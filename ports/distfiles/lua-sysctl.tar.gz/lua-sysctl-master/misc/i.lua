#!/usr/bin/env lua
sysctl = require('sysctl')
g = sysctl.get
s = sysctl.set
