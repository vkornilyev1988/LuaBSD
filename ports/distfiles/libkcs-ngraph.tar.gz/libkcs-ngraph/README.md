REQUIREMENTS 
	libnetgraph
	для загрузки графа из БД, необходимо указать соответствующий флаг и библиотеку БД
	например, -DBDB_ENABLE -lbdb

DESCRIPTION
	libngraph.so - библиотека для работы с netgraph.

FUNCTIONS

	int
	ngraph_mkpeer_node(char *path, char *type, char *ourhook, char *peerhook);
		описание:
			создать узел типа type и соеднить и с path.
		возвращаемое значение:
			0 при успехе иначе -1

	int
	ngraph_connect_node(char *path, char *peer, char *ourhook, char *peerhook);
		описание:
			соединить узел path с узлом peer.
		возвращаемое значение:
			0 при успехе иначе -1

	int
	ngraph_shutdown_node(char *node, int type);
		описание:
			выключить узел(-ы). в зависимости от type, node будет восприниматься как имя типа или узла
			type:
				NGRAPH_SHUTDOWN_BY_NAME
				NGRAPH_SHUTDOWN_BY_TYPE
		возвращаемое значение:
			0 при успехе иначе -1

	int
	ngraph_name_node(char *path, char *name);
		описание:
			переименовать узел path в name.
		возвращаемое значение:
			0 при успехе иначе -1

	int
	ngraph_msg_node(char *path, char *cmd, char *params);
		описание:
			отправить сообщение на узел path.
		возвращаемое значение:
			0 при успехе иначе -1

	int
	ngraph_rmhook(char *path, char *hook);
		описание:
			удалить хук hook у узла path
		возвращаемое значение:
			0 при успехе иначе -1

	char *
	ngraph_msg_node_rc(char *path, char *cmd, char *params);
		описание:
			отправить сообщение на узел и получить ответ. ответ должен быть освобожден функцией free
		возвращаемое значение:
			указатель на строку при успехе иначе NULL

	struct ng_vlan_table *
	ngraph_msg_vlan(char *path, char *cmd);
		описание:
			отправить сообщение на узел типа vlan для получения текущих фильтров узла. ответ должен быть освобожден функцией free
		возвращаемое значение:
			указатель ng_vlan_table * иначе NULL

	ngraph_info_t **
	ngraph_list(int *size);
		описание:
			получить список доступных узлов с их хуками. каждый указатель должен быть освобожден функцией ngraph_info_node_free. в параметр size будет записано количество узлов
		возвращаемое значение:
			указатель ngraph_info_t ** иначе NULL

	ngraph_info_t *
	ngraph_info_node(char *path);
		описание:
			получить информацию об узле path и его хуках. указатель должен быть усвобожден функцией ngraph_info_node_free
		возвращаемое значение:
			указатель ngraph_info_t * иначе NULL

	void
	ngraph_info_node_free(ngraph_info_t *);
		описание:
			освободить память ngraph_info_t *

	int
	ngraph_load(void);
		описание:
			применить конфигурацию графа из БД
		возвращаемое значение:
			0 при успехе иначе -1
