#include <ngraph.h>

int kek(void)
{
	ngraph_info_t **next;
	int size = 0;
	next = ngraph_list(&size);
	printf("%d\n", size);
//	ngraph_info_t *next;
	for (int i = 0; i < size; i++) {
//		printf("%s\n", next[i]->name);
		for (int k = 0; k < next[i]->hooks_count; k++) {
//			printf("\t%s %s %s\n", next->hooks[k]->ourhook, next->hooks[k]->peerhook, next->hooks[k]->peername);
		}
	ngraph_info_node_free(next[i]);
	}

	free(next);
	return 0;
}

int main(void)
{

	kek();
//	printf("#####################################################################\n");
/*	kek();
//	printf("#####################################################################\n");
	kek();
//	printf("#####################################################################\n");
	kek();
//	printf("#####################################################################\n");
	kek();
//	printf("#####################################################################\n");
	kek();
//	printf("#####################################################################\n");
	kek();
//	printf("\n");
*/	return 0;
}
