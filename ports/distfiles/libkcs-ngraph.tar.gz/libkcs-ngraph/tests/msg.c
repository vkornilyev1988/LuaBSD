#include <ngraph.h>

int main(void)
{

	char *msg = ngraph_msg_node_rc("vlan:", "gettable", "");
	if (msg != NULL) {
		printf("%s\n", msg);
		free(msg);
	}

	return 0;
}
