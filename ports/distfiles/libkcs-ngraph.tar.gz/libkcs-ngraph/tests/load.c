#include <ngraph.h>


int main(void)
{

	printf("%d\n", ngraph_load());
	return 0;
}
