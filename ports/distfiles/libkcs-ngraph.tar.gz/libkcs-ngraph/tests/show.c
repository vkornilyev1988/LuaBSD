#include <ngraph.h>

int main(int ac, char *av[])
{
	printf("%d\n", ac);
	ngraph_info_t *next = ngraph_info_node("vlan:");
//	printf("%s\n", info->name);
//	ngraph_info_t *next;
//	for (next = info; next != NULL; next = next->next) {
		printf("%s\n", next->name);
		for (int k = 0; k < next->hooks_count; k++) {
			printf("\t%s %s %s\n", next->hooks[k]->ourhook, next->hooks[k]->peerhook, next->hooks[k]->peername);
//			free(next->hooks[k]);
		}
////	free(next->hooks);
	ngraph_info_node_free(next);
	free(next);
//	}
/*	while (info != NULL) {
		next = info->next;
		free(info);
		info = next;
	}
*/

//	ngraph_list_free(info);
	return 0;
}
