#include <sys/ioctl.h>
#include <net/if.h>
#include <net/if_dl.h>
#include <net/if_types.h>
#include <net/ethernet.h>
#include <kenv.h>
#include "ngraph.h"

#ifdef BDB_ENABLE
#include <bdb.h>

#endif // BDB_ENABLE

#define NGRAPH_EIFACE_MAC_PREFIX    "00:1d:92:"

static void ngraph_mac_gen(char *mac);
static int ngraph_iface_rename(const char *oldname, const char *val);
static int ngraph_check_node(char *path);
static char *ngraph_get_peername(char *path);
static ngraph_info_t *ngraph_info_node_s(char *path, int dsock, int csock);
static int ngraph_shutdown_eifaces(void);


int
ngraph_mkpeer_node(const char *path, const char *type, const char *ourhook, const char *peerhook)
{
    if (path == NULL) {
        path = ".";
    }
#ifdef ZDEBUG
    printf("mkpeer %s %s %s %s\n", path, type, ourhook, peerhook);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    struct ngm_mkpeer mkp;
    memset(&mkp, 0, sizeof(struct ngm_mkpeer));
    snprintf(mkp.type, sizeof(mkp.type), "%s", type);
    snprintf(mkp.ourhook, sizeof(mkp.ourhook), "%s", ourhook);
    snprintf(mkp.peerhook, sizeof(mkp.peerhook), "%s", peerhook);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_MKPEER, &mkp, sizeof(mkp)) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    close(csock);
    close(dsock);
    // if (strcmp(type, "eiface") == 0) {
    //     char mac[NGRAPH_MAC_LEN_MAX];
    //     ngraph_mac_gen(mac);
    //     ngraph_set_mac(, mac);
    //     free(eiface);
    // }
    return 0;
}

int ngraph_rmhook(const char *path, const char *hook)
{
#ifdef ZDEBUG
    printf("rmhook %s %s\n", path, hook);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    struct ngm_rmhook rmh;
    memset(&rmh, 0, sizeof(struct ngm_rmhook));
    snprintf(rmh.ourhook, sizeof(rmh.ourhook), "%s", hook);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_RMHOOK, &rmh, sizeof(rmh)) < 0) {
        return -1;
    }
    close(csock);
    close(dsock);
    return 0;
}

int
ngraph_connect_node(const char *path, const char *peer, const char *ourhook, const char *peerhook)
{
#ifdef ZDEBUG
    printf("connect %s %s %s %s\n", path, peer, ourhook, peerhook);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    struct ngm_connect con;
    memset(&con, 0, sizeof(struct ngm_connect));
    snprintf(con.path, sizeof(con.path), "%s%s", peer, strchr(peer, ':') == NULL ? ":" : "");
    snprintf(con.ourhook, sizeof(con.ourhook), "%s", ourhook);
    snprintf(con.peerhook, sizeof(con.peerhook), "%s", peerhook);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_CONNECT, &con, sizeof(con)) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    close(csock);
    close(dsock);
    return 0;
}

ngraph_info_t **
ngraph_list(int *size)
{
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return NULL;
    }
    struct ng_mesg *resp;
    struct namelist *nlist;
    struct nodeinfo *ninfo;
    if (NgSendMsg(csock, ".", NGM_GENERIC_COOKIE,
        NGM_LISTNODES, NULL, 0) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    nlist = (struct namelist *) resp->data;
    ninfo = nlist->nodeinfo;
    char    path[NG_PATHSIZ];

    ngraph_info_t **info;
    info = malloc(sizeof(ngraph_info_t *) * nlist->numnames);
    if (info == NULL) {
        close(csock);
        close(dsock);
        return NULL;
    }
    int k = 0;
    while (nlist->numnames > 0) {
        snprintf(path, sizeof(path),
            "[%lx]:", (u_long)ninfo->id);
        if ((info[k] = ngraph_info_node_s(path, dsock, csock)) == NULL) {
            break;
        }
        k++;
        ninfo++;
        nlist->numnames--;
    }

    *size = k;
    free(resp);
    close(csock);
    close(dsock);
    return info;
}

static ngraph_info_t *
ngraph_info_node_s(char *path, int dsock, int csock)
{
    struct ng_mesg *resp;
    struct hooklist *hlist;
    struct nodeinfo *ninfo;
    if (NgSendMsg(csock, path, NGM_GENERIC_COOKIE,
        NGM_LISTHOOKS, NULL, 0) < 0) {
        return NULL;
    }
    if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
        return NULL;
    }
    hlist = (struct hooklist *) resp->data;
    ninfo = &hlist->nodeinfo;
    ngraph_info_t *info = malloc(sizeof(ngraph_info_t));
    if (!*ninfo->name)
        snprintf(info->name, sizeof(info->name), "%s", NGRAPH_UNNAMED);
    else
        snprintf(info->name, sizeof(info->name), "%s", ninfo->name);
    snprintf(info->type, sizeof(info->type), "%s", ninfo->type);
    info->hooks_count = ninfo->hooks;
    if (ninfo->hooks > 0) {
        info->hooks = malloc(sizeof(ngraph_hook_info_t *) * ninfo->hooks);
        for (int k = 0; k < ninfo->hooks; k++) {
            info->hooks[k] = malloc(sizeof(ngraph_hook_info_t));
            snprintf(info->hooks[k]->ourhook, sizeof(info->hooks[k]->ourhook), "%s", hlist->link[k].ourhook);
            snprintf(info->hooks[k]->ourhook, sizeof(info->hooks[k]->ourhook), "%s", hlist->link[k].ourhook);
            snprintf(info->hooks[k]->peerhook, sizeof(info->hooks[k]->peerhook), "%s", hlist->link[k].peerhook);
            snprintf(info->hooks[k]->peertype, sizeof(info->hooks[k]->peertype), "%s", hlist->link[k].nodeinfo.type);
            if (!*hlist->link[k].nodeinfo.name)
                snprintf(info->hooks[k]->peername, sizeof(info->hooks[k]->peername), "%s", NGRAPH_UNNAMED);
            else
                snprintf(info->hooks[k]->peername, sizeof(info->hooks[k]->peername), "%s", hlist->link[k].nodeinfo.name);
        }
    }
    free(resp);
    return info;
}
ngraph_info_t *
ngraph_info_node(const char *path)
{
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return NULL;
    }
    struct ng_mesg *resp;
    struct hooklist *hlist;
    struct nodeinfo *ninfo;
    char ng_path[strlen(path) + 2];
    char *ch;

    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_LISTHOOKS, NULL, 0) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    hlist = (struct hooklist *) resp->data;
    ninfo = &hlist->nodeinfo;
    ngraph_info_t *info = malloc(sizeof(ngraph_info_t));
    if (!*ninfo->name)
        snprintf(info->name, sizeof(info->name), "%s", NGRAPH_UNNAMED);
    else
        snprintf(info->name, sizeof(info->name), "%s", ninfo->name);
    snprintf(info->type, sizeof(info->type), "%s", ninfo->type);
    info->hooks_count = ninfo->hooks;
    if (ninfo->hooks > 0) {
        info->hooks = malloc(sizeof(ngraph_hook_info_t *) * ninfo->hooks);
        for (int k = 0; k < ninfo->hooks; k++) {
            info->hooks[k] = malloc(sizeof(ngraph_hook_info_t));
            snprintf(info->hooks[k]->ourhook, sizeof(info->hooks[k]->ourhook), "%s", hlist->link[k].ourhook);
            snprintf(info->hooks[k]->ourhook, sizeof(info->hooks[k]->ourhook), "%s", hlist->link[k].ourhook);
            snprintf(info->hooks[k]->peerhook, sizeof(info->hooks[k]->peerhook), "%s", hlist->link[k].peerhook);
            snprintf(info->hooks[k]->peertype, sizeof(info->hooks[k]->peertype), "%s", hlist->link[k].nodeinfo.type);
            if (!*hlist->link[k].nodeinfo.name)
                snprintf(info->hooks[k]->peername, sizeof(info->hooks[k]->peername), "%s", NGRAPH_UNNAMED);
            else
                snprintf(info->hooks[k]->peername, sizeof(info->hooks[k]->peername), "%s", hlist->link[k].nodeinfo.name);
        }
    }
    free(resp);
    close(csock);
    close(dsock);
    return info;
}
void 
ngraph_info_node_free(ngraph_info_t *info)
{
    for (int k = 0; k < info->hooks_count; k++) {
        free(info->hooks[k]);
    }
    if (info->hooks_count > 0)
        free(info->hooks);
    free(info);
}

int
ngraph_shutdown_node(const char *node, int type)
{
#ifdef ZDEBUG
    printf("shutdown %s %s\n", node, type == NGRAPH_SHUTDOWN_BY_NAME ? "by_name" : "by_type");
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    if (type == NGRAPH_SHUTDOWN_BY_NAME) {
        char ng_path[strlen(node) + 2];
        char *ch;
        if ((ch = strchr(node, ':')) == NULL)
            snprintf(ng_path, sizeof(ng_path), "%s:", node);
        else
            snprintf(ng_path, sizeof(ng_path), "%s", node);
        if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
            NGM_SHUTDOWN, NULL, 0) < 0) {
            close(csock);
            close(dsock);
            return -1;
        }
    } else if (type == NGRAPH_SHUTDOWN_BY_TYPE) {
        struct ng_mesg *resp;
        struct namelist *nlist;
        struct nodeinfo *ninfo;
        if (NgSendMsg(csock, ".", NGM_GENERIC_COOKIE,
            NGM_LISTNODES, NULL, 0) < 0) {
            close(csock);
            close(dsock);
            return -1;
        }
        if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
            close(csock);
            close(dsock);
            return -1;
        }
        char nametmp[NG_PATHSIZ];
        nlist = (struct namelist *) resp->data;
        ninfo = nlist->nodeinfo;
        while (nlist->numnames > 0) {
            if (strcmp(ninfo->type, node) == 0) {
                    snprintf(nametmp, sizeof(nametmp), "[%lx]:", (u_long)ninfo->id);
                    if (NgSendMsg(csock, nametmp, NGM_GENERIC_COOKIE,
                        NGM_SHUTDOWN, NULL, 0) < 0) {
                            free(resp);
                            close(csock);
                            close(dsock);
                            return -1;
                    }
            }
            ninfo++;
            nlist->numnames--;
        }
    free(resp);
    }
    close(csock);
    close(dsock);
    return 0;
}

int
ngraph_name_node(const char *path, const char *name)
{
#ifdef ZDEBUG
    printf("name_node %s %s\n", path, name);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }

    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);

    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_NODEINFO, NULL, 0) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    u_char rbuf[sizeof(struct ng_mesg) + sizeof(struct nodeinfo)];
    struct ng_mesg *reply;
    struct nodeinfo *info;
    reply = (struct ng_mesg *)rbuf;
    info = (struct nodeinfo *)reply->data;
    if (NgRecvMsg(csock, reply, sizeof rbuf, NULL) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }

    struct ngm_name name_st;
    memset(&name_st, 0, sizeof(struct ngm_name));
    snprintf(name_st.name, sizeof(name_st.name), "%s", name);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_NAME, &name_st, sizeof(name_st)) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    close(csock);
    close(dsock);
    if (strcmp(info->type, "eiface") == 0 || strcmp(info->type, "ether") == 0) {
        return ngraph_iface_rename(info->name, name);
    } else {
        return 0;
    }
}

int
ngraph_msg_node(const char *path, const char *cmd, const char *params)
{
    if (!cmd) {
        return -1;
    }
#ifdef ZDEBUG
    printf("msg %s %s %s\n", path, cmd, params);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    int i, len;
    len = strlen(params) + 1;
    char buf[len + 2];
    snprintf(buf, sizeof(buf), "%s", params);

    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    if (NgSendAsciiMsg(csock, ng_path, "%s %s", cmd, buf) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    close(csock);
    close(dsock);
    return 0;
}

struct ng_vlan_table *
ngraph_msg_vlan(const char *path, const char *cmd)
{
    if (!cmd) {
        return NULL;
    }
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return NULL;
    }

    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    if (NgSendAsciiMsg(csock, ng_path, "%s", cmd) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    struct ng_mesg *m;
    char path_rc[NG_PATHSIZ];

    if (NgAllocRecvMsg(csock, &m, path_rc) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    struct ng_vlan_table *tbl = malloc(m->header.arglen);
    if (tbl == NULL) {
        free(m);
        close(csock);
        close(dsock);
        return NULL;
    }

    memmove(tbl, m->data, m->header.arglen);
    free(m);
    close(csock);
    close(dsock);
    return tbl;
}
char *
ngraph_msg_node_rc(const char *path, const char *cmd, const char *params)
{
    if (!cmd) {
        return NULL;
    }
#ifdef ZDEBUG
    printf("msg_rc %s %s %s\n", path, cmd, params);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return NULL;
    }
    int i, len;
    len = strlen(params) + 1;
    char buf[len + 2];
    snprintf(buf, sizeof(buf), "%s", params);

    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    if (NgSendAsciiMsg(csock, ng_path, "%s %s", cmd, buf) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }

    struct ng_mesg *m, *m2;
    struct ng_mesg *ascii;
    char path_rc[NG_PATHSIZ];

    if (NgAllocRecvMsg(csock, &m, path_rc) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    if (NgSendMsg(csock, path_rc, NGM_GENERIC_COOKIE,
            NGM_BINARY2ASCII, m, sizeof(*m) + m->header.arglen) < 0
            || NgAllocRecvMsg(csock, &m2, NULL) < 0) {
            if (m->header.arglen == 0){
                close(csock);
                close(dsock);
                free(m);
                return NULL;
            }
    }

    free(m);
    ascii = (struct ng_mesg *)m2->data;
    char *retval = NULL;
    if (*ascii->data != '\0')
    {
        retval = malloc(strlen(ascii->data) + 1);
        snprintf(retval, strlen(ascii->data) + 1, "%s", ascii->data);
    }
    free(m2);
    close(csock);
    close(dsock);
    return retval;
}

static char *
ngraph_get_peername(char *path)
{
#ifdef ZDEBUG
    printf("get_peername %s\n", path);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return NULL;
    }
    struct ng_mesg *resp;
    struct hooklist *hlist;
    struct nodeinfo *ninfo;

    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_LISTHOOKS, NULL, 0) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
        close(csock);
        close(dsock);
        return NULL;
    }
    hlist = (struct hooklist *) resp->data;
    ninfo = &hlist->nodeinfo;
    char *name;
    name = malloc(NG_PATHSIZ);
    if (!*ninfo->name)
        snprintf(name, NG_PATHSIZ, "%s", NGRAPH_UNNAMED);
    else
        snprintf(name, NG_PATHSIZ, "%s", ninfo->name);
    free(resp);
    close(csock);
    close(dsock);
    return name;
}

int
ngraph_load(void)
{
#ifdef BDB_ENABLE
    char db_path[KENV_MVALLEN + 1];
    if(kenv(KENV_GET, BDB_KENV_PATH, db_path, sizeof(db_path)) < 0)
        return -1;
    DB *dbp = bdb_open("ngraph", db_path);
    if (dbp == NULL) {
        printf("failed to open ngraph db\n");
        return -1;
    }

    char tmp[NG_PATHSIZ];
    memset(tmp, 0, sizeof(tmp));
    ngraph_shutdown_eifaces();
    ngraph_shutdown_node("vlan", NGRAPH_SHUTDOWN_BY_TYPE);
    for (int i = 0; i < 29; i++) {
        snprintf(tmp, sizeof(tmp), "%s:link%d", NGRAPH_MAIN_SWITCH_NAME, i);
        ngraph_shutdown_node(tmp, NGRAPH_SHUTDOWN_BY_NAME);
    }

    bdb_data_t *data = NULL;
    while ((data = bdb_seq(dbp, BDB_POS_NEXT)) != NULL) {
        memset(tmp, 0, sizeof(tmp));
        int ret = 0;
        bdb_value_t value;
        memset(&value, 0, sizeof(bdb_value_t));
        char *type, *name;
        ngraph_hooks_info_t hi;
        while ((ret = bdb_parse_next(data, &value)) == 0) {
            if (strcmp(value.bdb_vl_colname, "type") == 0) {
                type = value.bdb_vl_s;
            } else if (strcmp(value.bdb_vl_colname, "name") == 0) {
                name = value.bdb_vl_s;
            } else if (strcmp(value.bdb_vl_colname, "ourhook") == 0) {
                hi.ourhook = value.bdb_vl_s;
            } else if (strcmp(value.bdb_vl_colname, "peertype") == 0) {
                hi.peertype = value.bdb_vl_s;
            } else if (strcmp(value.bdb_vl_colname, "peerhook") == 0) {
                hi.peerhook = value.bdb_vl_s;
            } else if (strcmp(value.bdb_vl_colname, "peername") == 0) {
                hi.peername = value.bdb_vl_s;
            } else if (strcmp(value.bdb_vl_colname, "filter") == 0) {
                hi.filter = value.bdb_vl_s;
            }
        }
        if (strcmp(hi.ourhook, "0") == 0) {
            free(data);
            continue;
        }
        char *c;
        char *tmp_oh = strtok(hi.ourhook, ",");
        while (tmp_oh != NULL) {
            if ((c = strchr(hi.peertype, ',')) != NULL) 
                *c = '\0';
            if ((c = strchr(hi.peerhook, ',')) != NULL)
                *c = '\0';
            if ((c = strchr(hi.peername, ',')) != NULL)
                *c = '\0';
            if (strcmp(type, "ether") == 0) {
                if (strcmp(tmp_oh, "upper") == 0) {
                    snprintf(tmp, sizeof(tmp), "%s:%s", name, tmp_oh);
                    if (!ngraph_check_node(tmp)) {
                        char *peer = ngraph_get_peername(tmp);
                        if (peer != NULL) {
                            if (strcmp(peer, hi.peername) == 0) {
                                free(peer);
                                if (c != NULL) {
                                    hi.peertype = hi.peertype + strlen(hi.peertype) + 1;
                                    hi.peername = hi.peername + strlen(hi.peername) + 1;
                                    hi.peerhook = hi.peerhook + strlen(hi.peerhook) + 1;
                                }
                                tmp_oh = strtok(NULL, ",");
                                continue;
                            }
                            free(peer);
                        }
                        ngraph_rmhook(name, tmp_oh);
                        if (!ngraph_check_node(hi.peername)) {
                            ngraph_connect_node(name, hi.peername, tmp_oh, name);
                        } else {
                            ngraph_mkpeer_node(name, hi.peertype, tmp_oh, name);
                            ngraph_name_node(tmp, hi.peertype);
                        }
                    } else {
                        if (!ngraph_check_node(hi.peername)) {
                            ngraph_connect_node(name, hi.peername, tmp_oh, name);
                        } else {
                            ngraph_mkpeer_node(name, hi.peertype, tmp_oh, name);
                            ngraph_name_node(tmp, hi.peertype);
                        }
                    }
                } else if (strcmp(tmp_oh, "lower") == 0) {
                    snprintf(tmp, sizeof(tmp), "%s:%s", name, tmp_oh);
                    if (!ngraph_check_node(tmp)) {
                        ngraph_rmhook(name, tmp_oh);
                    }
                    if (!ngraph_check_node(hi.peername)) {
                        ngraph_connect_node(name, hi.peername, tmp_oh, hi.peerhook);
                    } else {
                        ngraph_mkpeer_node(name, hi.peertype, tmp_oh, hi.peerhook);
                        ngraph_name_node(tmp, hi.peername);
                    }
                }
            } else if (strcmp(type, "vlan") == 0) {
                if (!ngraph_check_node(name)) {
                    snprintf(tmp, sizeof(tmp), "%s:%s", name, tmp_oh);
                    if (strcmp(hi.peertype, "eiface") == 0) {
                        ngraph_mkpeer_node(name, hi.peertype, tmp_oh, hi.peerhook);
                        ngraph_name_node(tmp, hi.peername);
                        char mac[NGRAPH_MAC_LEN_MAX];
                        ngraph_mac_gen(mac);
                        ngraph_set_mac(hi.peername, mac);
                    } else {
                        ngraph_connect_node(name, hi.peername, tmp_oh, hi.peerhook);
                    }
                } else {
                    if (strcmp(hi.peertype, "eiface") == 0) {
                        char eiface[NG_PATHSIZ];
                        memset(eiface, 0, NG_PATHSIZ);
                        ngraph_mkpeer_node_rc(".", hi.peertype, hi.peerhook, hi.peerhook, eiface);
                        ngraph_name_node(eiface, hi.peername);
                        char mac[NGRAPH_MAC_LEN_MAX];
                        memset(mac, 0, NGRAPH_MAC_LEN_MAX);
                        ngraph_mac_gen(mac);
                        ngraph_set_mac(hi.peername, mac);
                        // free(eiface);
                    }
                    snprintf(tmp, sizeof(tmp), "%s:%s", hi.peername, hi.peerhook);
                    ngraph_mkpeer_node(hi.peername, "vlan", hi.peerhook, tmp_oh);
                    ngraph_name_node(tmp, name);
                }
                c = strchr(hi.filter, ',');
                if (c != NULL)
                    *c = '\0';
                if (strcmp(tmp_oh, NGRAPH_TRUNK_NF) == 0) {
                    char *dot = strchr(hi.filter, '.');
                    if (dot == NULL) {
                        int filter = (int)strtol(hi.filter, NULL, 10);
                        char msg[NGRAPH_VLAN_MSG_MAX_LEN];
                        snprintf(msg, sizeof(msg), "{ hook=\"%s\" tcount=1 trunk=[%d] }", tmp_oh, filter);
                        ngraph_msg_node(name, "addfilter", msg);
                    } else {
                        char *msg = malloc(NGRAPH_VLAN_MSG_MAX_LEN);
                        char *cur = hi.filter;
                        int filter;
                        snprintf(msg, NGRAPH_VLAN_MSG_MAX_LEN, "{ hook=\"%s\" trunk=[ ", tmp_oh);
                        size_t len = NGRAPH_VLAN_MSG_MAX_LEN;
                        int count = 0;
                        while ((filter = (int)strtol(cur, &cur, 10))) {
                            int n = snprintf(NULL, 0, "%d", filter);
                            len += n;
                            msg = realloc(msg, len);
                            snprintf(msg, NGRAPH_VLAN_MSG_MAX_LEN, "%s%d ", msg, filter);
                            count++;
                            if (*cur == '\0')
                                break;
                            cur++;
                        }
                        snprintf(msg, len, "%s] tcount=%d}", msg, count);
                        ngraph_msg_node(name, "addfilter", msg);
                        free(msg);
                    }
                } else {
                    int filter = (int)strtol(hi.filter, NULL, 10);
                    if (filter != 0) {
                        char msg[NGRAPH_VLAN_MSG_MAX_LEN];
                        snprintf(msg, sizeof(msg), "{ hook=\"%s\" vid=%d vlan=%d }", tmp_oh, filter, filter);
                        ngraph_msg_node(name, "addfilter", msg);
                    }
                }
                if (c != NULL)
                    hi.filter = hi.filter + strlen(hi.filter) + 1;
            }
            if (c != NULL) {
                hi.peertype = hi.peertype + strlen(hi.peertype) + 1;
                hi.peername = hi.peername + strlen(hi.peername) + 1;
                hi.peerhook = hi.peerhook + strlen(hi.peerhook) + 1;
            }
            tmp_oh = strtok(NULL, ",");
        }
        free(data);
    }
    bdb_close(dbp);
    return 0;

#else
    return -1;
#endif
}

static int
ngraph_check_node(char *path)
{
#ifdef ZDEBUG
    printf("check %s\n", path);
    return 0;
#endif
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    struct ng_mesg *resp;
    struct namelist *nlist;
    struct nodeinfo *ninfo;

    char ng_path[strlen(path) + 2];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_LISTHOOKS, NULL, 0) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
        free(resp);
        close(csock);
        close(dsock);
        return -1;
    }

    free(resp);
    close(csock);
    close(dsock);
    return 0;
}

static int
ngraph_shutdown_eifaces(void)
{
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());

    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    struct ng_mesg *resp;
    struct namelist *nlist;
    struct nodeinfo *ninfo;
    if (NgSendMsg(csock, ".", NGM_GENERIC_COOKIE,
        NGM_LISTNAMES, NULL, 0) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    char nametmp[NG_PATHSIZ];
    nlist = (struct namelist *) resp->data;
    ninfo = nlist->nodeinfo;
    while (nlist->numnames > 0) {
        if (strcmp(ninfo->type, "eiface") == 0 && strcmp(ninfo->name, NGRAPH_MAIN_BR_NAME) != 0) {
                snprintf(nametmp, sizeof(nametmp), "%s%s", ninfo->name, ":");
                if (NgSendMsg(csock, nametmp, NGM_GENERIC_COOKIE,
                    NGM_SHUTDOWN, NULL, 0) < 0) {
                        free(resp);
                        close(csock);
                        close(dsock);
                        return -1;
                }
        }
        ninfo++;
        nlist->numnames--;
    }
    free(resp);
    close(csock);
    close(dsock);
    return 0;
}

int
ngraph_mkpeer_node_rc(char *path, char *type, char *ourhook, char *peerhook, char *name)
{
    if (path == NULL) {
        path = ".";
    }
    int csock, dsock;

    char    ngname[NG_NODESIZ];
    memset(ngname, 0, NG_NODESIZ);
    snprintf(ngname, sizeof(ngname), "ngctl%d", getpid());
    if (NgMkSockNode(ngname, &csock, &dsock) < 0) {
        return -1;
    }
    char ng_path[NG_PATHSIZ];
    char *ch;
    if ((ch = strchr(path, ':')) == NULL)
        snprintf(ng_path, sizeof(ng_path), "%s:", path);
    else
        snprintf(ng_path, sizeof(ng_path), "%s", path);
    struct ngm_mkpeer mkp;
    memset(&mkp, 0, sizeof(struct ngm_mkpeer));
    snprintf(mkp.type, sizeof(mkp.type), "%s", type);
    snprintf(mkp.ourhook, sizeof(mkp.ourhook), "%s", ourhook);
    snprintf(mkp.peerhook, sizeof(mkp.peerhook), "%s", peerhook);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_MKPEER, &mkp, sizeof(mkp)) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }
    struct ng_mesg *resp;
    struct hooklist *hlist;
    struct nodeinfo *ninfo;
    snprintf(ng_path, sizeof(ng_path), "%s:%s", path, ourhook);
    if (NgSendMsg(csock, ng_path, NGM_GENERIC_COOKIE,
        NGM_LISTHOOKS, NULL, 0) < 0) {
        printf("list hooks failed\n");
        close(csock);
        close(dsock);
        return -1;
    }

    if (NgAllocRecvMsg(csock, &resp, NULL) < 0) {
        close(csock);
        close(dsock);
        return -1;
    }

    hlist = (struct hooklist *) resp->data;
    ninfo = &hlist->nodeinfo;
    // char *name = malloc(NG_PATHSIZ);
    // if (name == NULL) {
    //     free(resp);
    //     close(csock);
    //     close(dsock);
    //     return NULL;
    // }
    if (!*ninfo->name)
        snprintf(name, NG_PATHSIZ, "%s", NGRAPH_UNNAMED);
    else
        snprintf(name, NG_PATHSIZ, "%s", ninfo->name);

    free(resp);

    close(csock);
    close(dsock);
    return 0;
}

static int
ngraph_iface_rename(const char *oldname, const char *val)
{
    int s, ret;
    if ((s = socket(AF_LOCAL, SOCK_DGRAM, 0)) < 0) {
        if  ((s = socket(AF_LOCAL, SOCK_DGRAM, 0)) < 0) 
            return -1;
    }
    struct ifreq ifr;
    memset(&ifr, 0, sizeof(struct ifreq));
    strlcpy(ifr.ifr_name, oldname, sizeof(ifr.ifr_name));
    char *newname = strdup(val);
    if (newname == NULL) {
        close(s);
        return -1;
    }

    ifr.ifr_data = newname;
    if (ioctl(s, SIOCSIFNAME, (caddr_t)&ifr) < 0) {
        free(newname);
        close(s);
        return -1;
    }
    free(newname);
    close(s);
    return 0;
}

static void
ngraph_mac_gen(char *mac)
{
    char mac_gen1[4];
    memset(mac_gen1, 0, 4);
    char mac_gen2[4];
    memset(mac_gen2, 0, 4);
    char mac_gen3[4];
    memset(mac_gen3, 0, 4);
    int tp;

    tp = rand() % 256;
    snprintf(mac_gen1, 4, "%0.2x:", tp < 16 ? 0 : tp);
    tp = rand() % 256;
    snprintf(mac_gen2, 4, "%0.2x:", tp < 16 ? 0 : tp);
    tp = rand() % 256;
    snprintf(mac_gen3, 4, "%0.2x", tp < 16 ? 0 : tp);

    snprintf(mac, NGRAPH_MAC_LEN_MAX, "%s%s%s%s", NGRAPH_EIFACE_MAC_PREFIX, mac_gen1, mac_gen2, mac_gen3);
}

int
ngraph_set_mac(char *iface, char *mac)
{
    int s;
    if ((s = socket(AF_LOCAL, SOCK_DGRAM, 0)) < 0) {
        if  ((s = socket(AF_LOCAL, SOCK_DGRAM, 0)) < 0) {
            return -1;
        }
    }
    struct ifreq link_ridreq;
    memset(&link_ridreq, 0, sizeof(struct ifreq));
    struct sockaddr_dl sdl;
    memset(&sdl, 0, sizeof(struct sockaddr_dl));
    struct sockaddr *sa = &link_ridreq.ifr_addr;
    char *temp;

    if ((temp = malloc(strlen(mac) + 2)) == NULL) {
        close(s);
        return -1;
    }
    temp[0] = ':';
    strcpy(temp + 1, mac);
    sdl.sdl_len = sizeof(sdl);
    link_addr(temp, &sdl);
    free(temp);
    sa->sa_family = AF_LINK;
    sa->sa_len = sdl.sdl_alen;
    bcopy(LLADDR(&sdl), sa->sa_data, sdl.sdl_alen);
    strlcpy(link_ridreq.ifr_name, iface, sizeof(link_ridreq.ifr_name));
    if (ioctl(s, SIOCSIFLLADDR, (caddr_t)&link_ridreq) < 0) {
        close(s);
        return -1;
    }
    close(s);
    return 0;
}