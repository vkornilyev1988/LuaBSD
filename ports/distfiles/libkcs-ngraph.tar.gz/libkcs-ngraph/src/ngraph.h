#ifndef KCS_NGRAPH_H
#define KCS_NGRAPH_H

#include <sys/socket.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sysexits.h>
#include <unistd.h>
#include <fcntl.h>
#include <net/ethernet.h>
#include <netgraph.h>
#include <netgraph/ng_vlan.h>
#include <errno.h>

#define NGRAPH_SHUTDOWN_BY_NAME		0
#define NGRAPH_SHUTDOWN_BY_TYPE		1
#define NGRAPH_UNNAMED				"unnamed"
#define NGRAPH_TRUNK_NF				"trunk0"
#define NGRAPH_MAIN_SWITCH_NAME		"switch"
#define NGRAPH_MAIN_BR_NAME			"br0"
#define NGRAPH_MAC_LEN_MAX			18
#define NGRAPH_VLAN_MSG_MAX_LEN		64

#define NGRAPH_TYPE_ETHER			1
#define NGRAPH_TYPE_EIFACE			2
#define NGRAPH_TYPE_BRIDGE			3
#define NGRAPH_TYPE_VLAN			4


typedef struct ngraph_hook_info {
	char ourhook[NG_HOOKSIZ];
	char peerhook[NG_HOOKSIZ];
	char peername[NG_PATHSIZ];
	char peertype[NG_TYPESIZ];
} ngraph_hook_info_t;

typedef struct ngraph_info {
	char name[NG_PATHSIZ];
	char type[NG_TYPESIZ];
	uint32_t hooks_count;
	ngraph_hook_info_t **hooks;
} ngraph_info_t;

typedef struct ngraph_hooks_info {
	char *ourhook;
	char *peertype;
	char *peerhook;
	char *peername;
	char *filter;
	size_t ourhooklen;
	size_t peertypelen;
	size_t peerhooklen;
	size_t peernamelen;
	size_t filterlen;
} ngraph_hooks_info_t;

int ngraph_mkpeer_node(const char *path, const char *type, const char *ourhook, const char *peerhook);
int ngraph_mkpeer_node_rc(char *path, char *type, char *ourhook, char *peerhook, char *name);
int ngraph_connect_node(const char *path, const char *peer, const char *ourhook, const char *peerhook);
int ngraph_shutdown_node(const char *node, int type);
int ngraph_name_node(const char *path, const char *name);
int ngraph_msg_node(const char *path, const char *cmd, const char *params);
int ngraph_rmhook(const char *path, const char *hook);
char *ngraph_msg_node_rc(const char *path, const char *cmd, const char *params);
struct ng_vlan_table *ngraph_msg_vlan(const char *path, const char *cmd);
ngraph_info_t **ngraph_list(int *size);
ngraph_info_t *ngraph_info_node(const char *path);
void ngraph_info_node_free(ngraph_info_t *);
int ngraph_load(void);
int ngraph_set_mac(char *iface, char *mac);

#endif // KCS_NGRAPH_H