#include "bdb.h"

DB *bdb_open(char *dbname, char *path)
{
	char fullpath[MAXPATHLEN + 1];
	snprintf(fullpath, sizeof(fullpath), "%s/%s.db", path, dbname);
	DB *dbp = dbopen(fullpath, O_RDWR, S_IRUSR|S_IWUSR, DB_BTREE, NULL);
	return dbp;
}

DB *bdb_create(char *dbname, char *path)
{
	char fullpath[MAXPATHLEN + 1];
	snprintf(fullpath, sizeof(fullpath), "%s/%s.db", path, dbname);
	DB *dbp = dbopen(fullpath, O_CREAT|O_RDWR, S_IRUSR|S_IWUSR, DB_BTREE, NULL);
	return dbp;
}

int bdb_copy(char *dir, char *oldname, char *newname)
{
	char from[MAXPATHLEN + 1];
	snprintf(from, sizeof(from), "%s/%s.db", dir, oldname);
	char to[MAXPATHLEN + 1];
	snprintf(to, sizeof(to), "%s/%s.db", dir, newname);
	int fd_to, fd_from;
	char buf[4096];
	ssize_t nread;
	int saved_errno;

	fd_from = open(from, O_RDONLY);
	if (fd_from < 0) {
#ifdef ZDEBUG
		printf("open %s failed\n", from);
#endif
		return -1;
	}

	fd_to = open(to, O_WRONLY | O_CREAT, 0666);
	if (fd_to < 0) {
#ifdef ZDEBUG
		printf("open %s failed\n", to);
#endif
		goto out_error;
	}

	while (nread = read(fd_from, buf, sizeof buf), nread > 0)
	{
		char *out_ptr = buf;
		ssize_t nwritten;
		do {
			nwritten = write(fd_to, out_ptr, nread);
			if (nwritten >= 0) {
				nread -= nwritten;
				out_ptr += nwritten;
			} else if (errno != EINTR) {
#ifdef ZDEBUG
				printf("write failed %s\n", strerror(EINTR));
#endif
				goto out_error;
			}
		} while (nread > 0);
	}

	if (nread == 0) {
		if (close(fd_to) < 0) {
			fd_to = -1;
			goto out_error;
		}
		close(fd_from);
		return 0;
	}

out_error:
	saved_errno = errno;

	close(fd_from);
	if (fd_to >= 0)
		close(fd_to);

	errno = saved_errno;
	return -1;
}

int bdb_close(DB *dbp)
{
	dbp->close(dbp);
	return 0;
}

int bdb_set(DB *dbp, bdb_data_t *data)
{
	DBT k, d;
	memset(&k, 0, sizeof(DBT));
	memset(&d, 0, sizeof(DBT));
	char tbuf[BDB_KEY_BYTE_MAX];
	uint64_t store;
	memset(tbuf, 0, BDB_KEY_BYTE_MAX);
	k.data = (u_char *)tbuf;
	char *p = tbuf;
	BDB_FROM_SCALAR(data->bdb_dt_key);
	k.size = sizeof(store) + 1;
	d.data = data->bdb_dt_p;
	d.size = data->bdb_dt_len;
	if (dbp->put(dbp, &k, &d, 0) == -1)
		return 1;
	return 0;
}

int bdb_key_exist(DB *dbp, long long key)
{
	DBT k, d;
	memset(&k, 0, sizeof(DBT));
	memset(&d, 0, sizeof(DBT));
	char tbuf[BDB_KEY_BYTE_MAX];
	memset(tbuf, 0, BDB_KEY_BYTE_MAX);
	uint64_t store;
	store = htonll(key);

	memmove(tbuf, &store, sizeof(store));
	k.data = (u_char *)tbuf;
	k.size = sizeof(store) + 1;
	if (dbp->get(dbp, &k, &d, 0))
		return 0;
	return 1;
}

int bdb_del(DB *dbp, long long key)
{
	DBT k;
	memset(&k, 0, sizeof(DBT));
	char tbuf[BDB_KEY_BYTE_MAX];
	memset(tbuf, 0, BDB_KEY_BYTE_MAX);
	uint64_t store;
	store = htonll(key);

	memmove(tbuf, &store, sizeof(store));
	k.data = (u_char *)tbuf;
	k.size = sizeof(store) + 1;
	int ret = 0;
	if ((ret = dbp->del(dbp, &k, 0)) == -1)
		return 1;
	return 0;
}

bdb_data_t *bdb_get(DB *dbp, long long key)
{
	DBT k, d;
	memset(&k, 0, sizeof(DBT));
	memset(&d, 0, sizeof(DBT));
	char tbuf[BDB_KEY_BYTE_MAX];
	memset(tbuf, 0, BDB_KEY_BYTE_MAX);
	uint64_t store;
	store = htonll(key);

	memmove(tbuf, &store, sizeof(store));
	k.data = (u_char *)tbuf;
	k.size = sizeof(store) + 1;
	if (dbp->get(dbp, &k, &d, 0))
		return NULL;
	bdb_data_t *data = malloc(sizeof(bdb_data_t));
	if (data == NULL) {
		return NULL;
	}
	data->bdb_dt_p = d.data;
	data->bdb_dt_schema = bdb_get_schema(dbp, &data->bdb_dt_schema_len);
	data->bdb_dt_len = d.size;
	data->bdb_dt_cur_len = d.size;
	return data;
}

bdb_data_t *bdb_seq(DB *dbp, int pos)
{
	static unsigned int rn = 0;
	DBT k, d;
	memset(&k, 0, sizeof(DBT));
	memset(&d, 0, sizeof(DBT));
	int ret = 0;
	if ((ret = dbp->seq(dbp, &k, &d, pos)) != 0) {
		return NULL;
	}
	if (strncmp(k.data, "bdb_", 4) == 0) {
		if (pos == BDB_POS_LAST) {
			if ((ret = dbp->seq(dbp, &k, &d, R_PREV)) != 0) 
				return NULL;
		} else {
			return NULL;
		}
	}
	bdb_data_t *data = malloc(sizeof(bdb_data_t));
	if (data == NULL) {
		return NULL;
	}
	char *p = k.data;
	BDB_TO_SCALAR(data->bdb_dt_key);
	data->bdb_dt_p = d.data;
	data->bdb_dt_schema = bdb_get_schema(dbp, &data->bdb_dt_schema_len);
	data->bdb_dt_len = d.size;
	data->bdb_dt_cur_len = d.size;
	return data;
}

char *bdb_get_schema(DB *dbp, size_t *size)
{
	DBT k, d;
	memset(&k, 0, sizeof(DBT));
	memset(&d, 0, sizeof(DBT));
	k.data = "bdb_schema";
	k.size = strlen("bdb_schema") + 1;
	if (dbp->get(dbp, &k, &d, 0))
		return NULL;
	*size = d.size;
	return d.data;
}

bdb_column_t *bdb_get_next_col(bdb_data_t *data)
{
	if (!data->bdb_dt_schema_len)
		return NULL;
	char *st, *col;
	char col_info[70];
	st = col_info;

	BDB_EXPAND(col, data->bdb_dt_schema);
	data->bdb_dt_schema_len = data->bdb_dt_schema_len - strlen(col) - 1;
	char *col_type;

	if ((col_type = strchr(col, ':')) == NULL) {
		return NULL;
	}
	bdb_column_t *ret = malloc(sizeof(bdb_column_t));
	*col_type = '\0';
	col_type++;
	snprintf(ret->col_name, sizeof(ret->col_name), "%s", col);
	snprintf(ret->type, sizeof(ret->type), "%s", col_type);
	return ret;
}
int bdb_parse_next(bdb_data_t *data, bdb_value_t *value)
{
	if (!data->bdb_dt_cur_len)
		return 1;
	char *tmp;
	char *p = data->bdb_dt_p;
	BDB_EXTRACT(value->bdb_vl_type, value->bdb_vl_colname, tmp);
	data->bdb_dt_p = p;
	data->bdb_dt_cur_len = data->bdb_dt_cur_len - strlen(value->bdb_vl_colname) - strlen(value->bdb_vl_type) - strlen(tmp) - 3;

	char *st, *sp = data->bdb_dt_schema, *col;
	char col_info[70];
	st = col_info;

	BDB_EXPAND(col, data->bdb_dt_schema);
	data->bdb_dt_schema_len = data->bdb_dt_schema_len - strlen(col) - 1;
	char *col_name, *col_type;

	if ((col_type = strchr(col, ':')) == NULL) {
		return -1;
	}
	*col_type = '\0';
	col_type++;
	if (strcmp(col, value->bdb_vl_colname) != 0 || 
		strcmp(col_type, value->bdb_vl_type) != 0)
		return -1;

	switch (*value->bdb_vl_type) {
		case BDB_COL_ADOUBLE:
		case BDB_COL_ALONG:
		case BDB_COL_ASTRING:
		case BDB_COL_STRING:
			value->bdb_vl_s = tmp;
		break;
		case BDB_COL_LONG:
			value->bdb_vl_l = strtol(tmp, NULL, 0);
		break;
		case BDB_COL_DOUBLE:
			value->bdb_vl_d = strtod(tmp, NULL);
		break;
	}
	return 0;
}

int bdb_freeget(void *data)
{
	free(data);
	return 0;
}

int bdb_add_next(bdb_data_t *data, bdb_value_t *value)
{
	data->bdb_dt_cur_len = strlen(value->bdb_vl_type) + strlen(value->bdb_vl_colname) + 3;

	// char *st, *sp = data->bdb_dt_schema, *col;
	// char col_info[70];
	// st = col_info;

	// BDB_EXPAND(col, data->bdb_dt_schema);
	// data->bdb_dt_schema_len = data->bdb_dt_schema_len - strlen(col) - 1;
	// char *col_name, *col_type;

	// if ((col_type = strchr(col, ':')) == NULL) {
	// 	return -1;
	// }
	// *col_type = '\0';
	// col_type++;
	// if (strcmp(col, value->bdb_vl_colname) != 0 || 
	// 	strcmp(col_type, value->bdb_vl_type) != 0)
	// 	return -1;
	int flag = 0;
	int n = 0;
	switch (*value->bdb_vl_type) {
		case BDB_COL_ADOUBLE:
		case BDB_COL_ALONG:
		case BDB_COL_ASTRING:
		case BDB_COL_STRING:
			flag = 1;
			data->bdb_dt_cur_len += strlen(value->bdb_vl_s);
		break;
		case BDB_COL_LONG:
			n = snprintf(NULL, 0, "%ld", value->bdb_vl_l);
			data->bdb_dt_cur_len += n;
		break;
		case BDB_COL_DOUBLE:
			n = snprintf(NULL, 0, "%f", value->bdb_vl_d);
			data->bdb_dt_cur_len += n;
		break;
		default:
			return -1;
			break;
	}
	data->bdb_dt_p = realloc(data->bdb_dt_p, data->bdb_dt_cur_len + data->bdb_dt_len);
	char tbuf[data->bdb_dt_cur_len];

	if (flag) {
		snprintf(tbuf, sizeof(tbuf), "%s:%s:%s", value->bdb_vl_colname, value->bdb_vl_type, value->bdb_vl_s);
	} else {
		if (*value->bdb_vl_type == BDB_COL_LONG)
			snprintf(tbuf, sizeof(tbuf), "%s:%s:%ld", value->bdb_vl_colname, value->bdb_vl_type, value->bdb_vl_l);
		else
			snprintf(tbuf, sizeof(tbuf), "%s:%s:%f", value->bdb_vl_colname, value->bdb_vl_type, value->bdb_vl_d);
	}
	char *p = data->bdb_dt_p + data->bdb_dt_len;
	char *t;
	BDB_COMPACT(tbuf);
	data->bdb_dt_len = data->bdb_dt_cur_len + data->bdb_dt_len;
	return 0;
}

char *bdb_mk_double_array(double val, char *str, size_t *size)
{
	int n = snprintf(NULL, 0, "%f", val);
	*size += n + 1;
	str = realloc(str, *size);
	if (str == NULL)
		return NULL;
	if ((*size - n) == 1)
		snprintf(str, *size, "%f", val);
	else
		snprintf(str, *size, "%s%s%f", str, BDB_ARRAY_DELIM, val);
	return str;
}

char *bdb_mk_long_array(long val, char *str, size_t *size)
{
	int n = snprintf(NULL, 0, "%ld", val);
	*size += n + 1;
	str = realloc(str, *size);
	if (str == NULL)
		return NULL;
	if ((*size - n) == 1)
		snprintf(str, *size, "%ld", val);
	else
		snprintf(str, *size, "%s%s%ld", str, BDB_ARRAY_DELIM, val);
	return str;
}
char *bdb_mk_string_array(char * val, char *str, size_t *size)
{
	size_t n = strlen(val);
	*size += n + 1;
	str = realloc(str, *size);
	if (str == NULL)
		return NULL;
	if ((*size - n) == 1)
		snprintf(str, *size, "%s", val);
	else
		snprintf(str, *size, "%s%s%s", str, BDB_ARRAY_DELIM, val);
	return str;
}

void bdb_trunc(DB *dbp)
{
	DBT k, d;

    while (dbp->seq(dbp, &k, &d, R_NEXT) == 0) {
        if (strncmp(k.data, "bdb_", 4) == 0) {
            continue;
        }
        dbp->del(dbp, &k, 0);
    }
}

//clang -c -fpic bdb.c && clang -shared bdb.o -o libbdb.so