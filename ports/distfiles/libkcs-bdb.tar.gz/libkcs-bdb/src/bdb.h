#ifndef KCS_BDB_H
#define KCS_BDB_H

#include <sys/types.h>
#include <sys/param.h>
#include <sys/stat.h>

#include <arpa/inet.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <db.h>
#include <fcntl.h>
#include <limits.h>
#include <errno.h>

#define BDB_ARRAY_DELIM				","
#define BDB_TABLE_DIR			"/root/bdb"
#define BDB_KENV_PATH			"kcs.bdb.path"
#define BDB_EXPAND(e, k)		e = st; while( (*st++ = *k++) );
#define	BDB_COMPACT(e)		t = e; while ((*p++ = *t++)) ;;
#define BDB_EXTRACT(t, v, val)	v = p; \
			while (*p++) \
					; \
			t = strchr(v, ':'); \
			if (t != NULL) { \
				*t = '\0'; \
				t++; \
				val = strchr(t, ':'); \
				*val = '\0'; \
				val++; \
			}
#define BDB_FROM_SCALAR(e)	store = htonll((uint64_t)(e));      \
				memmove(p, &store, sizeof(store)); \
				p += sizeof(store);
#define BDB_TO_SCALAR(v)	memmove(&(v), p, sizeof(v)); \
				p += sizeof(v); \
				v = ntohll(v);

#define htonll(x) ((1==htonl(1)) ? (x) : ((uint64_t)htonl((x) & 0xFFFFFFFF) << 32) | htonl((x) >> 32))
#define ntohll(x) ((1==ntohl(1)) ? (x) : ((uint64_t)ntohl((x) & 0xFFFFFFFF) << 32) | ntohl((x) >> 32))


#define BDB_KEY_BYTE_MAX			128

#define BDB_COL_TYPE(col) (*col.bdb_vl_type)
#define BDB_COL_STRING			's'
#define BDB_COL_LONG			'l'
#define BDB_COL_DOUBLE			'd'
#define BDB_COL_ASTRING			'S'
#define BDB_COL_ALONG			'L'
#define BDB_COL_ADOUBLE			'D'
#define BDB_SCOL_STRING			"s"
#define BDB_SCOL_LONG			"l"
#define BDB_SCOL_DOUBLE			"d"
#define BDB_SCOL_ASTRING		"S"
#define BDB_SCOL_ALONG			"L"
#define BDB_SCOL_ADOUBLE		"D"
#define BDB_POS_NEXT			R_NEXT
#define BDB_POS_LAST			R_LAST
#define BDB_COLNAME_MAX_LEN		32
typedef struct bdb_column {
	char col_name[BDB_COLNAME_MAX_LEN + 1];
	char type[2];
} bdb_column_t;

typedef struct bdb_data {
	char *bdb_dt_schema;
	char *bdb_dt_p;
	long long bdb_dt_key;
	size_t bdb_dt_len;
	size_t bdb_dt_cur_len;
	size_t bdb_dt_schema_len;
} bdb_data_t;

typedef struct bdb_value {
	char *bdb_vl_colname;
	char *bdb_vl_type;
	union {
		char *us_value;
		long ul_value;
		double ud_value;
	} u_value;
#define bdb_vl_s	u_value.us_value
#define bdb_vl_l	u_value.ul_value
#define bdb_vl_d	u_value.ud_value
} bdb_value_t;

DB *bdb_open(char *dbname, char *path);
DB *bdb_create(char *dbname, char *path);
int bdb_close(DB *dbp);
int bdb_set(DB *dbp, bdb_data_t *data);
int bdb_del(DB *dbp, long long key);

bdb_data_t *bdb_get(DB *dbp, long long key);
bdb_data_t *bdb_seq(DB *dbp, int pos);
char *bdb_get_schema(DB *dbp, size_t *size);
int bdb_key_exist(DB *dbp, long long key);
int bdb_parse_next(bdb_data_t *data, bdb_value_t *value);
bdb_column_t *bdb_get_next_col(bdb_data_t *data);
int bdb_add_next(bdb_data_t *data, bdb_value_t *value);
char *bdb_mk_double_array(double val, char *str, size_t *size);
char *bdb_mk_long_array(long val, char *str, size_t *size);
char *bdb_mk_string_array(char * val, char *str, size_t *size);
int bdb_freeget(void *data);
int bdb_copy(char *dir, char *oldname, char *newname);
void bdb_trunc(DB *dbp);

#endif // KCS_BDB_H