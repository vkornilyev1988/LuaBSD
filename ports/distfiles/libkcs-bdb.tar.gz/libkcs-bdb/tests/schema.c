#include <bdb.h>

#define EXTRACT(t, v)	v = p; \
			t = strchr(v, ':'); \
			if (t != NULL) { \
				*t = '\0'; \
				t++; \
				while (*p++) \
					; \
			}

#define EXPAND(e) e=t; while( (*t++ = *p++) );

void usage(void)
{
	printf("schema dir name\ndir\t- directory where to search db\nname\t- db name");
}

int main(int ac, char *av[])
{

	if (ac != 3)
		usage();

	DB *dbp = bdb_open(av[2], av[1]);
	if (dbp == NULL) {
		printf("db open failed\n");
		return (1);
	}
	size_t size;
	char *schema = bdb_get_schema(dbp, &size);

	if (schema == NULL) {
		printf("get schema failed\n");
		bdb_close(dbp);
		return (1);
	}
	bdb_close(dbp);
	char buf[70];
	char *col, *t = buf;
	char *p = schema;
	size_t len = size;
	char *kek[4];
	int i = 0;
	while (len != 0) {
		EXPAND(kek[i]);
//		printf("%s\n", kek[i]);
		if ((col = strchr(kek[i], ':')) != NULL) {
			len = len - strlen(kek[i]) - 1;
			*col = '\0';
			col++;
			printf("type=%s\tcol_name=%s\n", col, kek[i]);
		}
		i++;
	}
	return (0);
}
