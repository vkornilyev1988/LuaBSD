#include <bdb.h>
#define COLOR_RESET   "\033[0m"
#define COLOR_BOLD   "\033[1m"
#define STYLE_UNDERLINE    "\033[4m"
#define STYLE_NO_UNDERLINE "\033[24m"
#define	COMPACT(e)	t = e; while ((*p++ = *t++));

static void
usage(void)
{
	printf(COLOR_BOLD "bdb create" COLOR_RESET " "STYLE_UNDERLINE"dir" STYLE_NO_UNDERLINE" "STYLE_UNDERLINE "name" STYLE_NO_UNDERLINE" create_params\n"
		   COLOR_BOLD "bdb schema" COLOR_RESET " "STYLE_UNDERLINE"dir" STYLE_NO_UNDERLINE" "STYLE_UNDERLINE "name" STYLE_NO_UNDERLINE "\n"
		   COLOR_BOLD "bdb set" COLOR_RESET " "STYLE_UNDERLINE"dir" STYLE_NO_UNDERLINE" "STYLE_UNDERLINE "name" STYLE_NO_UNDERLINE " key set_params\n"
		   COLOR_BOLD "bdb get" COLOR_RESET " "STYLE_UNDERLINE"dir" STYLE_NO_UNDERLINE" "STYLE_UNDERLINE "name" STYLE_NO_UNDERLINE " [key]\n"
		   COLOR_BOLD "bdb del" COLOR_RESET " "STYLE_UNDERLINE"dir" STYLE_NO_UNDERLINE" "STYLE_UNDERLINE "name" STYLE_NO_UNDERLINE " key\n"
	       "   dir\t- directory where to create db\n"
	       "   name\t- db name\n"
	       "   col_name max len is 32 symbols\n"
	       "   create params:\n"
	       "       -s col_name\t- string column\n"
	       "       -l col_name\t- long column\n"
	       "       -d col_name\t- double column\n"
	       "       -S col_name\t- strings array column\n"
	       "       -L col_name\t- longs array column\n"
	       "       -D col_name\t- doubles array column\n"
	       "   set params:\n"
	       "       -s col_name:value\t- string column\n"
	       "       -l col_name:value\t- long column\n"
	       "       -d col_name:value\t- double column\n"
	       "       -S col_name:value\t- strings array column\n"
	       "       -L col_name:value\t- longs array column\n"
	       "       -D col_name:value\t- doubles array column\n"
	);
	exit(1);
}

static void
del_db(int ac, char *av[])
{
	if (ac != 3)
		usage();

	DB *dbp = bdb_open(av[1], av[0]);
	if (dbp == NULL) {
		printf("%s\n", "failed to open db");
		return;
	}

	long key = strtol(av[2], NULL, 10);
	if (key == 0) {
		printf("%s\n", "key must be long number");
		bdb_close(dbp);
		return;
	}

	int ret = bdb_del(dbp, key);
	if (ret)
		printf("%s\n", "failed to delete value\n");

	bdb_close(dbp);
}

static void
get_db(int ac, char *av[])
{
	if (ac < 2 || ac > 3)
		usage();

	DB *dbp = bdb_open(av[1], av[0]);
	if (dbp == NULL) {
		printf("%s\n", "failed to open db");
		return;
	}

	bdb_data_t *data;
	if (ac == 2) {
		while ((data = bdb_seq(dbp, BDB_POS_NEXT)) != NULL) {
			int ret = 0;
			bdb_value_t value;
			memset(&value, 0, sizeof(bdb_value_t));
			printf("%ld\t", data->bdb_dt_key);
			while ((ret = bdb_parse_next(data, &value)) == 0) {
				if (BDB_COL_TYPE(value) == BDB_COL_LONG) {
					printf("%ld (%s:%s)\t", value.bdb_vl_l, value.bdb_vl_colname, value.bdb_vl_type);
				} else if (BDB_COL_TYPE(value) == BDB_COL_DOUBLE) {
					printf("%f (%s:%s)\t", value.bdb_vl_d, value.bdb_vl_colname, value.bdb_vl_type);
				} else {
					printf("%s (%s:%s)\t", value.bdb_vl_s, value.bdb_vl_colname, value.bdb_vl_type);
				}
			}
			printf("\n");
		}
	} else if (ac == 3) {
		if ((data = bdb_get(dbp, strtol(av[2], NULL, 10))) != NULL) {
			int ret = 0;
			bdb_value_t value;
			printf("%ld\t", strtol(av[2], NULL, 10));
			while ((ret = bdb_parse_next(data, &value)) == 0) {
				if (BDB_COL_TYPE(value) == BDB_COL_LONG) {
					printf("%ld (%s:%s)\t", value.bdb_vl_l, value.bdb_vl_colname, value.bdb_vl_type);
				} else if (BDB_COL_TYPE(value) == BDB_COL_DOUBLE) {
					printf("%f (%s:%s)\t", value.bdb_vl_d, value.bdb_vl_colname, value.bdb_vl_type);
				} else {
					printf("%s (%s:%s)\t", value.bdb_vl_s, value.bdb_vl_colname, value.bdb_vl_type);
				}
			}
			printf("\n");
		}
	}

	bdb_close(dbp);
}

static void
add_db(int ac, char *av[])
{
	if (ac < 5)
		usage();

	DB *dbp = bdb_open(av[1], av[0]);
	if (dbp == NULL) {
		printf("failed to open db\n");
		return;
	}

	bdb_data_t data;
	memset(&data, 0, sizeof(bdb_data_t));
	data.bdb_dt_schema = bdb_get_schema(dbp, &data.bdb_dt_schema_len);
	if (data.bdb_dt_schema == NULL) {
		printf("%s\n", "failed to get schema\n");
		bdb_close(dbp);
		return;
	}

	data.bdb_dt_key = strtol(av[2], NULL, 10);
	if (data.bdb_dt_key < 0)
		usage();
	ac -= 2;
	av += 2;
	char type[2];
	bdb_value_t value;
	char *ch;
	char c;
	while ((c = getopt(ac, av, "s:S:l:L:d:D:")) != -1) {
		switch(c) {
		case 'S':
		case 'L':
		case 'D':
		case 's':
			memset(&value, 0, sizeof(bdb_value_t));
			snprintf(type, sizeof(type), "%c", c);
			value.bdb_vl_type = type;
			if ((ch = strchr(optarg, ':')) == NULL) {
				goto erruse;
			}
			*ch = '\0';
			ch++;
			value.bdb_vl_colname = optarg;
			value.bdb_vl_s = ch;
			if (bdb_add_next(&data, &value)) {
				printf("%s, %s\n", "failed to parse value", "check schema and your values");
				goto out;
			}
			break;
		case 'l':
			memset(&value, 0, sizeof(bdb_value_t));
			snprintf(type, sizeof(type), "%c", c);
			value.bdb_vl_type = type;
			if ((ch = strchr(optarg, ':')) == NULL) {
				goto erruse;
			}
			*ch = '\0';
			ch++;
			value.bdb_vl_colname = optarg;
			value.bdb_vl_l = strtol(ch, NULL, 10);
			if (bdb_add_next(&data, &value)) {
				printf("%s, %s\n", "failed to parse value", "check schema and your values");
				goto out;
			}
			break;
		case 'd':
			memset(&value, 0, sizeof(bdb_value_t));
			snprintf(type, sizeof(type), "%c", c);
			value.bdb_vl_type = type;
			if ((ch = strchr(optarg, ':')) == NULL) {
				goto erruse;
			}
			*ch = '\0';
			ch++;
			value.bdb_vl_colname = optarg;
			value.bdb_vl_d = strtod(ch, NULL);
			if (bdb_add_next(&data, &value)) {
				printf("%s, %s\n", "failed to parse value", "check schema and your values");
				goto out;
			}
			break;
		}
	}

	if (bdb_set(dbp, &data)) {
		printf("%s\n", "failed to set value");
	}
	goto out;

erruse:
	if (data.bdb_dt_len)
		free(data.bdb_dt_p);
	bdb_close(dbp);
	usage();

out:
	if (data.bdb_dt_len)
		free(data.bdb_dt_p);
	bdb_close(dbp);
}

static void
schema_db(int ac, char *av[])
{
	if (ac != 2)
		usage();

	DB *dbp = bdb_open(av[1], av[0]);
	if (dbp == NULL) {
		printf("%s\n", "failed to open db");
		return;
	}

	size_t len;
	char *schema = bdb_get_schema(dbp, &len);
	if (schema == NULL) {
		printf("%s\n", "failed to get schema\n");
		return;
	}

	char *st, *col;
	char col_info[70];
	st = col_info;
	size_t cur = 0;
	while (cur < len) {
		BDB_EXPAND(col, schema);
		printf("%s\n", col);
		cur += strlen(col) + 1;
	}

	bdb_close(dbp);
}

static void
create_db(int ac, char *av[])
{
	char *dir = av[0];
	char *dbname = av[1];
	ac -= 1;
	av += 1;
	int c = 0;
	char schema[4096];
	char col[70];
	char *p = schema;
	char *t = NULL;
	int len = 0;
	while ((c = getopt(ac, av, "s:S:l:L:d:D:")) != -1) {
		switch(c) {
		case 's':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:s", optarg);
			COMPACT(col);
			break;
		case 'S':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:S", optarg);
			COMPACT(col);
			break;
		case 'l':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:l", optarg);
			COMPACT(col);
			break;
		case 'L':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:L", optarg);
			COMPACT(col);
			break;
		case 'd':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:d", optarg);
			COMPACT(col);
			break;
		case 'D':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:D", optarg);
			COMPACT(col);
			break;

		}
	}

	char fullpath[MAXPATHLEN + 1];
	snprintf(fullpath, sizeof(fullpath), "%s/%s.db", dir, dbname);
	DB *dbp = dbopen(fullpath, O_CREAT|O_RDWR|O_TRUNC, S_IRUSR|S_IWUSR, DB_BTREE, NULL);
	if (dbp == NULL) {
		printf("db create failed\n");
		return;
	}

	DBT key, data;
	key.data = "bdb_schema";
	key.size = strlen("bdb_schema") + 1;
	data.data = schema;
	data.size = p - schema;

	if (dbp->put(dbp, &key, &data, 0)) {
		printf("schema creating failed\n");
		return;
	}
	dbp->close(dbp);
}

int main(int ac, char *av[])
{
	if (ac < 2)
		usage();
	if (strcmp("schema", av[1]) == 0)
		schema_db(ac - 2, av + 2);
	else if (strcmp("delete", av[1]) == 0)
		del_db(ac - 2, av + 2);
	else if (strcmp("get", av[1]) == 0)
		get_db(ac - 2, av + 2);
	else if (strcmp("set", av[1]) == 0)
		add_db(ac - 2, av + 2);
	else if (strcmp("create", av[1]) == 0)
		create_db(ac - 2, av + 2);
	return (0);
}
