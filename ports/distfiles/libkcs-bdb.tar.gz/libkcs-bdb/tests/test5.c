#include <bdb.h>

int main(void)
{
	DB *dbp = bdb_open("kek", "/data/db");
	if (dbp == NULL) {
		printf("db open failed\n");
		return 1;
	}

	char *col = "name", *type = "s", *val = "kai";

	bdb_data_t data;
	memset(&data, 0, sizeof(bdb_data_t));
	data.bdb_dt_schema = bdb_get_schema(dbp, &data.bdb_dt_schema_len);
	bdb_value_t value;
	value.bdb_vl_colname = col;
	value.bdb_vl_type = type;
	value.bdb_vl_s = val;
	bdb_add_next(&data, &value);
	col = "age";
	type = "l";
	value.bdb_vl_colname = col;
	value.bdb_vl_type = type;
	value.bdb_vl_l = 26;
	bdb_add_next(&data, &value);
	col = "weight";
	type = "d";

	value.bdb_vl_colname = col;
	value.bdb_vl_type = type;
	value.bdb_vl_d = 73.4;
	bdb_add_next(&data, &value);
	col = "pets";
	type = "S";

	value.bdb_vl_colname = col;
	value.bdb_vl_type = type;
	value.bdb_vl_s = "luck,stevie";
	bdb_add_next(&data, &value);
	col = "pages";
	type = "L";

	value.bdb_vl_colname = col;
	value.bdb_vl_type = type;
	value.bdb_vl_s = "10,4";
	bdb_add_next(&data, &value);
	col = "pwght";
	type = "D";

	value.bdb_vl_colname = col;
	value.bdb_vl_type = type;
	value.bdb_vl_s = "8,4.3";
	bdb_add_next(&data, &value);
	data.bdb_dt_key = 17;
	bdb_set(dbp, &data);
	free(data.bdb_dt_p);
	bdb_close(dbp);

}
