#include <bdb.h>

int main(void)
{
	DB *dbp = bdb_open("kek", "/data/db");
	if (dbp == NULL) {
		printf("db open failed\n");
		return 1;
	}


	int ret = 0;
	bdb_data_t *data;
	while ((data = bdb_seq(dbp)) != NULL) {
		bdb_value_t value;
		printf("%ld\t", data->bdb_dt_key);
		memset(&value, 0, sizeof(bdb_value_t));
		while ((ret = bdb_parse_next(data, &value)) == 0) {
			if(BDB_COL_TYPE(value) == BDB_COL_STRING) {
					printf(" %s\t", value.bdb_vl_s);
			} else if (BDB_COL_TYPE(value) == BDB_COL_LONG) {
					printf(" %ld\t", value.bdb_vl_l);
			} else if (BDB_COL_TYPE(value) == BDB_COL_DOUBLE) {
					printf(" %.2f\t", value.bdb_vl_d);
			}
			if (ret) 
				break;
		}
		printf("\n");
		bdb_freeget(data);
	}

	if (ret == -1)
		printf("schema  is wrong\n");

	bdb_close(dbp);

}
