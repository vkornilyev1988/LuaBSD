#include <bdb.h>

int main(void)
{
	DB *dbp = bdb_open("kek", "/data/db");
	if (dbp == NULL) {
		printf("db open failed\n");
		return 1;
	}

	bdb_data_t data = malloc(sizeof(bdb_data_t));

	bdb_close(dbp);

}
