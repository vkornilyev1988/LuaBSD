#include <bdb.h>

int main(void)
{
	char *dbname = "coockie1";
	char *path = "/data/db";
	long key = 10001;
	DB *dbp;
	char *val;
	dbp = bdb_open(dbname, path);
	if (dbp == NULL)
		return 1;
	val = bdb_seq(dbp, key);

	if (val == NULL) {
		bdb_close(dbp);
	}
	printf("%s\n", val);
	bdb_freeget(val);
	bdb_close(dbp);
	dbp = bdb_open(dbname, path);
	if (dbp == NULL)
		return 1;
	val = bdb_seq(dbp, 999);

	if (val == NULL) {
		bdb_close(dbp);
	}
	printf("%s\n", val);
	bdb_freeget(val);
	bdb_close(dbp);
	key++;
	dbp = bdb_open(dbname, path);
	if (dbp == NULL)
		return 1;
	val = bdb_seq(dbp, key);

	if (val == NULL) {
		bdb_close(dbp);
	}
	printf("%s\n", val);
	bdb_freeget(val);
	bdb_close(dbp);
}
