#include <bdb.h>

int main(void)
{
	DB *dbp = bdb_open("kek", "/data/db");
	if (dbp == NULL) {
		printf("db open failed\n");
		return 1;
	}

	unsigned int rn = bdb_get_row_num(dbp);
	printf("row_num = %u\n", rn);
	bdb_close(dbp);

}
