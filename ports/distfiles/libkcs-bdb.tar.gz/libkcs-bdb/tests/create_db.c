#include <sys/types.h>
#include <sys/param.h>
#include <sys/stat.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <db.h>
#include <fcntl.h>
#include <limits.h>
#include <errno.h>

#define	COMPACT(e)	t = e; while ((*p++ = *t++));

void usage(void)
{
	printf("create_db dir name params\n"
	       "dir\t- directory where to create db\n"
	       "name\t- db name\n"
	       "params:\n"
	       "   -s col_name\t- string column\n"
	       "   -l col_name\t- long column\n"
	       "   -d col_name\t- double column\n"
	       "   -S col_name\t- strings array column\n"
	       "   -L col_name\t- longs array column\n"
	       "   -D col_name\t- doubles array column\n"
	       "col_name max len is 32 symbols\n"
	);
	exit(1);
}

int main(int ac, char *av[])
{
	if (ac < 5)
		usage();

	char *dir = av[1];
	char *dbname = av[2];
	ac -= 2;
	av += 2;
	int c = 0;
	char schema[4096];
	char col[70];
	char *p = schema;
	char *t = NULL;
	int len = 0;
	while ((c = getopt(ac, av, "s:S:l:L:d:D:")) != -1) {
		switch(c) {
		case 's':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:s", optarg);
			COMPACT(col);
			break;
		case 'S':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:S", optarg);
			COMPACT(col);
			break;
		case 'l':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:l", optarg);
			COMPACT(col);
			break;
		case 'L':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:L", optarg);
			COMPACT(col);
			break;
		case 'd':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:d", optarg);
			COMPACT(col);
			break;
		case 'D':
			if (strlen(optarg) > 64)
				usage();
			snprintf(col, sizeof(col), "%s:D", optarg);
			COMPACT(col);
			break;

		}
	}

	char fullpath[MAXPATHLEN + 1];
	snprintf(fullpath, sizeof(fullpath), "%s/%s.db", dir, dbname);
	DB *dbp = dbopen(fullpath, O_CREAT|O_RDWR, S_IRUSR|S_IWUSR, DB_BTREE, NULL);
	if (dbp == NULL) {
		printf("db create failed\n");
		return (1);
	}

	DBT key, data;
	key.data = "bdb_schema";
	key.size = strlen("bdb_schema") + 1;
	data.data = schema;
	data.size = p - schema;

	if (dbp->put(dbp, &key, &data, 0)) {
		printf("schema creating failed\n");
		return (1);
	}
	dbp->close(dbp);
	return (0);

}
