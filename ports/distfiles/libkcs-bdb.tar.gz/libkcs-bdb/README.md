DESCRIPTION
	libbdb - библиотека для работы с Berkeley Database BTREE. 

FUNCTIONS

	DB *
	bdb_open(char *dbname, char *path);
		описание:
			открыть соединение с бд
		возвращаемое значение:
			указатель BD * или NULL

	int bdb_close(DB *dbp);
		описание:
			закрыть соединение с бд
		возвращаемое значение:
			0 при успехе иначе -1

	int bdb_set(DB *dbp, bdb_data_t *data);
		описание:
			добавить/обновить значение в бд.
			typedef struct bdb_data {
				char *bdb_dt_schema;		/*схема таблицы*/
				char *bdb_dt_p;				/*указать на данные, содержит данные из вчех колонок текущей строки*/
				long bdb_dt_key;			/*ключ*/
				size_t bdb_dt_len;
				size_t bdb_dt_cur_len;
				size_t bdb_dt_schema_len;
			} bdb_data_t;
		возвращаемое значение:
			0 при успехе иначе -1

	int bdb_del(DB *dbp, long key);
		описание:
			удалить значение с ключом key
		возвращаемое значение:
			0 при успехе иначе -1

	bdb_data_t *bdb_get(DB *dbp, long key);
		описание:
			получить значение по ключу key. возващенный указатель должен быть освобожден функцией free
		возвращаемое значение:
			указатель bdb_data_t * или NULL, если значение отсутствует или возникла ошибка

	bdb_data_t *bdb_seq(DB *dbp, int pos);
		описание:
			получить следующее значение или поледнее в зависимости от параметра pos. возвращенный указатель должен быть освобожден функцией free
			pos:
				BDB_POS_NEXT
				BDB_POS_LAST
		возвращаемое значение:
			указатель BD * или NULL

	char *bdb_get_schema(DB *dbp, size_t *size);
		описание:
			получить схему текущей таблицы. в параметр size будет записан размер строки, возвращенный указатель должен быть освобожден функцией free
		возвращаемое значение:
			указатель на строку со схемой или NULL

	int bdb_key_exist(DB *dbp, long key);
		описание:
			проверить чуществует ли ключ key в бд
		возвращаемое значение:
			0 если ключ не найден иначе 1

	int bdb_parse_next(bdb_data_t *data, bdb_value_t *value);
		описание:
			получить значение из следующей колонки data->bdb_dt_p. данные будут записаны в структуру bdb_value_t. в структуре bdb_data_t должна быть записана схема (data->bdb_dt_schema)
			typedef struct bdb_value {
				char *bdb_vl_colname;		/*имя колонки*/
				char *bdb_vl_type;			/*тип колонки*/
				union {
					char *us_value;			/*хранит значения типов BDB_SCOL_STRING, BDB_SCOL_ASTRING, BDB_SCOL_ALONG, BDB_SCOL_ADOUBLE*/
					long ul_value;			/*хранит значения типа BDB_SCOL_LONG*/
					double ud_value;		/*хранит значения типа BDB_SCOL_DOUBLE*/
				} u_value;					/*значение колонки, в зависимости от типа*/
			#define bdb_vl_s	u_value.us_value
			#define bdb_vl_l	u_value.ul_value
			#define bdb_vl_d	u_value.ud_value
			} bdb_value_t;
			типы колонок:
				BDB_SCOL_STRING - строка
				BDB_SCOL_LONG - целочисленное
				BDB_SCOL_DOUBLE - с плавающей
				BDB_SCOL_ASTRING - массив строк
				BDB_SCOL_ALONG - массив целочисленных
				BDB_SCOL_ADOUBLE - массив с плавающей
		возвращаемое значение:
			0 при успехе иначе -1

	int bdb_add_next(bdb_data_t *data, bdb_value_t *value);
		описание:
			добавить значение в следующую колонку.
		возвращаемое значение:
			0 при успехе иначе -1

	char *bdb_mk_double_array(double val, char *str, size_t *size);
		описание:
			создать "массив" из чисел с плавающей. значение val будет добавлено в строку str, size будет увеличен на новое значение размера str.
			после использования str необходимо освободить функцией free
		возвращаемое значение:
			возвращает указатель на строку с записанным значением val или NULL

	char *bdb_mk_long_array(long val, char *str, size_t *size);
		описание:
			создать "массив" из целочисленных. значение val будет добавлено в строку str, size будет увеличен на новое значение размера str.
			после использования str необходимо освободить функцией free
		возвращаемое значение:
			возвращает указатель на строку с записанным значением val или NULL

	char *bdb_mk_string_array(char * val, char *str, size_t *size);
		описание:
			создать "массив" из строк. значение val будет добавлено в строку str, size будет увеличен на новое значение размера str.
			после использования str необходимо освободить функцией free
		возвращаемое значение:
			возвращает указатель на строку с записанным значением val или NULL

	int bdb_copy(char *dir, char *oldname, char *newname);
		описание:
			создать копию таблицы oldname с именем newname.
		возвращаемое значение:
			0 при успехе иначе -1

	void bdb_trunc(DB *dbp);
		описание:
			очистить таблицу