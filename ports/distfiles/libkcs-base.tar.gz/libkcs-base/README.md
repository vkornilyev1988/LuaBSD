DESCRIPTION
  libbase.so - библиотека с базовыми функциями
