#ifndef KCS_BASE_H
#define KCS_BASE_H
#include <fcntl.h>

#define BASE_EXEC_MAX_ARGS				32

int base_execs(const char *cmd, const char *path_env);
int base_execl(const char *path, ...);
char *base_execs_out(const char *cmd, const char *path_env);
pid_t base_execl_nowait(const char *cmd, const char *path_env);

char *base_execs_path_out(char *path, const char *cmd, const char *path_env);
pid_t base_execl_path_nowait(char *path, const char *cmd, const char *path_env);


void parse_line(const char line[], char *av[], size_t size, int *ac, const char *delim);
void parse_line_from(const char line[], char *av[], size_t size, int *ac, const char *delim, int from);
void parse_line_quoted(char *line, char *av[], int size, int *ac, char *delim);


#endif // KCS_BASE_H