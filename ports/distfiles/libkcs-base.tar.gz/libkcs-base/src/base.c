#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include "base.h"


int base_execs(const char *cmd, const char *path_env)
{
	int ret = 0;
	pid_t pid = fork();
	if (pid == 0) {
		char *list[BASE_EXEC_MAX_ARGS];
		int list_count;
		char cmd2[strlen(cmd) + 1];
		snprintf(cmd2, sizeof(cmd2), "%s", cmd);
		parse_line(cmd2, list, BASE_EXEC_MAX_ARGS - 1, &list_count, " ");
		execvp(list[0], list);
		_exit(-1);
	} else if (pid < 0) {
		ret = -1;
	} else {
		int status;
		if (waitpid(pid, &status, 0) < 0)
			ret = -1;
		if (status)
			ret = -1;
	}

	return ret;
}

int
base_execl(const char *path, ...)
{
	va_list argptr;
	va_start(argptr, path);
	int ret = 0;
	pid_t pid = fork();
	if (pid == 0) {
	    char *args[BASE_EXEC_MAX_ARGS];
	    int argno = 0;
	    char *arg = NULL;
	    while ((arg = (char *)va_arg(argptr, char *)) != NULL && argno < BASE_EXEC_MAX_ARGS - 1) {
	    	args[argno++] = arg;
	    }
	    args[argno] = NULL;
		va_end(argptr);
		execvp(path, args);
		_exit(-1);
	} else if (pid < 0) {
		ret = -1;
	} else {
		int status;
		if (waitpid(pid, &status, 0) < 0)
			ret = -1;
		if (status)
			ret = -1;
	}

	va_end(argptr);
	return ret;
}

pid_t base_execl_nowait(const char *cmd, const char *path_env)
{
	if (path_env != NULL)
		setenv("PATH", path_env, 1);

	int ret = 0;
    signal(SIGCHLD,SIG_IGN);
    signal(SIGHUP,SIG_IGN);
	pid_t spid = 0;
	int io[2];
    if (pipe(io) == -1) {
    	return -1;
    }
	pid_t pid = fork();
    if (pid == -1) {
        close(io[1]);
        close(io[0]);
    	return -1;
    } else if (pid == 0) {
		char *list[BASE_EXEC_MAX_ARGS];
		int list_count;
		char cmd2[strlen(cmd) + 1];
		snprintf(cmd2, sizeof(cmd2), "%s", cmd);
		parse_line(cmd2, list, BASE_EXEC_MAX_ARGS - 1, &list_count, " ");

		list[list_count] = NULL;
		while ((dup2(io[1], STDOUT_FILENO) == -1) && (errno == EINTR)) {}

        close(io[0]);
	    signal(SIGCHLD,SIG_IGN);
	    signal(SIGHUP,SIG_IGN);

	    pid_t child = fork();
	    if (child == 0) {
			execvp(list[0], list);
			_exit(-1);
	    } else {
	    	write(io[1],&child,sizeof(child));
		    printf("%d", child);
	    	_exit(-1);
	    }
	} else if (pid > 0) {
		close(io[1]);
		read(io[0],&spid,sizeof(pid_t));
	}
	close(io[0]);
	return spid;
}

char *base_execs_out(const char *cmd, const char *path_env)
{
	char *res = NULL;

	if (path_env != NULL)
		setenv("PATH", path_env, 1);

	char *list[BASE_EXEC_MAX_ARGS];
	int list_count;
	char cmd2[strlen(cmd) + 1];
	snprintf(cmd2, sizeof(cmd2), "%s", cmd);
	parse_line(cmd2, list, BASE_EXEC_MAX_ARGS - 1, &list_count, " ");
	list[list_count] = NULL;
	int filedes[2];
    if (pipe(filedes) == -1) {
    	return NULL;
    }
    pid_t pid = fork();
    if (pid == -1) {
        close(filedes[1]);
        close(filedes[0]);
    	return NULL;
    } else if (pid == 0) {
		while ((dup2(filedes[1], STDOUT_FILENO) == -1) && (errno == EINTR)) {}
        close(filedes[1]);
        close(filedes[0]);
        execvp(list[0], list);
        perror("execv");
        _exit(1);
    }
    close(filedes[1]);
    char buffer[_POSIX_ARG_MAX];
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        ssize_t count = read(filedes[0], buffer, sizeof(buffer));
        if (count == -1) {
            if (errno == EINTR) {
                continue;
            } else {
			    close(filedes[0]);
		    	return NULL;
            }
        } else if (count == 0) {
            break;
        } else {
            res = buffer;
            close(filedes[0]);
            return res;
        }
    }
    close(filedes[0]);
    return res;
}

char *base_execs_path_out(char *path, const char *cmd, const char *path_env)
{
	if (path_env != NULL)
		setenv("PATH", path_env, 1);
	char *res = NULL;

	char *list[BASE_EXEC_MAX_ARGS];
	int list_count;
	
	char cmd2[strlen(cmd) + 1];
	snprintf(cmd2, sizeof(cmd2), "%s", cmd);
	list[0] = path;
	parse_line_from(cmd2, list, BASE_EXEC_MAX_ARGS - 1, &list_count, " ", 1);

	list[list_count] = NULL;
	int filedes[2];
    if (pipe(filedes) == -1) {
    	return NULL;
    }
    pid_t pid = fork();
    if (pid == -1) {
        close(filedes[1]);
        close(filedes[0]);
    	return NULL;
    } else if (pid == 0) {
		while ((dup2(filedes[1], STDOUT_FILENO) == -1) && (errno == EINTR)) {}
        close(filedes[1]);
        close(filedes[0]);
        execvp(list[0], list);
        perror("execv");
        _exit(1);
    }
    close(filedes[1]);
    char buffer[_POSIX_ARG_MAX];
    memset(buffer, 0, sizeof(buffer));
    while (1) {
        ssize_t count = read(filedes[0], buffer, sizeof(buffer));
        if (count == -1) {
            if (errno == EINTR) {
                continue;
            } else {
			    close(filedes[0]);
		    	return NULL;
            }
        } else if (count == 0) {
            break;
        } else {
            res = buffer;
            close(filedes[0]);
            return res;
        }
    }
    close(filedes[0]);
    return res;
}

pid_t base_execl_path_nowait(char *path, const char *cmd, const char *path_env)
{
	if (path_env != NULL)
		setenv("PATH", path_env, 1);
	int ret = 0;
	pid_t spid = 0;
	int io[2];
    if (pipe(io) == -1) {
    	return -1;
    }
	pid_t pid = fork();
	
    if (pid == -1) {
        close(io[1]);
        close(io[0]);
    	return -1;
    } else if (pid == 0) {
		char *list[BASE_EXEC_MAX_ARGS];
		int list_count;
		
		char cmd2[strlen(cmd) + 1];
		snprintf(cmd2, sizeof(cmd2), "%s", cmd);
		list[0] = path;
		parse_line_from(cmd2, list, BASE_EXEC_MAX_ARGS - 1, &list_count, " ", 1);

		list[list_count] = NULL;
		while ((dup2(io[1], STDOUT_FILENO) == -1) && (errno == EINTR)) {}

        close(io[0]);
	    signal(SIGCHLD,SIG_IGN);
	    signal(SIGHUP,SIG_IGN);

	    pid_t child = fork();
	    if (child == 0) {
			execvp(list[0], list);
			_exit(-1);
	    } else {
	    	write(io[1],&child,sizeof(child));
		    printf("%d", child);
	    	_exit(-1);
	    }
	} else {
		close(io[1]);
		read(io[0],&spid,sizeof(pid_t));
	}
	close(io[0]);
	return spid;
}


void parse_line(const char line[], char *av[], size_t size, int *ac, const char *delim)
{
    for (*ac = 0, av[0] = strtok((char *)line, delim);
        *ac < size - 1 && av[*ac];
        av[++(*ac)] = strtok(NULL, delim));
}

void parse_line_from(const char line[], char *av[], size_t size, int *ac, const char *delim, int from)
{
    for (*ac = from, av[from] = strtok((char *)line, delim);
        *ac < size - 1 && av[*ac];
        av[++(*ac)] = strtok(NULL, delim));
}

void parse_line_quoted(char *line, char *av[], int size, int *ac, char *delim)
{
        char *tmp = strtok(line, delim);
        int i = *ac;
        while (tmp != NULL && i < size) {
                if (*tmp == '"' || *tmp == '\'') {
                        av[i] = tmp + 1;
                        if ((tmp[strlen(tmp) - 1] != '"' && tmp[strlen(tmp) - 1] != '\'')) {
                                tmp[strlen(tmp)] = ' ';
                                while ((tmp = strtok(NULL, delim)) != NULL) {
                                        if ((tmp[strlen(tmp) - 1] != '"' && tmp[strlen(tmp) - 1] != '\'')) {
                                                tmp[strlen(tmp)] = ' ';
                                        } else {
                                                tmp[strlen(tmp) - 1] = '\0';
                                                break;
                                        }
                                }
                        } else {
                                tmp[strlen(tmp) - 1] = '\0';
                        }
                } else {
                        av[i] = tmp;
                }
                i++;
                tmp = strtok(NULL, delim);
        }
        *ac = i;
}
