#include <assert.h>
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <libgen.h>
#include <libintl.h>
#include <libuutil.h>
#include <libnvpair.h>
#include <locale.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include <unistd.h>
#include <fcntl.h>
#include <zone.h>
#include <grp.h>
#include <pwd.h>
#include <kenv.h>
#include <signal.h>
#include <sys/debug.h>
#include <sys/list.h>
#include <sys/mntent.h>
#include <sys/mnttab.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/fs/zfs.h>
#include <sys/types.h>
#include <time.h>
#include <err.h>
#include <jail.h>

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#include <libzfs.h>
#include <libzfs_core.h>
#include <zfs_prop.h>
#include <zfs_deleg.h>
#include <libuutil.h>

#include <libgeom.h>

#include "zfs_comutil.h"
#include "zfeature_common.h"
#include "kzfs.h"

#define ZPOOL_FUZZ                      (16 * 1024 * 1024)

#if defined(BSD113) || defined(BSD12)

typedef enum { OP_SHARE, OP_MOUNT } share_mount_op_t;

typedef struct share_mount_state {
    share_mount_op_t    sm_op;
    boolean_t   sm_verbose;
    int sm_flags;
    char    *sm_options;
    char    *sm_proto; /* only valid for OP_SHARE */
    pthread_mutex_t sm_lock; /* protects the remaining fields */
    uint_t  sm_total; /* number of filesystems to process */
    uint_t  sm_done; /* number of filesystems processed */
    int sm_status; /* -1 if any of the share/mount operations failed */
} share_mount_state_t;
typedef struct get_all_state {
    boolean_t   ga_verbose;
    get_all_cb_t    *ga_cbp;
} get_all_state_t;


#else
#define OP_SHARE    0x1
#define OP_MOUNT    0x2
#endif

typedef struct replication_level {
    char *zprl_type;
    uint64_t zprl_children;
    uint64_t zprl_parity;
} replication_level_t;

typedef struct destroy_cbdata {
    boolean_t   cb_first;
    boolean_t   cb_force;
    boolean_t   cb_recurse;
    boolean_t   cb_error;
    boolean_t   cb_doclones;
    zfs_handle_t    *cb_target;
    boolean_t   cb_defer_destroy;
    boolean_t   cb_verbose;
    boolean_t   cb_parsable;
    boolean_t   cb_dryrun;
    nvlist_t    *cb_nvl;
    nvlist_t    *cb_batchedsnaps;
    char        *cb_firstsnap;
    char        *cb_prevsnap;
    int64_t     cb_snapused;
    const char  *cb_snapspec;
    char        *cb_bookmark;
    libzfs_handle_t *g_zfs;
} destroy_cbdata_t;

typedef struct snap_cbdata {
    nvlist_t *sd_nvl;
    boolean_t sd_recursive;
    const char *sd_snapname;
} snap_cbdata_t;

typedef struct unshare_unmount_node {
    zfs_handle_t    *un_zhp;
    char        *un_mountp;
    uu_avl_node_t   un_avlnode;
} unshare_unmount_node_t;

typedef struct zpool_cb_data {
    kzfs_prop_list_t *proplist;
    void *  tmp;
} zpool_cb_data_t;

typedef struct callback_data {
    zfs_type_t      cb_types;
    kzfs_prop_list_t *proplist;
    // zprop_list_t        *cb_proplist;
    // uint8_t         cb_props_table[ZFS_NUM_PROPS];
    void *tmp;

} callback_data_t;
typedef struct scrub_cbdata {
    int cb_type;
    pool_scrub_cmd_t cb_scrub_cmd;
} scrub_cbdata_t;

typedef struct spare_cbdata {
    uint64_t    cb_guid;
    zpool_handle_t  *cb_zhp;
} spare_cbdata_t;

// typedef struct status_cbdata {
//     // int     cb_count;
//     // boolean_t   cb_verbose;
//     kzpool_status_t *cb_ret;
// } status_cbdata_t;






static int zfs_dataset_rb(const char *zname, long recursive);
static int destroy_callback(zfs_handle_t *zhp, void *data);
static int destroy_check_dependent(zfs_handle_t *zhp, void *data);
static int zfs_snapshot_cb(zfs_handle_t *zhp, void *arg);
static int zfs_snapshot_rb(const char *zname, const char *snapname, long recursive);
static int gather_snapshots(zfs_handle_t *zhp, void *arg);
static int snapshot_to_nvl_cb(zfs_handle_t *zhp, void *arg);
static int unshare_unmount_path(libzfs_handle_t *g_zfs, const char *path, int flags, boolean_t is_manual);
static int unshare_unmount_compare(const void *larg, const void *rarg, void *unused);
static int share_mount_one(zfs_handle_t *zhp, int op, int flags, char *protocol,
    boolean_t explicit, const char *options);

#ifdef BSD112
static void get_all_datasets(libzfs_handle_t *g_zfs, zfs_handle_t ***dslist, size_t *count);
#elif defined(BSD12) || defined(BSD113)
static void get_all_datasets(libzfs_handle_t *g_zfs, get_all_cb_t *cbp, boolean_t verbose);
static int share_mount_one_cb(zfs_handle_t *zhp, void *arg);
#endif

static int get_one_dataset(zfs_handle_t *zhp, void *data);
static int zfs_snap_callback(zfs_handle_t *zhp, void *data);
static int zfs_ds_callback(zfs_handle_t *zhp, void *data);
static boolean_t should_auto_mount(zfs_handle_t *zhp);
static int add_prop_list(const char *propname, char *propval, nvlist_t **props, boolean_t poolprop);
static int add_prop_list_default(const char *propname, char *propval, nvlist_t **props, boolean_t poolprop);
static boolean_t prop_list_contains_feature(nvlist_t *proplist);
static nvlist_t *make_root_vdev(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, int force, int check_rep,
    boolean_t replacing, boolean_t dryrun, zpool_boot_label_t boot_type,
    uint64_t boot_size, kzpool_dev_list_t *devs);
static nvlist_t *construct_spec(kzpool_dev_list_t *devs);
static boolean_t is_device_in_use(libzfs_handle_t *g_zfs, nvlist_t *config, nvlist_t *nv, boolean_t force,
    boolean_t replacing, boolean_t isspare);
static const char *is_grouping(const char *type, int *mindev, int *maxdev);
static int check_device(libzfs_handle_t *g_zfs, const char *name, boolean_t force, boolean_t isspare);
static boolean_t is_whole_disk(const char *arg);
static boolean_t is_spare(libzfs_handle_t *g_zfs, nvlist_t *config, const char *path);
static nvlist_t *make_leaf_vdev(const char *arg, uint64_t is_log);
static int check_file(libzfs_handle_t *g_zfs, const char *file, boolean_t force, boolean_t isspare);
static int check_replication(nvlist_t *config, nvlist_t *newroot);
static uint_t num_logs(nvlist_t *nv);
static replication_level_t *get_replication(nvlist_t *nvroot, boolean_t fatal);
static int zpool_attach_or_replace(const char *zpool_name, const char *old_dev, const char *new_dev, int force, int replacing);
static int zpool_scrub_callback(zpool_handle_t *zhp, void *data);
static boolean_t zpool_has_checkpoint(zpool_handle_t *zhp);
static nvlist_t *split_mirror_vdev(zpool_handle_t *zhp, const char *newname, nvlist_t *props,
    splitflags_t flags, kzpool_dev_info_t *devs);
static int zpool_callback(zpool_handle_t *zhp, void *data);
static void zpool_devs_list(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t *nv, kzpool_dev_list_t **list);
static void zpool_devs_list_grouping(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t *nv,
        char *name, int islog, kzpool_dev_info_t **info);
static int zpool_status_callback(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, void *data);
static void zpool_get_scan_status(pool_scan_stat_t *ps, char **scan_status);
static void zpool_get_checkpoint_scan_warning(pool_scan_stat_t *ps, pool_checkpoint_stat_t *pcs, char **item);
static void zpool_get_removal_status(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, pool_removal_stat_t *prs, char **rm_st);
static void zpool_get_checkpoint_status(pool_checkpoint_stat_t *pcs, char **checkpoint);
static void zpool_get_status_config(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, const char *name, nvlist_t *nv,
    int depth, boolean_t isspare, kzpool_status_config_t **config);
static int find_spare(zpool_handle_t *zhp, void *data);
static boolean_t find_vdev(nvlist_t *nv, uint64_t search);
static void zpool_get_logs_status(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t *nv, kzpool_status_config_t **logs);
static void zpool_get_l2cache(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t **l2cache,
    uint_t nl2cache, kzpool_status_config_t **cache);
static void zpool_get_spares(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t **spares, uint_t nspares, kzpool_status_config_t **spares_cfg);
static char *zpool_get_error_log(zpool_handle_t *zhp);
static void fill_import_info(libzfs_handle_t *g_zfs, nvlist_t *config, kzpool_import_info_t *import_info);
static void zpool_get_import_config(libzfs_handle_t *g_zfs, const char *name, nvlist_t *nv, int depth, kzpool_import_config_t **config);
static void zpool_get_logs(libzfs_handle_t *g_zfs, nvlist_t *nv, kzpool_import_config_t **logs);
static int do_import(libzfs_handle_t *g_zfs, nvlist_t *config, const char *newname, const char *mntopts,
    nvlist_t *props, int flags);










/* ZFS */

char *
kzfs_get_uprop(const char *dsname, const char *propname)
{
    char *strval;
    zfs_handle_t *zhp;
    libzfs_handle_t *g_zfs_l;
    char *source = NULL;
    nvlist_t *userprops, *propval;

    if ((g_zfs_l = libzfs_init()) == NULL) {
        return NULL;
    }

    if ((zhp = zfs_open(g_zfs_l, dsname, ZFS_TYPE_DATASET)) == NULL) {
        libzfs_fini(g_zfs_l);
        return NULL;
    }
    userprops = zfs_get_user_props(zhp);
    
    if (nvlist_lookup_nvlist(userprops, propname,
        &propval) == 0) {
            if (nvlist_lookup_string(propval, ZPROP_VALUE, &source) != 0) {
                zfs_close(zhp);
                libzfs_fini(g_zfs_l);
                return NULL;
            }
            strval = fnvlist_lookup_string(propval, ZPROP_VALUE);
            (void) nvlist_lookup_string(propval, ZPROP_SOURCE, &source);
    } else {
        zfs_close(zhp);
        libzfs_fini(g_zfs_l);
        return NULL;
    }
    zfs_close(zhp);
    libzfs_fini(g_zfs_l);
    if (strlen(strval) == 0)
        return NULL;
    return strval;
}

int
kzfs_del_uprop(const char *dsname, const char *propname)
{
    libzfs_handle_t *g_zfs_l;
    zfs_handle_t *zhp;

    if ((g_zfs_l = libzfs_init()) == NULL) {
        return  -1;
    }

    if ((zhp = zfs_open(g_zfs_l, dsname, ZFS_TYPE_DATASET)) == NULL) {
        libzfs_fini(g_zfs_l);
        return -1;
    }
    int ret = zfs_prop_inherit(zhp, propname, B_FALSE);

    zfs_close(zhp);
    libzfs_fini(g_zfs_l);
    return ret;
}

int
kzfs_set_uprop(const char *dsname, const char *propname, const char *propval)
{
    libzfs_handle_t *g_zfs_l;
    zfs_handle_t *zhp;
    nvlist_t *props = NULL;

    if ((g_zfs_l = libzfs_init()) == NULL) {
        libzfs_fini(g_zfs_l);
        return -1;
    }

    if ((zhp = zfs_open(g_zfs_l, dsname, ZFS_TYPE_DATASET)) == NULL) {
        libzfs_fini(g_zfs_l);
        return -1;
    }


    if (nvlist_alloc(&props, NV_UNIQUE_NAME, 0) != 0) {
        zfs_close(zhp);
        libzfs_fini(g_zfs_l);
        return -1;
    }

    if (nvlist_add_string(props, propname, propval) != 0) {
        nvlist_free(props);
        zfs_close(zhp);
        libzfs_fini(g_zfs_l);
        return -1;
    }

    int ret;
    if ((ret = zfs_prop_set_list(zhp, props)) != 0) {
        nvlist_free(props);
        zfs_close(zhp);
        libzfs_fini(g_zfs_l);
        return -1;
    }
    nvlist_free(props);
    zfs_close(zhp);
    libzfs_fini(g_zfs_l);
    return 0;
}

int kzfs_ds_destroy(const char *zname, int recursive)
{
    return zfs_dataset_rb(zname, recursive);
}

int kzfs_snap_create(const char *zname, const char *snapname, const char *desc, int recursive)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    nvlist_t *props;
    snap_cbdata_t sd = { 0 };
    if (nvlist_alloc(&props, NV_UNIQUE_NAME, 0) != 0) {
        libzfs_fini(g_zfs);
        return -1;
    }
    if (nvlist_alloc(&sd.sd_nvl, NV_UNIQUE_NAME, 0) != 0) {
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }
    sd.sd_recursive = recursive;
    sd.sd_snapname = snapname;
    zfs_handle_t *zhp;
    zhp = zfs_open(g_zfs, zname, ZFS_TYPE_FILESYSTEM | ZFS_TYPE_VOLUME);
    if (zhp == NULL) {
        nvlist_free(sd.sd_nvl);
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }
    if (zfs_snapshot_cb(zhp, &sd) != 0) {
        nvlist_free(sd.sd_nvl);
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }
    nvlist_add_string(props, "snap:desc", desc);
    int ret = zfs_snapshot_nvl(g_zfs, sd.sd_nvl, props);
    nvlist_free(sd.sd_nvl);
    nvlist_free(props);

    libzfs_mnttab_cache(g_zfs, B_FALSE);
    libzfs_fini(g_zfs);

    return 0;
}

int kzfs_snap_destroy(const char *zname, const char *snapname, int recursive)
{
    return zfs_snapshot_rb(zname, snapname, recursive);
}

int kzfs_snap_rollback(const char *zname, const char *snapname)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    char snap[strlen(zname) + strlen(snapname) + 2];
    snprintf(snap, sizeof(snap), "%s@%s", zname, snapname);

    zfs_handle_t *zhp_snap = zfs_open(g_zfs, snap,
        ZFS_TYPE_SNAPSHOT);
    if (zhp_snap == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }
    zfs_handle_t *zhp = zfs_open(g_zfs, zname,
        ZFS_TYPE_FILESYSTEM);
    if (zhp == NULL) {
        zfs_close(zhp_snap);
        libzfs_fini(g_zfs);
        return -1;
    }

    int ret = zfs_rollback(zhp, zhp_snap, B_TRUE);


    zfs_close(zhp_snap);
    zfs_close(zhp);
    libzfs_fini(g_zfs);

    return ret;
}

int kzfs_send(const char *zname, const char *remote_ip, long remote_port, int move)
{
    libzfs_handle_t *g_zfs;
    
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    nvlist_t *props;
    snap_cbdata_t sd = { 0 };
    sd.sd_recursive = B_TRUE;
    if (nvlist_alloc(&props, NV_UNIQUE_NAME, 0) != 0) {
        libzfs_fini(g_zfs);
        return -1;
    }
    if (nvlist_alloc(&sd.sd_nvl, NV_UNIQUE_NAME, 0) != 0) {
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }
    zfs_handle_t *zhp;
    zhp = zfs_open(g_zfs, zname,
        ZFS_TYPE_FILESYSTEM | ZFS_TYPE_VOLUME);
    if (zhp == NULL) {
        nvlist_free(sd.sd_nvl);
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }
    sd.sd_snapname = "migrate";
    if (zfs_snapshot_cb(zhp, &sd) != 0) {
        nvlist_free(sd.sd_nvl);
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }
    int ret = zfs_snapshot_nvl(g_zfs, sd.sd_nvl, props);

    nvlist_free(sd.sd_nvl);
    nvlist_free(props);

    zhp = zfs_open(g_zfs, zname,
        ZFS_TYPE_FILESYSTEM | ZFS_TYPE_VOLUME);
    sendflags_t flags = { 0 };
    flags.replicate = B_TRUE;
    flags.doall = B_TRUE;

    int s;
    struct sockaddr_in servaddr, cli;
  
    s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == -1) {
        return -1;
    }
    bzero(&servaddr, sizeof(servaddr));

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr(remote_ip);
    servaddr.sin_port = htons(remote_port);

    if (connect(s, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0) {
        close(s);
        return -1;
    }

    int err = zfs_send(zhp, NULL, "migrate", &flags, s, NULL, 0,
        NULL);
    zfs_close(zhp);
    libzfs_fini(g_zfs);
    close(s);
    zfs_snapshot_rb(zname, "migrate", 1);
    if (move) {
        zfs_dataset_rb(zname, 1);
    }

    if (err)
        return -1;
    return 0;
}

int kzfs_recv(const char *zname, const char *local_ip, long local_port)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    nvlist_t *props;
    nvpair_t *nvp = NULL;
    recvflags_t flags = { 0 };
    flags.force = B_TRUE;

    if (nvlist_alloc(&props, NV_UNIQUE_NAME, 0) != 0) {
        libzfs_fini(g_zfs);
        return -1;
    }

    while ((nvp = nvlist_next_nvpair(props, nvp))) {
        if (strcmp(nvpair_name(nvp), "origin") != 0) {
            nvlist_free(props);
            libzfs_fini(g_zfs);
            return -1;
        }
    }

    int sockfd, connfd;
    unsigned int len; 
    struct sockaddr_in servaddr, cli; 
  
    sockfd = socket(AF_INET, SOCK_STREAM, 0); 
    if (sockfd == -1) { 
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    } 
    int reuse = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse)) < 0) {
        close(sockfd);
        return -1;
    }
#ifdef SO_REUSEPORT
    if (setsockopt(sockfd, SOL_SOCKET, SO_REUSEPORT, (const char*)&reuse, sizeof(reuse)) < 0) {
        close(sockfd);
        return -1;
    }
#endif
    bzero(&servaddr, sizeof(servaddr)); 
  
    servaddr.sin_family = AF_INET; 
    servaddr.sin_addr.s_addr = inet_addr(local_ip);
    servaddr.sin_port = htons(local_port); 
  
    if ((bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr))) != 0) { 
        close(sockfd);
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    } 
  
    if ((listen(sockfd, 1)) != 0) { 
        close(sockfd);
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }
    len = sizeof(cli); 
  
    connfd = accept(sockfd, (struct sockaddr*)&cli, &len); 
    if (connfd < 0) {
        close(sockfd);
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }

    int err = zfs_receive(g_zfs, zname, props, &flags, connfd, NULL);
    nvlist_free(props);
    libzfs_fini(g_zfs);
    close(sockfd); 
    zfs_snapshot_rb(zname, "migrate", 1);

    if (err)
        return -1;
    return 0;
}

int kzfs_settings_merge(char *from, char *to)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    int ret = 0;
    char *at_f, *at_t;
    zfs_handle_t *zhp_f = NULL, *zhp_t = NULL;

    zfs_type_t type_f = ZFS_TYPE_DATASET, type_t = ZFS_TYPE_DATASET;
    if (strchr(from, '@') != NULL) {
        type_f = ZFS_TYPE_SNAPSHOT;
    }
    if (strchr(to, '@') != NULL) {
        type_t = ZFS_TYPE_SNAPSHOT;
    }

    if ((zhp_f = zfs_open(g_zfs, from, type_f)) == NULL) {
        ret = 1;
        goto out;
    }
    if ((zhp_t = zfs_open(g_zfs, to, type_t)) == NULL) {
        ret = 1;
        goto out;
    }

    nvlist_t *props_t = zfs_get_user_props(zhp_t);
    nvpair_t *nvp_t = NULL;

    while ((nvp_t = nvlist_next_nvpair(props_t, nvp_t)) != NULL) {
        const char *propname_t = nvpair_name(nvp_t);
        ret = zfs_prop_inherit(zhp_t, propname_t, B_FALSE);
    }

    nvlist_t *props_f = zfs_get_user_props(zhp_f);
    char *strval_f = NULL;
    nvpair_t *nvp_f = NULL;
    nvlist_t *nvlist_f = NULL;
    props_t = NULL;
    if ((ret = nvlist_alloc(&props_t, NV_UNIQUE_NAME, 0)) != 0) {
        goto out;
    }

    while ((nvp_f = nvlist_next_nvpair(props_f, nvp_f)) != NULL) {
        (void) nvpair_value_nvlist(nvp_f, &nvlist_f);
        nvpair_t *nvp = NULL;
        const char *propname_f = nvpair_name(nvp_f);
        while ((nvp = nvlist_next_nvpair(nvlist_f, nvp)) != NULL) {
        const char *name = nvpair_name(nvp);
        if (strcmp(name, "value") != 0)
            continue;
        (void) nvpair_value_string(nvp, &strval_f);
            if ((ret = nvlist_add_string(props_t, propname_f, strval_f)) != 0) {
                goto out;
            }
        }
    }
    if ((ret = zfs_prop_set_list(zhp_t, props_t)) != 0) {
        goto out;
    }
    
out:
    nvlist_free(props_t);
    if (zhp_t)
        zfs_close(zhp_t);
    if (zhp_f)
        zfs_close(zhp_f);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzfs_unmount(const char *entry, int force)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    int ret = 0;
    int flags = 0;

    if (force)
        flags = MS_FORCE;
    if (entry[0] == '/') {
        ret = unshare_unmount_path(g_zfs, entry, flags, B_FALSE);
        libzfs_fini(g_zfs);
        if (ret)
            return -1;
        return 0;
    }

    zfs_handle_t *zhp;
    char nfs_mnt_prop[ZFS_MAXPROPLEN];

    if ((zhp = zfs_open(g_zfs, entry,
        ZFS_TYPE_FILESYSTEM)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    ret = zfs_prop_get(zhp, ZFS_PROP_MOUNTPOINT,
        nfs_mnt_prop, sizeof (nfs_mnt_prop), NULL,
        NULL, 0, B_FALSE);
    if (ret) {
        zfs_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }

    if (strcmp(nfs_mnt_prop, "legacy") == 0) {
        ret = 1;
    } else if (!zfs_is_mounted(zhp, NULL)) {
        ret = 1;
    } else if (zfs_unmountall(zhp, flags) != 0) {
        ret = 1;
    }

    zfs_close(zhp);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzfs_unmount_all(int force)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0;
    int flags = 0;
    char nfs_mnt_prop[ZFS_MAXPROPLEN];
    char sharesmb[ZFS_MAXPROPLEN];
    if (force)
        flags = MS_FORCE;
    FILE *mnttab_file;

    if ((mnttab_file = fopen(MNTTAB, "r")) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    zfs_handle_t *zhp;
    struct mnttab entry;
    uu_avl_pool_t *pool;
    uu_avl_t *tree = NULL;
    unshare_unmount_node_t *node;
    uu_avl_index_t idx;
    uu_avl_walk_t *walk;

    if (((pool = uu_avl_pool_create("unmount_pool",
        sizeof (unshare_unmount_node_t),
        offsetof(unshare_unmount_node_t, un_avlnode),
        unshare_unmount_compare, UU_DEFAULT)) == NULL) ||
        ((tree = uu_avl_create(pool, NULL, UU_DEFAULT)) == NULL)) {
        ret = 1;
        goto out;
    }

    rewind(mnttab_file);
    while (getmntent(mnttab_file, &entry) == 0) {

        if (strcmp(entry.mnt_fstype, MNTTYPE_ZFS) != 0)
            continue;

        if (strchr(entry.mnt_special, '@') != NULL)
            continue;

        if ((zhp = zfs_open(g_zfs, entry.mnt_special,
            ZFS_TYPE_FILESYSTEM)) == NULL) {
            ret = 1;
            continue;
        }

        if (zpool_skip_pool(zfs_get_pool_name(zhp))) {
            zfs_close(zhp);
            continue;
        }

        ret = zfs_prop_get(zhp, ZFS_PROP_MOUNTPOINT,
                nfs_mnt_prop,
                sizeof (nfs_mnt_prop),
                NULL, NULL, 0, B_FALSE);
        if (ret) {
            zfs_close(zhp);
            fclose(mnttab_file);
            libzfs_fini(g_zfs);
            return -1;
        }
        if (strcmp(nfs_mnt_prop, "legacy") == 0)
            continue;
        if (zfs_prop_get_int(zhp, ZFS_PROP_CANMOUNT) ==
            ZFS_CANMOUNT_NOAUTO)
            continue;

        node = malloc(sizeof (unshare_unmount_node_t));
        node->un_zhp = zhp;
        node->un_mountp = strdup(entry.mnt_mountp);

        uu_avl_node_init(node, &node->un_avlnode, pool);

        if (uu_avl_find(tree, node, NULL, &idx) == NULL) {
            uu_avl_insert(tree, node, idx);
        } else {
            zfs_close(node->un_zhp);
            free(node->un_mountp);
            free(node);
        }
    }

    if ((walk = uu_avl_walk_start(tree,
        UU_WALK_REVERSE | UU_WALK_ROBUST)) == NULL) {
        ret = 1;
        goto out;
    }

    while ((node = uu_avl_walk_next(walk)) != NULL) {
        uu_avl_remove(tree, node);

        if (zfs_unmount(node->un_zhp,
            node->un_mountp, flags) != 0)
            ret = 1;
        zfs_close(node->un_zhp);
        free(node->un_mountp);
        free(node);
    }

    uu_avl_walk_end(walk);
    uu_avl_destroy(tree);
    uu_avl_pool_destroy(pool);

out:
    fclose(mnttab_file);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzfs_mount(const char *zname, const char *mntopts)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    zfs_handle_t *zhp;
    int flags = 0;
    int ret = 0;
    if ((zhp = zfs_open(g_zfs, zname,
        ZFS_TYPE_FILESYSTEM)) == NULL) {
        ret = 1;
    } else {
        ret = share_mount_one(zhp, OP_MOUNT, flags, NULL, B_TRUE,
            mntopts);
        zfs_close(zhp);
    }
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}


int kzfs_mount_all(const char *mntopts)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0;

    int flags = 0;

#ifdef BSD112
    zfs_handle_t **dslist = NULL;
    size_t i, count = 0;
    char *protocol = NULL;
    get_all_datasets(g_zfs, &dslist, &count);
    if (count == 0) {
        libzfs_fini(g_zfs);
        return 0;
    }
    qsort(dslist, count, sizeof (void *), libzfs_dataset_cmp);
    for (i = 0; i < count; i++) {
        if (share_mount_one(dslist[i], OP_MOUNT, flags, protocol,
            B_FALSE, mntopts) != 0)
            ret = 1;
        zfs_close(dslist[i]);
    }

    free(dslist);

#elif defined(BSD113) || defined(BSD12)
    get_all_cb_t cb = { 0 };
    get_all_datasets(g_zfs, &cb, B_FALSE);

    if (cb.cb_used == 0) {
        libzfs_fini(g_zfs);
        return 0;
    }

    share_mount_state_t share_mount_state = { 0 };
    share_mount_state.sm_op = OP_MOUNT;
    share_mount_state.sm_verbose = B_FALSE;
    share_mount_state.sm_flags = flags;
    share_mount_state.sm_options = (char *)mntopts;
    share_mount_state.sm_proto = NULL;
    share_mount_state.sm_total = cb.cb_used;
    pthread_mutex_init(&share_mount_state.sm_lock, NULL);

    zfs_foreach_mountpoint(g_zfs, cb.cb_handles, cb.cb_used,
        share_mount_one_cb, &share_mount_state, 1);
    ret = share_mount_state.sm_status;

    for (int i = 0; i < cb.cb_used; i++)
        zfs_close(cb.cb_handles[i]);
    free(cb.cb_handles);
#endif

    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

kzfs_snap_list_st_t *kzfs_snap_list(const char *zname)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return NULL;
    }
    callback_data_t cb = {0};

    cb.cb_types = ZFS_TYPE_SNAPSHOT;
    kzfs_snap_list_st_t *list = malloc(sizeof(kzfs_snap_list_st_t));
    if (list == NULL) {
        libzfs_fini(g_zfs);
        return NULL;
    }
    list->list = NULL;
    list->count = 0;
    cb.tmp = list;

    zfs_handle_t *zhp = zfs_open(g_zfs, zname,
        ZFS_TYPE_FILESYSTEM);
    if (zhp == NULL) {
        free(list);
        libzfs_fini(g_zfs);
        return NULL;
    }
    if (zfs_snap_callback(zhp, &cb)) {
        free(list);
        libzfs_fini(g_zfs);
        return NULL;
    }

    libzfs_fini(g_zfs);
    return list;
}

void kzfs_free_snap_list(kzfs_snap_list_st_t *list)
{
    if (list == NULL)
        return;
    for (int i = 0; i < list->count; i++) {
        free(list->list[i]->snapname);
        free(list->list[i]->desc);
        free(list->list[i]->used);
        free(list->list[i]);
    }
    free(list->list);
    free(list);
}

kzfs_mount_list_st_t *kzfs_mount_list(void)
{
    struct mnttab entry;
    FILE *mnttab_file;

    if ((mnttab_file = fopen(MNTTAB, "r")) == NULL) {
        return NULL;
    }
    kzfs_mount_list_st_t *list = malloc(sizeof(kzfs_mount_list_st_t));
    if (list == NULL) {
        return NULL;
    }
    list->count = 0;
    list->list = NULL;
    rewind(mnttab_file);
    while (getmntent(mnttab_file, &entry) == 0) {
        if (strcmp(entry.mnt_fstype, MNTTYPE_ZFS) != 0 ||
            strchr(entry.mnt_special, '@') != NULL)
            continue;

        list->count++;
        list->list = realloc(list->list, sizeof(kzfs_mount_info_t *) * list->count);
        if (list->list == NULL) {
            free(list);
            list = NULL;
            break;
        }
        int cur = list->count-1;
        list->list[cur] = malloc(sizeof(kzfs_mount_info_t));
        if (list->list[cur] == NULL) {
            free(list->list);
            free(list);
            list = NULL;
            break;
        }
        list->list[cur]->mi_special = malloc(strlen(entry.mnt_special) + 1);
        snprintf(list->list[cur]->mi_special, strlen(entry.mnt_special) + 1, "%s", entry.mnt_special);
        list->list[cur]->mi_mountpoint = malloc(strlen(entry.mnt_mountp) + 1);
        snprintf(list->list[cur]->mi_mountpoint, strlen(entry.mnt_mountp) + 1, "%s", entry.mnt_mountp);
    }
    fclose(mnttab_file);
    return list;
}

void kzfs_free_mount_list(kzfs_mount_list_st_t *list)
{
    if (list == NULL)
        return;
    for (int i = 0; i < list->count; i++) {
        free(list->list[i]->mi_special);
        free(list->list[i]->mi_mountpoint);
        free(list->list[i]);
    }
    free(list->list);
    free(list);
}

int kzfs_ds_rename(const char *zname, const char *new_zname, int force, int noumount, int parents_flag)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0;
    zfs_handle_t *zhp = NULL;
    renameflags_t flags = { 0 };
    int types;
    boolean_t parents = B_FALSE;
    flags.forceunmount = force;
    flags.nounmount = noumount;
    parents = parents_flag;

    if (flags.nounmount && parents) {
        ret = 1;
        goto out;
    }

    if (flags.nounmount)
        types = ZFS_TYPE_FILESYSTEM;
    else if (parents)
        types = ZFS_TYPE_FILESYSTEM | ZFS_TYPE_VOLUME;
    else
        types = ZFS_TYPE_DATASET;

    if ((zhp = zfs_open(g_zfs, zname, types)) == NULL) {
        ret = 1;
        goto out;
    }

    if (parents && zfs_name_valid(new_zname, zfs_get_type(zhp)) &&
        zfs_create_ancestors(g_zfs, new_zname) != 0) {
        ret = 1;
        goto out;
    }

    ret = (zfs_rename(zhp, NULL, new_zname, flags) != 0);

out:
    if (zhp)
        zfs_close(zhp);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzfs_snap_rename(const char *zname, const char *snapname, const char *new_snapname, int force, int recursive)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "libzfs_init failed");
#endif
        return -1;
    }
    int ret = 0;
    zfs_handle_t *zhp = NULL;
    renameflags_t flags = { 0 };
    int types;
    const char *snap = snapname;
    char tmp1[strlen(zname) + strlen(snapname) + 2];
    char tmp2[strlen(zname) + strlen(new_snapname) + 2];
    snprintf(tmp2, sizeof(tmp2), "%s@%s", zname, new_snapname);
    flags.forceunmount = force;
    flags.recurse = recursive;
    if (recursive) {
        snprintf(tmp1, sizeof(tmp1), "%s", zname);
    } else {
        snprintf(tmp1, sizeof(tmp1), "%s@%s", zname, snapname);
        snap = NULL;
    }
    types = ZFS_TYPE_DATASET;

    if ((zhp = zfs_open(g_zfs, tmp1, types)) == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "zfs_open failed");
#endif
        libzfs_fini(g_zfs);
        return -1;
    }
#ifdef ZDEBUG
    printf("%s %s %s\n", tmp1, tmp2, snap);
#endif
    
    ret = (zfs_rename(zhp, snap, tmp2, flags) != 0);

    zfs_close(zhp);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzfs_prop_valid(const char *propname)
{
    if (propname == NULL ||
        (zfs_name_to_prop(propname) == ZPROP_INVAL &&
        strchr(propname, ':') == NULL))
        return 0;
    return 1;
}

int kzpool_prop_valid(const char *propname)
{
    if (propname == NULL || zpool_name_to_prop(propname) == ZPROP_INVAL)
        return 0;
    return 1;
}

int kzfs_props_val_fill(kzfs_propval_list_t **list, const char *propname, const char *value)
{
    if (propname == NULL)
        return -1;
    if ((*list) == NULL) {
        (*list) = malloc(sizeof(kzfs_propval_list_t));
        if ((*list) == NULL)
            return -1;
        (*list)->count = 0;
        (*list)->props = NULL;
        (*list)->values = NULL;
    }

    int cur = (*list)->count;
    (*list)->count++;
    (*list)->props = realloc((*list)->props, sizeof(char *) * (*list)->count);
    if ((*list)->props == NULL) {
        free((*list));
        return -1;
    }
    if (value != NULL) {
        (*list)->values = realloc((*list)->values, sizeof(char *) * (*list)->count);
        if ((*list)->values == NULL) {
            free((*list)->props);
            free((*list));
            return -1;
        }
    }

    (*list)->props[cur] = malloc(strlen(propname) + 1);
    if ((*list)->props[cur] == NULL) {
        (*list)->count--;
        kzfs_free_props_val((*list));
        return -1;
    }
    snprintf((*list)->props[cur], strlen(propname) + 1, "%s", propname);

    if (value != NULL) {
        (*list)->values[cur] = malloc(strlen(value) + 1);
        if ((*list)->values[cur] == NULL) {
            (*list)->count--;
            free((*list)->props[cur]);
            kzfs_free_props_val((*list));
            return -1;
        }
        snprintf((*list)->values[cur], strlen(value) + 1, "%s", value);
    }
    return 0;
}

void kzfs_free_props_val(kzfs_propval_list_t *list)
{
    if (list == NULL)
        return;
    for (int i = 0; i < list->count; i++) {
        free(list->props[i]);
        if (list->values[i] != NULL)
            free(list->values[i]);
    }
    if (list->props != NULL)
        free(list->props);
    if (list->values != NULL)
        free(list->values);
    free(list);
}

int kzfs_ds_create(const char *zname, kzfs_propval_list_t *list)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    nvlist_t *props;
    zfs_type_t type = ZFS_TYPE_FILESYSTEM;
    zfs_handle_t *zhp = NULL;
    uint64_t volsize = 0;
    uint64_t intval;
    int mount = 0;
    if (nvlist_alloc(&props, NV_UNIQUE_NAME, 0) != 0) {
        libzfs_fini(g_zfs);
        return -1;
    }

    if (list != NULL) {
        for (int i = 0; i < list->count; i++) {
            if (strchr(list->props[i], ':') == NULL) {
                zfs_prop_t prop_n = zfs_name_to_prop(list->props[i]);
                if (prop_n == ZFS_PROP_VOLSIZE) {
                    char zname_tmp[strlen(zname) + 1];
                    snprintf(zname_tmp, sizeof(zname_tmp), "%s", zname);
                    type = ZFS_TYPE_VOLUME;
                    if (zfs_nicestrtonum(g_zfs, list->values[i], &intval) != 0) {
                        nvlist_free(props);
                        libzfs_fini(g_zfs);
                        return -1;
                    }
                    if (nvlist_add_uint64(props, zfs_prop_to_name(ZFS_PROP_VOLSIZE), intval) != 0) {
                        nvlist_free(props);
                        libzfs_fini(g_zfs);
                        return -1;
                    }
                    volsize = intval;

                    if (nvlist_add_string(props, "volmode", "dev") != 0) {
                        nvlist_free(props);
                        libzfs_fini(g_zfs);
                        return -1;
                    }

                    zpool_handle_t *zpool_handle;
                    nvlist_t *real_props = NULL;
                    uint64_t spa_version;
                    char *p;
                    zfs_prop_t resv_prop;
                    char *strval;
                    char msg[1024];
                    if ((p = strchr(zname_tmp, '/')) != NULL)
                        *p = '\0';
                    zpool_handle = zpool_open(g_zfs, zname_tmp);
                    if (p != NULL)
                        *p = '/';
                    if (zpool_handle == NULL) {
                        nvlist_free(props);
                        libzfs_fini(g_zfs);
                        return -1;
                    }
                    spa_version = zpool_get_prop_int(zpool_handle,
                        ZPOOL_PROP_VERSION, NULL);
                    if (spa_version >= SPA_VERSION_REFRESERVATION)
                        resv_prop = ZFS_PROP_REFRESERVATION;
                    else
                        resv_prop = ZFS_PROP_RESERVATION;

                    if (props && (real_props = zfs_valid_proplist(g_zfs, type,
                        props, 0, NULL, zpool_handle, msg)) == NULL) {
                        zpool_close(zpool_handle);
                        nvlist_free(props);
                        libzfs_fini(g_zfs);
                        return -1;
                    }
                    zpool_close(zpool_handle);

                    volsize = zvol_volsize_to_reservation(volsize, real_props);
                    nvlist_free(real_props);

                    if (nvlist_lookup_string(props, zfs_prop_to_name(resv_prop),
                        &strval) != 0) {
                        if (nvlist_add_uint64(props,
                            zfs_prop_to_name(resv_prop), volsize) != 0) {
                            nvlist_free(props);
                            libzfs_fini(g_zfs);
                            return -1;
                        }
                    }
                } else if (prop_n != ZPROP_INVAL) {
                    if (prop_n  == ZFS_PROP_MOUNTPOINT) {
                        mount = 1;
                    }
                    nvlist_add_string(props, zfs_prop_to_name(prop_n), list->values[i]);
                }
            } else {
                nvlist_add_string(props, list->props[i], list->values[i]);
            }
        }
    }


    if (zfs_create(g_zfs, zname, type, props) != 0) {
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }

    if ((zhp = zfs_open(g_zfs, zname, ZFS_TYPE_DATASET)) == NULL) {
        nvlist_free(props);
        libzfs_fini(g_zfs);
        return -1;
    }

    if (mount == 1 && should_auto_mount(zhp)) {
        if (zfs_mount(zhp, NULL, 0) != 0) {
            nvlist_free(props);
            libzfs_fini(g_zfs);
            return -1;
        } else if (zfs_share(zhp) != 0) {
            nvlist_free(props);
            libzfs_fini(g_zfs);
            return -1;
        }
    }

    zfs_close(zhp);
    nvlist_free(props);
    libzfs_fini(g_zfs);
    return 0;

}
int kzfs_props_fill(kzfs_prop_list_t **list, const char *propname)
{
    if (propname == NULL)
        return -1;
    if ((*list) == NULL) {
        (*list) = malloc(sizeof(kzfs_propval_list_t));
        if ((*list) == NULL)
            return -1;
        (*list)->count = 0;
        (*list)->props = NULL;
    }

    int cur = (*list)->count;
    (*list)->count++;
    (*list)->props = realloc((*list)->props, sizeof(char *) * (*list)->count);
    if ((*list)->props == NULL) {
        free((*list));
        return -1;
    }

    (*list)->props[cur] = malloc(strlen(propname) + 1);
    if ((*list)->props[cur] == NULL) {
        (*list)->count--;
        kzfs_free_props((*list));
        return -1;
    }
    snprintf((*list)->props[cur], strlen(propname) + 1, "%s", propname);

    return 0;
}

void kzfs_free_props(kzfs_prop_list_t *list)
{
    if (list == NULL)
        return;
    for (int i = 0; i < list->count; i++) {
        free(list->props[i]);
    }
    if (list->props != NULL)
        free(list->props);
    free(list);
}

kzfs_ds_list_t *kzfs_ds_list(kzfs_prop_list_t *props, const char *zname)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return NULL;
    }
    callback_data_t cb = {0};
    cb.proplist = props;
    kzfs_ds_list_t *list = malloc(sizeof(kzfs_ds_list_t));
    if (list == NULL) {
        libzfs_fini(g_zfs);
        return NULL;
    }
    list->count = 0;
    list->ds_info_list = NULL;
    cb.tmp = list;
    int ret = 0;
    if (zname != NULL) {
        zfs_handle_t *zhp = zfs_open(g_zfs, zname, ZFS_TYPE_FILESYSTEM | ZFS_TYPE_VOLUME);
        if (zhp == NULL) {
            libzfs_fini(g_zfs);
            return NULL;
        }
        zfs_ds_callback(zhp, &cb);
    } else {
        zfs_iter_root(g_zfs, zfs_ds_callback, &cb);
    }
    libzfs_fini(g_zfs);
    return list;
}

void kzfs_free_ds_list(kzfs_ds_list_t *ds_list)
{
    if (ds_list == NULL)
        return;
    for (int i = 0; i < ds_list->count; i++) {
        free(ds_list->ds_info_list[i]->zname);
        kzfs_free_props_val(ds_list->ds_info_list[i]->propval_list);
        free(ds_list->ds_info_list[i]);
    }
    free(ds_list->ds_info_list);
    free(ds_list);
}

int kzfs_ds_update(const char *zname, kzfs_propval_list_t *list)
{
    if (zname == NULL)
        return -1;
    if (list == NULL)
        return 0;
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    nvlist_t *props;
    zfs_type_t type = ZFS_TYPE_FILESYSTEM;
    zfs_handle_t *zhp = NULL;
    if ((zhp = zfs_open(g_zfs, zname, ZFS_TYPE_DATASET | ZFS_TYPE_VOLUME | ZFS_TYPE_SNAPSHOT)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }
    if (nvlist_alloc(&props, NV_UNIQUE_NAME, 0) != 0) {
        zfs_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }

    for (int i = 0; i < list->count; i++) {
        if (kzfs_prop_valid(list->props[i])) {
            nvlist_add_string(props, list->props[i], list->values[i]);
#ifdef ZDEBUG
        } else {
            printf("WARN: wrong property name (%s)\n", list->props[i]);
#endif
        }
    }
    int ret = zfs_prop_set_list(zhp, props);
    if (zhp)
        zfs_close(zhp);
    nvlist_free(props);
    libzfs_fini(g_zfs);
    if (ret != 0)
        return -1;
    return 0;
}

int kzfs_snap_update(const char *zname, const char *snapname, const char *desc)
{
    char snap[strlen(zname) + strlen(snapname) + 2];
    snprintf(snap, sizeof(snap), "%s@%s", zname, snapname);

    int ret = kzfs_set_uprop(snap, "snap:desc", desc);
    if (ret != 0)
        return -1;
    return 0;
}

/* ZPOOL */

int kzpool_destroy(const char *zpool_name)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    zpool_handle_t *zhp;

    if ((zhp = zpool_open_canfail(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    if (zpool_disable_datasets(zhp, B_TRUE) != 0) {
        zpool_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }

    int ret = zpool_destroy(zhp, NULL);

    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzpool_export(const char *zpool_name, int force)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    zpool_handle_t *zhp;

    if ((zhp = zpool_open_canfail(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    if (zpool_disable_datasets(zhp, force) != 0) {
        zpool_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }

    int ret = 0;
    ret = zpool_export(zhp, force, NULL);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;

}

int kzpool_clear(const char *zpool_name, const char *dev, int do_rewind)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0;
    nvlist_t *policy = NULL;
    zpool_handle_t *zhp;

    uint32_t rewind_policy = ZPOOL_NO_REWIND;
    if (do_rewind)
        rewind_policy = ZPOOL_DO_REWIND;

    if (nvlist_alloc(&policy, NV_UNIQUE_NAME, 0) != 0 ||
        nvlist_add_uint32(policy, ZPOOL_LOAD_REWIND_POLICY,
        rewind_policy) != 0) {
        libzfs_fini(g_zfs);
        return -1;
    }

    if ((zhp = zpool_open_canfail(g_zfs, zpool_name)) == NULL) {
        nvlist_free(policy);
        libzfs_fini(g_zfs);
        return -1;
    }
    
    ret = zpool_clear(zhp, dev, policy);

    zpool_close(zhp);
    nvlist_free(policy);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzpool_reguid(const char *zpool_name)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    int ret = 0;

    libzfs_fini(g_zfs);

    zpool_handle_t *zhp;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    ret = zpool_reguid(zhp);

    zpool_close(zhp);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzpool_reopen(const char *zpool_name)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0;
    zpool_handle_t *zhp;
    if ((zhp = zpool_open_canfail(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    ret = zpool_reopen(zhp);
    zpool_close(zhp);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzpool_labelclear(const char *dev, int force)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0, fd;
    struct stat st;
    char vdev[MAXPATHLEN];
    nvlist_t *config;
    boolean_t inuse = B_FALSE;
    char *name = NULL;
    pool_state_t state;

    (void) strlcpy(vdev, dev, sizeof (vdev));
    if (vdev[0] != '/' && stat(vdev, &st) != 0) {
        (void) snprintf(vdev, sizeof (vdev), "%s/%s",
            "/dev", dev);
        if (stat(vdev, &st) != 0) {
            libzfs_fini(g_zfs);
            return -1;
        }
    }

    if ((fd = open(vdev, O_RDWR)) < 0) {
        libzfs_fini(g_zfs);
        return -1;
    }
    if (zpool_read_label(fd, &config) != 0) {
        (void) close(fd);
        libzfs_fini(g_zfs);
        return -1;
    }
    nvlist_free(config);
    ret = zpool_in_use(g_zfs, fd, &state, &name, &inuse);
    if (ret != 0) {
        (void) close(fd);
        libzfs_fini(g_zfs);
        return -1;
    }
    if (!inuse)
        goto wipe_label;

    switch (state) {
    default:
    case POOL_STATE_ACTIVE:
    case POOL_STATE_SPARE:
    case POOL_STATE_L2CACHE:
    case POOL_STATE_DESTROYED:
        ret = 1;
        goto errout;
    case POOL_STATE_EXPORTED:
    case POOL_STATE_POTENTIALLY_ACTIVE:
        if (force)
            break;
        ret = 1;
        goto errout;
    }

wipe_label:
    ret = zpool_clear_label(fd);

errout:
    free(name);
    (void) close(fd);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzpool_root_mount_from(char *value)
{
    if (value == NULL)
        return -1;

    if(!kenv(KENV_GET, "vfs.root.mountfrom", value, KENV_MVALLEN + 1))
        return -1;
    return 0;
}

int kzpool_update(const char *zpool_name, kzfs_propval_list_t *list)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    zpool_handle_t *zhp;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }
    int ret = 0;
    for (int i = 0; i < list->count; i++) {
        if (kzpool_prop_valid(list->props[i])) {
            ret = zpool_set_prop(zhp, list->props[i], list->values[i]);
#ifdef ZDEBUG
        } else {
            printf("WARN: wrong property name (%s)\n", list->props[i]);
#endif
        }
    }

    zpool_close(zhp);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzpool_dev_info_fill(kzpool_dev_info_t **info, const char *type, int is_complex, int is_log, void *el)
{
    if ((*info) == NULL) {
        if (type == NULL) {
            return -1;
        }
        (*info) = malloc(sizeof(kzpool_dev_info_t));
        if (*info == NULL) {
            return -1;
        }
        snprintf((*info)->type, KZFS_ZPOOL_DEV_TYPE_MAX_LEN, "%s", type);
        (*info)->is_complex = is_complex;
        (*info)->is_log = is_log;
        (*info)->count = 0;
        (*info)->devs = NULL;
    }
    (*info)->count++;
    (*info)->devs = realloc((*info)->devs, (is_complex ? sizeof(kzpool_dev_info_t *) : sizeof(char *) ) * (*info)->count);
    int cur = (*info)->count - 1;

    if (is_complex) {
        /* already allocated */
        (*info)->devs[cur] = el;
    } else {
        /* copy dev name */
        (*info)->devs[cur] = malloc(strlen( (char *)el ) + 1);
        snprintf((*info)->devs[cur], strlen( (char *)el ) + 1, "%s", (char *)el);
    }
    return 0;
}

void kzpool_free_dev_info(kzpool_dev_info_t *info)
{
    if (info == NULL)
        return;
    if (info->is_complex) {
        for (int i = 0; i < info->count; i++) {
            kzpool_free_dev_info( (kzpool_dev_info_t *)info->devs[i] );
        }
    } else {
        for (int i = 0; i < info->count; i++) {
            free(info->devs[i]);
        }
    }
    free(info->devs);
    free(info);
}

int kzpool_dev_list_fill(kzpool_dev_list_t **list, kzpool_dev_info_t *info)
{
    if (info == NULL)
        return -1;
    if (*list == NULL) {
        *list = malloc(sizeof(kzpool_dev_list_t));
        if (list == NULL) {
            return -1;
        }
        (*list)->count = 0;
        (*list)->list = NULL;
    }
    (*list)->count++;
    int cur = (*list)->count - 1;
    (*list)->list = realloc((*list)->list, sizeof(kzpool_dev_info_t *) * (*list)->count);
    if ((*list)->list == NULL) {
        free(*list);
        return -1;
    }

    (*list)->list[cur] = info;
    return 0;
}

void kzpool_free_dev_list(kzpool_dev_list_t *list)
{
    if (list == NULL)
        return;
    for (int i = 0; i < list->count; i++) {
        kzpool_free_dev_info(list->list[i]);
    }
    free(list->list);
    free(list);
}

int kzpool_create(const char *zpool_name, kzpool_dev_list_t *devs_list, kzfs_propval_list_t *props_list, kzfs_propval_list_t *fs_props_list)
{
    if (zpool_name == NULL || devs_list == NULL) {
#ifdef ZDEBUG
        printf("zpool_name == NULL || devs_list == NULL\n");
#endif
        return -1;
    }

    if (strchr(zpool_name, '/') != NULL) {
#ifdef ZDEBUG
        printf("strchr(zpool_name, '/') != NULL\n");
#endif
        return -1;
    }

    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
#ifdef ZDEBUG
        printf("(g_zfs = libzfs_init()) == NULL\n");
#endif
        return -1;
    }

    if (devs_list != NULL) {
        for (int i = 0; i < devs_list->count; i++) {
            kzpool_dev_info_t *el = devs_list->list[i];
            printf("%s %s\n", el->type, el->is_log ? "log" : "");
            if (el->is_complex) {
                for (int j = 0; j < el->count; j++) {
                    kzpool_dev_info_t *subel = el->devs[j];
                    printf("\t%s\t", subel->type);
                    for (int k = 0; k < subel->count; k++) {
                        printf("%s ", subel->devs[k]);
                    }
                    printf("\n");
                }
            } else {
                for (int j = 0; j < el->count; j++) {
                    printf("%s ", (char *)el->devs[j]);
                }
            }
            printf("\n");
        }
        // kzpool_free_dev_list(list);
    }
    nvlist_t *fsprops = NULL;
    nvlist_t *props = NULL;
    nvlist_t *nvroot = NULL;
    char *mountpoint = NULL;
    int ret = 0;

    boolean_t force = B_FALSE;
    boolean_t dryrun = B_FALSE;
    boolean_t enable_all_pool_feat = B_TRUE;

    char *altroot = NULL;
    zpool_boot_label_t boot_type = ZPOOL_NO_BOOT_LABEL;
    uint64_t boot_size = 0;
    char *tname = NULL;

    if (props_list != NULL)
        for (int i = 0; i < props_list->count; i++) {
            if (strcmp(props_list->props[i], "root") == 0) {
                altroot = props_list->values[i];
                if (add_prop_list(zpool_prop_to_name(
                    ZPOOL_PROP_ALTROOT), altroot, &props, B_TRUE)) {
#ifdef ZDEBUG
        printf("add_prop_list ZPOOL_PROP_ALTROOT\n");
#endif
                    ret = 1;
                    goto error;
                }
                if (add_prop_list_default(zpool_prop_to_name(
                    ZPOOL_PROP_CACHEFILE), "none", &props, B_TRUE)) {
#ifdef ZDEBUG
        printf("add_prop_list ZPOOL_PROP_CACHEFILE\n");
#endif
                    ret = 1;
                    goto error;
                }
            } else if (strcmp(props_list->props[i], "force") == 0) {
                force = B_TRUE;
            } else if (strcmp(props_list->props[i], "dryrun") == 0) {
                dryrun = B_TRUE;
            } else if (strcmp(props_list->props[i], "no_feat") == 0) {
                enable_all_pool_feat = B_FALSE;
            } else if (strcmp(props_list->props[i], "mountpoint") == 0) {
                mountpoint = props_list->values[i];
            } else if (strcmp(props_list->props[i], "temp_name") == 0) {
                if (strchr(props_list->values[i], '/') != NULL) {
#ifdef ZDEBUG
        printf("temp_name no '/'\n");
#endif
                    ret = 1;
                    goto error;
                }
                if (add_prop_list(zpool_prop_to_name(
                    ZPOOL_PROP_TNAME), props_list->values[i], &props, B_TRUE)) {
#ifdef ZDEBUG
        printf("add_prop_list ZPOOL_PROP_TNAME\n");
#endif
                    ret = 1;
                    goto error;
                }
                if (add_prop_list_default(zpool_prop_to_name(
                    ZPOOL_PROP_CACHEFILE), "none", &props, B_TRUE)) {
#ifdef ZDEBUG
        printf("add_prop_list ZPOOL_PROP_CACHEFILE\n");
#endif
                    ret = 1;
                    goto error;
                }
                tname = props_list->values[i];
            } else {
                if (add_prop_list(props_list->props[i], props_list->values[i],
                    &props, B_TRUE)) {
#ifdef ZDEBUG
        printf("add_prop_list else\n");
#endif
                    ret = 1;
                    goto error;
                }
                if (zpool_name_to_prop(props_list->props[i]) == ZPOOL_PROP_BOOTSIZE) {
                    if (zfs_nicestrtonum(g_zfs, props_list->values[i],
                        &boot_size) < 0 || boot_size == 0) {
#ifdef ZDEBUG
        printf("zfs_nicestrtonum failed\n");
#endif
                        ret = 1;
                        goto error;
                    }
                }
                if (zpool_name_to_prop(props_list->props[i]) == ZPOOL_PROP_VERSION) {
                    char *end;
                    u_longlong_t ver;

                    ver = strtoull(props_list->values[i], &end, 10);
                    if (*end == '\0' &&
                        ver < SPA_VERSION_FEATURES) {
                        enable_all_pool_feat = B_FALSE;
                    }
                }
                if (zpool_name_to_prop(props_list->props[i]) == ZPOOL_PROP_ALTROOT)
                    altroot = props_list->values[i];
            }
        }

    if (fs_props_list != NULL)
        for (int i = 0; i < fs_props_list->count; i++) {
            if (0 == strcmp(fs_props_list->props[i],
                zfs_prop_to_name(ZFS_PROP_MOUNTPOINT))) {
                mountpoint = fs_props_list->values[i];
            } else if (add_prop_list(fs_props_list->props[i], fs_props_list->values[i], &fsprops,
                B_FALSE)) {
#ifdef ZDEBUG
        printf("add_prop_list fs_props_list failed\n");
#endif
                ret = 1;
                goto error;
            }
        }

    if (boot_type == ZPOOL_CREATE_BOOT_LABEL) {
        const char *propname;
        char *strptr, *buf = NULL;
        int rv;

        propname = zpool_prop_to_name(ZPOOL_PROP_BOOTSIZE);
        if (nvlist_lookup_string(props, propname, &strptr) != 0) {
            (void) asprintf(&buf, "%" PRIu64, boot_size);
            if (buf == NULL) {
#ifdef ZDEBUG
        printf("nvlist_lookup_string asprintf failed\n");
#endif
                ret = 1;
                goto error;
            }
            rv = add_prop_list(propname, buf, &props, B_TRUE);
            free(buf);
            if (rv != 0) {
#ifdef ZDEBUG
        printf("nvlist_lookup_string add_prop_list failed\n");
#endif
                ret = 1;
                goto error;
            }
        }
    } else {
        const char *propname;
        char *strptr;

        propname = zpool_prop_to_name(ZPOOL_PROP_BOOTSIZE);
        if (nvlist_lookup_string(props, propname, &strptr) == 0) {
#ifdef ZDEBUG
        printf("nvlist_lookup_string ZPOOL_PROP_BOOTSIZE failed\n");
#endif
            ret = 1;
            goto error;
        }
    }
    nvroot = make_root_vdev(g_zfs, NULL, force, !force, B_FALSE, dryrun,
        boot_type, boot_size, devs_list);
    if (nvroot == NULL) {
#ifdef ZDEBUG
        printf("make_root_vdev failed\n");
#endif
        ret = 1;
        goto error;
    }

    if (!zfs_allocatable_devs(nvroot)) {
#ifdef ZDEBUG
        printf("zfs_allocatable_devs failed\n");
#endif
        ret = 1;
        goto error;
    }
    if (altroot != NULL && altroot[0] != '/') {
#ifdef ZDEBUG
        printf("altroot != NULL && altroot[0] != '/'\n");
#endif
        ret = 1;
        goto error;
    }
    if (!force && (mountpoint == NULL ||
        (strcmp(mountpoint, ZFS_MOUNTPOINT_LEGACY) != 0 &&
        strcmp(mountpoint, ZFS_MOUNTPOINT_NONE) != 0))) {
        char buf[MAXPATHLEN];
        DIR *dirp;

        if (mountpoint && mountpoint[0] != '/') {
#ifdef ZDEBUG
        printf("mountpoint && mountpoint[0] != '/'\n");
#endif
            ret = 1;
            goto error;
        }

        if (mountpoint == NULL) {
            if (altroot != NULL)
                (void) snprintf(buf, sizeof (buf), "%s/%s",
                    altroot, zpool_name);
            else
                (void) snprintf(buf, sizeof (buf), "/%s",
                    zpool_name);
        } else {
            if (altroot != NULL)
                (void) snprintf(buf, sizeof (buf), "%s%s",
                    altroot, mountpoint);
            else
                (void) snprintf(buf, sizeof (buf), "%s",
                    mountpoint);
        }

        if ((dirp = opendir(buf)) == NULL && errno != ENOENT) {
#ifdef ZDEBUG
        printf("dirp = opendir(buf)) == NULL && errno != ENOENT\n");
#endif
            ret = 1;
            goto error;
        } else if (dirp) {
            int count = 0;

            while (count < 3 && readdir(dirp) != NULL)
                count++;
            (void) closedir(dirp);

            if (count > 2) {
#ifdef ZDEBUG
        printf("count > 2\n");
#endif
                ret = 1;
                goto error;
            }
        }
    }

    if (mountpoint != NULL) {
        ret = add_prop_list(zfs_prop_to_name(ZFS_PROP_MOUNTPOINT),
            mountpoint, &fsprops, B_FALSE);
        if (ret != 0) {
#ifdef ZDEBUG
        printf("add_prop_list ZFS_PROP_MOUNTPOINT failed\n");
#endif
            goto error;
        }
    }

    ret = 1;
    if (enable_all_pool_feat) {
        spa_feature_t j;
        for (j = 0; j < SPA_FEATURES; j++) {
            char propname[MAXPATHLEN];
            zfeature_info_t *feat = &spa_feature_table[j];

            (void) snprintf(propname, sizeof (propname),
                "feature@%s", feat->fi_uname);

            if (nvlist_exists(props, propname))
                continue;

            ret = add_prop_list(propname,
                ZFS_FEATURE_ENABLED, &props, B_TRUE);
            if (ret != 0) {
#ifdef ZDEBUG
        printf("add_prop_list ZFS_FEATURE_ENABLED failed\n");
#endif
                goto error;
            }
        }
    }

    ret = 1;
    if (zpool_create(g_zfs, zpool_name,
        nvroot, props, fsprops) == 0) {
        zfs_handle_t *pool = zfs_open(g_zfs,
            tname ? tname : zpool_name, ZFS_TYPE_FILESYSTEM);
        if (pool != NULL) {
            if (zfs_mount(pool, NULL, 0) == 0)
                ret = zfs_shareall(pool);
            zfs_close(pool);
        }
    }

error:

    nvlist_free(nvroot);
    nvlist_free(fsprops);
    nvlist_free(props);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;

}
int kzpool_attach(const char *zpool_name, const char *dev, const char *new_dev, int force)
{
    return zpool_attach_or_replace(zpool_name, dev, new_dev, force, 0);
}

int kzpool_replace(const char *zpool_name, const char *dev, const char *new_dev, int force)
{
    if (new_dev == NULL)
        new_dev = dev;
    return zpool_attach_or_replace(zpool_name, dev, new_dev, force, 1);
}

int kzpool_detach(const char *zpool_name, const char *dev)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    zpool_handle_t *zhp;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    int ret = zpool_vdev_detach(zhp, dev);

    zpool_close(zhp);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzpool_online(const char *zpool_name, kzpool_dev_info_t *devs, int expand)
{
    if (devs == NULL || zpool_name == NULL)
        return -1;
    if (devs->is_complex)
        return -1;
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    zpool_handle_t *zhp;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }
    int ret = 0;
    vdev_state_t newstate;

    int flags = 0;
    if (expand)
        flags |= ZFS_ONLINE_EXPAND;

    for (int i = 0; i < devs->count; i++) {
        if (zpool_vdev_online(zhp, (char *)devs->devs[i], flags, &newstate) != 0) {
            ret = 1;
        }
    }
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzpool_offline(const char *zpool_name, kzpool_dev_info_t *devs, int temp)
{
    if (devs == NULL || zpool_name == NULL)
        return -1;
    if (devs->is_complex)
        return -1;
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    zpool_handle_t *zhp;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }
    int ret = 0;
    vdev_state_t newstate;


    for (int i = 0; i < devs->count; i++) {
        if (zpool_vdev_offline(zhp, (char *)devs->devs[i], temp) != 0) {
            ret = 1;
        }
    }
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzpool_add(const char *zpool_name, kzpool_dev_list_t *devs_list, int force)
{
    if (devs_list == NULL)
        return -1;
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0;

    nvlist_t *nvroot;
    zpool_boot_label_t boot_type;
    uint64_t boot_size;
    zpool_handle_t *zhp;
    nvlist_t *config;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    if ((config = zpool_get_config(zhp, NULL)) == NULL) {
        zpool_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }
    if (zpool_is_bootable(zhp))
        boot_type = ZPOOL_COPY_BOOT_LABEL;
    else
        boot_type = ZPOOL_NO_BOOT_LABEL;

    boot_size = zpool_get_prop_int(zhp, ZPOOL_PROP_BOOTSIZE, NULL);
    nvroot = make_root_vdev(g_zfs, zhp, force, !force, B_FALSE, B_FALSE,
        boot_type, boot_size, devs_list);

    if (nvroot == NULL) {
        zpool_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }

    ret = (zpool_add(zhp, nvroot) != 0);

    nvlist_free(nvroot);
    zpool_close(zhp);
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzpool_scrub(const char *zpool_name, int cmd)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }
    int ret = 0;
    scrub_cbdata_t cb;
    cb.cb_type = POOL_SCAN_SCRUB;
    cb.cb_scrub_cmd = POOL_SCRUB_NORMAL;
    if (cmd == KZFS_ZPOOL_SCRUB_STOP)
        cb.cb_type = POOL_SCAN_NONE;
    if (cmd == KZFS_ZPOOL_SCRUB_PAUSE)
        cb.cb_scrub_cmd = POOL_SCRUB_PAUSE;

    zpool_handle_t *zhp;

    if ((zhp = zpool_open_canfail(g_zfs, zpool_name)) != NULL) {
        ret = zpool_scrub_callback(zhp, &cb);
        zpool_close(zhp);
    }
    libzfs_fini(g_zfs);

    if (ret)
        return -1;
    return 0;
}

int kzpool_split(const char *zpool_name, const char *new_zpool_name, kzfs_propval_list_t *props_list, kzpool_dev_info_t *devs)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "libzfs_init failed");
#endif
        return -1;
    }

    char *propval;
    char *mntopts = NULL;
    splitflags_t flags;
    int c, ret = 0;
    zpool_handle_t *zhp = NULL;
    nvlist_t *config, *props = NULL;
    flags.dryrun = B_FALSE;
    flags.import = B_FALSE;

    if (props_list != NULL)
        for (int i = 0; i < props_list->count; i++) {
            if (strcmp(props_list->props[i], "root") == 0) {
                flags.import = B_TRUE;
                if (add_prop_list(zpool_prop_to_name(
                    ZPOOL_PROP_ALTROOT), props_list->values[i], &props, B_TRUE)) {
#ifdef ZDEBUG
        printf("%s\n", "add_prop_list ZPOOL_PROP_ALTROOT failed");
#endif
                    ret = 1;
                    goto out;
                }
            } else if (strcmp(props_list->props[i], "mntopts") == 0) {
                mntopts = props_list->values[i];
            } else {
                if (add_prop_list(props_list->props[i], props_list->values[i],
                    &props, B_TRUE)) {
#ifdef ZDEBUG
        printf("%s %s failed\n", "add_prop_list", props_list->props[i]);
#endif
                    ret = 1;
                    goto out;
                }
            }
        }

    if (!flags.import && mntopts != NULL) {
#ifdef ZDEBUG
        printf("%s\n", "!flags.import && mntopts != NULL");
#endif
        ret = 1;
        goto out;
    }

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "zpool_open failed");
#endif
        ret = 1;
        goto out;
    }

    config = split_mirror_vdev(zhp, new_zpool_name, props, flags, devs);

    if (config == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "config == NULL");
#endif
        ret = 1;
    } else {
        nvlist_free(config);
    }
    zpool_close(zhp);

    if (ret != 0 || !flags.import) {
#ifdef ZDEBUG
        printf("%s\n", "ret != 0 || !flags.import");
        printf("ret = %d\t!flags.import = %d\n", ret, !flags.import);
#endif
        goto out;
    }

    if ((zhp = zpool_open_canfail(g_zfs, new_zpool_name)) == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "zpool_open_canfail failed");
#endif
        ret = 1;
        goto out;
    }
    if (zpool_get_state(zhp) != POOL_STATE_UNAVAIL &&
        zpool_enable_datasets(zhp, mntopts, 0) != 0) {
#ifdef ZDEBUG
        printf("%s\n", "zpool_get_state or zpool_enable_datasets failed");
#endif
        ret = 1;
    }
    zpool_close(zhp);

out:
    nvlist_free(props);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

kzfs_zpool_list_t *kzpool_list(kzfs_prop_list_t *props)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return NULL;
    }
    zpool_cb_data_t cb = {0};
    cb.proplist = props;
    kzfs_zpool_list_t *zlist = malloc(sizeof(kzfs_zpool_list_t));
    if (zlist == NULL) {
        libzfs_fini(g_zfs);
        return NULL;
    }
    zlist->zpool_info_list = NULL;
    zlist->count = 0;
    cb.tmp = zlist;
    int ret = zpool_iter(g_zfs, zpool_callback, &cb);
    libzfs_fini(g_zfs);

    if (ret)
        return NULL;
    return zlist;
}

void kzpool_free_list(kzfs_zpool_list_t *list)
{
    if (list == NULL)
        return;
    for (int i = 0; i < list->count; i++) {
        free(list->zpool_info_list[i]->zpool_name);
        kzfs_free_props_val(list->zpool_info_list[i]->propval_list);
        free(list->zpool_info_list[i]);
    }
    free(list->zpool_info_list);
    free(list);
}

kzpool_dev_list_t *kzpool_get_devs(const char *zpool_name)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return NULL;
    }

    zpool_handle_t *zhp = NULL;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return NULL;
    }
    nvlist_t *config;
    config = zpool_get_config(zhp, NULL);

    nvlist_t *nv;
    nvlist_lookup_nvlist(config, ZPOOL_CONFIG_VDEV_TREE,
            &nv);
    kzpool_dev_list_t *list = NULL;
    zpool_devs_list(g_zfs, zhp, nv, &list);
    zpool_close(zhp);
    libzfs_fini(g_zfs);
    return list;
}

kzpool_status_t *kzpool_status(const char *zpool_name)
{
    if (zpool_name == NULL) {
        return NULL;
    }
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return NULL;
    }

    kzpool_status_t *status = malloc(sizeof(kzpool_status_t));
    if (status == NULL) {
        libzfs_fini(g_zfs);
        return NULL;
    }

    zpool_handle_t *zhp;

    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        free(status);
        libzfs_fini(g_zfs);
        return NULL;
    }

    zpool_status_callback(g_zfs, zhp, status);
    zpool_close(zhp);
    libzfs_fini(g_zfs);
    return status;
}

kzpool_import_list_t *kzpool_import_list(char *cachefile, const char *search, int do_destroyed)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return NULL;
    }

    int ret = 0;
    char **searchdirs = NULL;
    int nsearch = 0;
    int flags = ZFS_IMPORT_NORMAL;
    nvlist_t *config = NULL;
    uint32_t rewind_policy = ZPOOL_NO_REWIND;

    if (search != NULL) {
        char search_tmp[strlen(search) + 1];
        snprintf(search_tmp, sizeof(search_tmp), "%s", search);
        char *tmp = strtok(search_tmp, ",");
        while (tmp != NULL) {
            nsearch++;
            searchdirs = realloc(searchdirs, sizeof(char *) * nsearch);
            if (searchdirs == NULL) {
                libzfs_fini(g_zfs);
                return NULL;
            }
            searchdirs[nsearch - 1] = tmp;
            tmp = strtok(NULL, ",");
        }
    }

    if (nsearch && cachefile != NULL) {
        free(searchdirs);
        libzfs_fini(g_zfs);
        return NULL;
    }
    if (searchdirs == NULL) {
        searchdirs = malloc(sizeof (char *));
        searchdirs[0] = "/dev";
        nsearch = 1;
    }

    importargs_t idata = { 0 };
    nvlist_t *pools = NULL;
    nvlist_t *policy = NULL;
    uint64_t pool_state, txg = -1ULL;
    nvpair_t *elem;
    kzpool_import_list_t *import_list = NULL;

    if (nvlist_alloc(&policy, NV_UNIQUE_NAME, 0) != 0 ||
        nvlist_add_uint64(policy, ZPOOL_LOAD_REQUEST_TXG, txg) != 0 ||
        nvlist_add_uint32(policy, ZPOOL_LOAD_REWIND_POLICY,
        rewind_policy) != 0) {
        ret = 1;
        goto out;
    }

    idata.path = searchdirs;
    idata.paths = nsearch;
    idata.poolname = NULL;
    idata.guid = 0;
    idata.cachefile = cachefile;
    idata.policy = policy;

    pools = zpool_search_import(g_zfs, &idata);
    if (pools == NULL && idata.exists) {
        ret = 1;
        goto out;
    } else if (pools == NULL) {
        ret = 1;
        goto out;
    }

    import_list = malloc(sizeof(kzpool_import_list_t));
    if (import_list == NULL) {
        ret = 1;
        goto out;
    }

    elem = NULL;
    import_list->list = NULL;
    import_list->count = 0;
    int cur = 0;
    while ((elem = nvlist_next_nvpair(pools, elem)) != NULL) {
        nvpair_value_nvlist(elem, &config);

        nvlist_lookup_uint64(config, ZPOOL_CONFIG_POOL_STATE,
            &pool_state);
        if (!do_destroyed && pool_state == POOL_STATE_DESTROYED)
            continue;
        if (do_destroyed && pool_state != POOL_STATE_DESTROYED)
            continue;

        nvlist_add_nvlist(config, ZPOOL_LOAD_POLICY,
            policy);
        import_list->count++;
        cur = import_list->count - 1;
        import_list->list = realloc(import_list->list, sizeof(kzpool_import_info_t *) * import_list->count); /*TODO free*/
        import_list->list[cur] = malloc(sizeof(kzpool_import_info_t)); /*TODO free*/

        uint64_t guid;
        nvlist_lookup_uint64(config,
            ZPOOL_CONFIG_POOL_GUID, &guid);
        import_list->list[cur]->guid = guid;

        fill_import_info(g_zfs, config, import_list->list[cur]);
    }

out:
    nvlist_free(pools);
    nvlist_free(policy);
    free(searchdirs);
    libzfs_fini(g_zfs);
    if (ret) {
        kzpool_free_import_list(import_list);
        return NULL;
    }
    return import_list;
}

int kzpool_import_all(kzfs_propval_list_t *props_list)
{
    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    int ret = 0;
    char *cachefile = NULL;
    char **searchdirs = NULL;
    int nsearch = 0;
    int flags = ZFS_IMPORT_NORMAL;
    boolean_t do_destroyed = B_FALSE;
    nvlist_t *config = NULL;
    importargs_t idata = { 0 };
    nvlist_t *found_config = NULL;
    nvlist_t *pools = NULL;
    nvlist_t *props = NULL;
    nvlist_t *policy = NULL;
    uint64_t pool_state, txg = -1ULL;
    uint64_t searchguid = 0;
    char *searchname = NULL;
    nvpair_t *elem;
    uint32_t rewind_policy = ZPOOL_NO_REWIND;
    boolean_t do_rewind = B_FALSE;
    boolean_t dryrun = B_FALSE;
    boolean_t xtreme_rewind = B_FALSE;
    char *newname = NULL;
    char *mntopts = NULL;

    if (props_list != NULL)
    for (int i = 0; i < props_list->count; i++) {
        if (strcmp(props_list->props[i], "newname") == 0) {
            newname = props_list->values[i];
        } else if (strcmp(props_list->props[i], "temp_name") == 0) {
            flags |= ZFS_IMPORT_TEMP_NAME;
            if (add_prop_list_default(zpool_prop_to_name(
                ZPOOL_PROP_CACHEFILE), "none", &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
        } else if (strcmp(props_list->props[i], "force") == 0) {
            flags |= ZFS_IMPORT_ANY_HOST;
        } else if (strcmp(props_list->props[i], "rewind") == 0) {
            do_rewind = B_TRUE;
        } else if (strcmp(props_list->props[i], "missing_log") == 0) {
            flags |= ZFS_IMPORT_MISSING_LOG;
        } else if (strcmp(props_list->props[i], "dryrun") == 0) {
            dryrun = B_TRUE;
        } else if (strcmp(props_list->props[i], "no_mount") == 0) {
            flags |= ZFS_IMPORT_ONLY;
        } else if (strcmp(props_list->props[i], "mntopts") == 0) {
            mntopts = props_list->values[i];
        } else if (strcmp(props_list->props[i], "cachefile") == 0) {
            cachefile = props_list->values[i];
        } else if (strcmp(props_list->props[i], "root") == 0) {
            if (add_prop_list(zpool_prop_to_name(
                ZPOOL_PROP_ALTROOT), props_list->values[i], &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
            if (add_prop_list_default(zpool_prop_to_name(
                ZPOOL_PROP_CACHEFILE), "none", &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
        } else if (strcmp(props_list->props[i], "searchdirs") == 0) {
            char *tmp = strtok(props_list->values[i], ",");
            while (tmp != NULL) {
                nsearch++;
                searchdirs = realloc(searchdirs, sizeof(char *) * nsearch);
                if (searchdirs == NULL) {
                    ret = 1;
                    goto out;
                }
                searchdirs[nsearch - 1] = tmp;
                tmp = strtok(NULL, ",");
            }
        } else if (strcmp(props_list->props[i], "destroyed") == 0) {
            do_destroyed = B_TRUE;
        } else {
            if (add_prop_list(props_list->props[i], props_list->values[i],
                &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
        }
    }

    if (nsearch && cachefile != NULL) {
        free(searchdirs);
        libzfs_fini(g_zfs);
        return -1;
    }

    if ((dryrun || xtreme_rewind) && !do_rewind) {
        ret = 1;
        goto out;
    }
    if (dryrun)
        rewind_policy = ZPOOL_TRY_REWIND;
    else if (do_rewind)
        rewind_policy = ZPOOL_DO_REWIND;
    if (xtreme_rewind)
        rewind_policy |= ZPOOL_EXTREME_REWIND;

    if (searchdirs == NULL) {
        searchdirs = malloc(sizeof (char *));
        searchdirs[0] = "/dev";
        nsearch = 1;
    }

    if (nvlist_alloc(&policy, NV_UNIQUE_NAME, 0) != 0 ||
        nvlist_add_uint64(policy, ZPOOL_LOAD_REQUEST_TXG, txg) != 0 ||
        nvlist_add_uint32(policy, ZPOOL_LOAD_REWIND_POLICY,
        rewind_policy) != 0) {
        ret = 1;
        goto out;
    }

    idata.path = searchdirs;
    idata.paths = nsearch;
    idata.poolname = searchname;
    idata.guid = searchguid;
    idata.cachefile = cachefile;
    idata.policy = policy;

    pools = zpool_search_import(g_zfs, &idata);
    if (pools == NULL && idata.exists) {
        ret = 1;
    } else if (pools == NULL) {
        ret = 1;
    }
    if (ret == 1)
        goto out;


    elem = NULL;

    while ((elem = nvlist_next_nvpair(pools, elem)) != NULL) {
        nvpair_value_nvlist(elem, &config);

        nvlist_lookup_uint64(config, ZPOOL_CONFIG_POOL_STATE,
            &pool_state);
        if (!do_destroyed && pool_state == POOL_STATE_DESTROYED)
            continue;
        if (do_destroyed && pool_state != POOL_STATE_DESTROYED)
            continue;

        nvlist_add_nvlist(config, ZPOOL_LOAD_POLICY,
            policy);
        ret |= do_import(g_zfs, config, NULL, mntopts, props, flags);
    }

out:
    nvlist_free(pools);
    nvlist_free(props);
    nvlist_free(policy);
    if (searchdirs != NULL)
        free(searchdirs);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

int kzpool_import(const char *zpool_name, kzfs_propval_list_t *props_list)
{
    if (zpool_name == NULL)
        return -1;

    libzfs_handle_t *g_zfs;

    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    int ret = 0;
    char *cachefile = NULL;
    char **searchdirs = NULL;
    int nsearch = 0;
    int flags = ZFS_IMPORT_NORMAL;
    boolean_t do_destroyed = B_FALSE;
    nvlist_t *config = NULL;
    importargs_t idata = { 0 };
    nvlist_t *found_config = NULL;
    nvlist_t *pools = NULL;
    nvlist_t *props = NULL;
    nvlist_t *policy = NULL;
    uint64_t pool_state, txg = -1ULL;
    uint64_t searchguid = 0;
    char searchname[strlen(zpool_name) + 1];
    memset(searchname, 0, sizeof(searchname));
    nvpair_t *elem;
    uint32_t rewind_policy = ZPOOL_NO_REWIND;
    boolean_t do_rewind = B_FALSE;
    boolean_t dryrun = B_FALSE;
    boolean_t xtreme_rewind = B_FALSE;
    char *newname = NULL;
    char *mntopts = NULL;

    if (props_list != NULL)
    for (int i = 0; i < props_list->count; i++) {
        if (strcmp(props_list->props[i], "newname") == 0) {
            newname = props_list->values[i];
        } else if (strcmp(props_list->props[i], "temp_name") == 0) {
            flags |= ZFS_IMPORT_TEMP_NAME;
            if (add_prop_list_default(zpool_prop_to_name(
                ZPOOL_PROP_CACHEFILE), "none", &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
        } else if (strcmp(props_list->props[i], "force") == 0) {
            flags |= ZFS_IMPORT_ANY_HOST;
        } else if (strcmp(props_list->props[i], "rewind") == 0) {
            do_rewind = B_TRUE;
        } else if (strcmp(props_list->props[i], "missing_log") == 0) {
            flags |= ZFS_IMPORT_MISSING_LOG;
        } else if (strcmp(props_list->props[i], "dryrun") == 0) {
            dryrun = B_TRUE;
        } else if (strcmp(props_list->props[i], "no_mount") == 0) {
            flags |= ZFS_IMPORT_ONLY;
        } else if (strcmp(props_list->props[i], "mntopts") == 0) {
            mntopts = props_list->values[i];
        } else if (strcmp(props_list->props[i], "cachefile") == 0) {
            cachefile = props_list->values[i];
        } else if (strcmp(props_list->props[i], "root") == 0) {
            if (add_prop_list(zpool_prop_to_name(
                ZPOOL_PROP_ALTROOT), props_list->values[i], &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
            if (add_prop_list_default(zpool_prop_to_name(
                ZPOOL_PROP_CACHEFILE), "none", &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
        } else if (strcmp(props_list->props[i], "searchdirs") == 0) {
            char *tmp = strtok(props_list->values[i], ",");
            while (tmp != NULL) {
                nsearch++;
                searchdirs = realloc(searchdirs, sizeof(char *) * nsearch);
                if (searchdirs == NULL) {
                    ret = 1;
                    goto out;
                }
                searchdirs[nsearch - 1] = tmp;
                tmp = strtok(NULL, ",");
            }
        } else if (strcmp(props_list->props[i], "destroyed") == 0) {
            do_destroyed = B_TRUE;
        } else {
            if (add_prop_list(props_list->props[i], props_list->values[i],
                &props, B_TRUE)) {
                ret = 1;
                goto out;
            }
        }
    }

    if (nsearch && cachefile != NULL) {
        free(searchdirs);
        libzfs_fini(g_zfs);
        return -1;
    }

    if ((dryrun || xtreme_rewind) && !do_rewind) {
        ret = 1;
        goto out;
    }
    if (dryrun)
        rewind_policy = ZPOOL_TRY_REWIND;
    else if (do_rewind)
        rewind_policy = ZPOOL_DO_REWIND;
    if (xtreme_rewind)
        rewind_policy |= ZPOOL_EXTREME_REWIND;

    if (searchdirs == NULL) {
        searchdirs = malloc(sizeof (char *));
        searchdirs[0] = "/dev";
        nsearch = 1;
    }

    if (nvlist_alloc(&policy, NV_UNIQUE_NAME, 0) != 0 ||
        nvlist_add_uint64(policy, ZPOOL_LOAD_REQUEST_TXG, txg) != 0 ||
        nvlist_add_uint32(policy, ZPOOL_LOAD_REWIND_POLICY,
        rewind_policy) != 0) {
        ret = 1;
        goto out;
    }

    if (zpool_name != NULL) {
        char *endptr;
        errno = 0;
        searchguid = strtoull(zpool_name, &endptr, 10);
        if (errno != 0 || *endptr != '\0') {
            // searchname = zpool_name;
            snprintf(searchname, sizeof(searchname), "%s", zpool_name);
            searchguid = 0;
        }
        found_config = NULL;
        idata.unique = B_TRUE;
    }
    idata.path = searchdirs;
    idata.paths = nsearch;
    idata.poolname = searchname[0] ? searchname : NULL;
    idata.guid = searchguid;
    idata.cachefile = cachefile;
    idata.policy = policy;

    pools = zpool_search_import(g_zfs, &idata);
    if (pools != NULL && idata.exists &&
        (newname != NULL || strcmp(zpool_name, newname) == 0)) {
        ret = 1;
    } else if (pools == NULL && idata.exists) {
        ret = 1;
    } else if (pools == NULL) {
        ret = 1;
    }
    if (ret == 1)
        goto out;


    elem = NULL;
    while ((elem = nvlist_next_nvpair(pools, elem)) != NULL) {
        nvpair_value_nvlist(elem, &config);

        nvlist_lookup_uint64(config, ZPOOL_CONFIG_POOL_STATE,
            &pool_state);
        if (!do_destroyed && pool_state == POOL_STATE_DESTROYED)
            continue;
        if (do_destroyed && pool_state != POOL_STATE_DESTROYED)
            continue;

        nvlist_add_nvlist(config, ZPOOL_LOAD_POLICY,
            policy);
        if (searchname[0]) {
            char *name;
            nvlist_lookup_string(config,
                ZPOOL_CONFIG_POOL_NAME, &name);
            if (strcmp(name, searchname) == 0) {
                if (found_config != NULL) {
                    ret = B_TRUE;
                }
                found_config = config;
                break;
            }
        } else {
            uint64_t guid;
            nvlist_lookup_uint64(config,
                ZPOOL_CONFIG_POOL_GUID, &guid);
            if (guid == searchguid) {
                found_config = config;
            }
        }
    }
    ret |= do_import(g_zfs, found_config, newname, mntopts, props, flags);

out:
    nvlist_free(pools);
    nvlist_free(props);
    nvlist_free(policy);
    if (searchdirs != NULL)
        free(searchdirs);
    libzfs_fini(g_zfs);
    if (ret)
        return -1;
    return 0;
}

static void kzpool_free_import_config(kzpool_import_config_t *config)
{
    if (config == NULL)
        return;
    for (int i = 0; i < config->config_count; i++)
        kzpool_free_import_config(config->config_list[i]);
    for (int i = 0; i < config->cache_count; i++)
        free(config->cache_list[i]);
    for (int i = 0; i < config->spares_count; i++)
        free(config->spares_list[i]);
    if (config->config_list != NULL)
        free(config->config_list);
    if (config->cache_list != NULL)
        free(config->cache_list);
    if (config->spares_list != NULL)
        free(config->spares_list);
    if (config->msg != NULL)
        free(config->msg);
    free(config);
}

void kzpool_free_import_list(kzpool_import_list_t *import_list)
{
    if (import_list == NULL)
        return;

    for (int i = 0; i < import_list->count; i++) {
        kzpool_free_import_config(import_list->list[i]->config);
        kzpool_free_import_config(import_list->list[i]->logs);
        if (import_list->list[i]->reason != NULL)
            free(import_list->list[i]->reason);
        if (import_list->list[i]->action != NULL)
            free(import_list->list[i]->action);
        if (import_list->list[i]->comment != NULL)
            free(import_list->list[i]->comment);
        if (import_list->list[i]->msg != NULL)
            free(import_list->list[i]->msg);
        if (import_list->list[i]->warn != NULL)
            free(import_list->list[i]->warn);
        free(import_list->list[i]);
    }
    if (import_list->list != NULL)
        free(import_list->list);
    free(import_list);
}

static void
fill_import_info(libzfs_handle_t *g_zfs, nvlist_t *config, kzpool_import_info_t *import_info)
{
    char *name;
    uint64_t pool_state;
    vdev_stat_t *vs;
    uint_t vsc;
    char *msgid;
    char *comment;
    nvlist_t *nvroot;
    int reason = 0;

    nvlist_lookup_string(config,
        ZPOOL_CONFIG_POOL_NAME, &name);
    snprintf(import_info->name, MAXPATHLEN, "%s", name);

    nvlist_lookup_uint64(config, ZPOOL_CONFIG_POOL_STATE,
        &pool_state);
    nvlist_lookup_nvlist(config, ZPOOL_CONFIG_VDEV_TREE,
        &nvroot);
    nvlist_lookup_uint64_array(nvroot, ZPOOL_CONFIG_VDEV_STATS,
        (uint64_t **)&vs, &vsc);
    snprintf(import_info->state, KZFS_ZPOOL_STATUS_STATE_LEN, "%s", zpool_state_to_name(vs->vs_state, vs->vs_aux));

    if (pool_state == POOL_STATE_DESTROYED)
        import_info->destroyed = 1;
    else
        import_info->destroyed = 0;

    reason = zpool_import_status(config, &msgid);
    char *tmp_ptr = NULL;
    switch (reason) {
    case ZPOOL_STATUS_MISSING_DEV_R:
    case ZPOOL_STATUS_MISSING_DEV_NR:
    case ZPOOL_STATUS_BAD_GUID_SUM:
        tmp_ptr = "One or more devices are "
            "missing from the system.";
        break;

    case ZPOOL_STATUS_CORRUPT_LABEL_R:
    case ZPOOL_STATUS_CORRUPT_LABEL_NR:
        tmp_ptr = "One or more devices contains "
            "corrupted data.";
        break;

    case ZPOOL_STATUS_CORRUPT_DATA:
        tmp_ptr = "The pool data is corrupted.";
        break;

    case ZPOOL_STATUS_OFFLINE_DEV:
        tmp_ptr = "One or more devices "
            "are offlined.";
        break;

    case ZPOOL_STATUS_CORRUPT_POOL:
        tmp_ptr = "The pool metadata is "
            "corrupted.";
        break;

    case ZPOOL_STATUS_VERSION_OLDER:
        tmp_ptr = "The pool is formatted using a "
            "legacy on-disk version.";
        break;

    case ZPOOL_STATUS_VERSION_NEWER:
        tmp_ptr = "The pool is formatted using an "
            "incompatible version.";
        break;

    case ZPOOL_STATUS_FEAT_DISABLED:
        tmp_ptr = "Some supported features are "
            "not enabled on the pool.";
        break;

    case ZPOOL_STATUS_UNSUP_FEAT_READ:
        tmp_ptr = "The pool uses "
            "feature(s) that is not supported on this system.";
        break;

    case ZPOOL_STATUS_UNSUP_FEAT_WRITE:
        tmp_ptr = "The pool can only be accessed "
            "in read-only mode on this system. It cannot be "
            "accessed in read-write mode because it uses "
            "feature(s) that is not supported on this system.";
        break;

    case ZPOOL_STATUS_HOSTID_MISMATCH:
        tmp_ptr = "The pool was last accessed by "
            "another system.";
        break;

    case ZPOOL_STATUS_FAULTED_DEV_R:
    case ZPOOL_STATUS_FAULTED_DEV_NR:
        tmp_ptr = "One or more devices are "
            "faulted.";
        break;

    case ZPOOL_STATUS_BAD_LOG:
        tmp_ptr = "An intent log record cannot be "
            "read.";
        break;

    case ZPOOL_STATUS_RESILVERING:
        tmp_ptr = "One or more devices were being "
            "resilvered.";
        break;

    case ZPOOL_STATUS_NON_NATIVE_ASHIFT:
        tmp_ptr = "One or more devices were "
            "configured to use a non-native block size. "
            "Expect reduced performance.";
        break;

    default:
        break;
    }

    if (tmp_ptr != NULL) {
        import_info->reason = malloc(strlen(tmp_ptr) + 1); /*TODO free*/
        snprintf(import_info->reason, strlen(tmp_ptr) + 1, "%s", tmp_ptr);
    } else {
        import_info->reason = NULL;
    }
    tmp_ptr = NULL;
    if (vs->vs_state == VDEV_STATE_HEALTHY) {
        if (reason == ZPOOL_STATUS_VERSION_OLDER ||
            reason == ZPOOL_STATUS_FEAT_DISABLED) {
            tmp_ptr = "The pool can be "
                "imported using its name or numeric identifier, "
                "though some features will not be available "
                "without an explicit zpool upgrade.";
        } else if (reason == ZPOOL_STATUS_HOSTID_MISMATCH) {
            tmp_ptr = "The pool can be "
                "imported using its name or numeric "
                "identifier and the force flag.";
        } else {
            tmp_ptr = "The pool can be "
                "imported using its name or numeric "
                "identifier.";
        }
    } else if (vs->vs_state == VDEV_STATE_DEGRADED) {
        tmp_ptr = "The pool can be imported "
            "despite missing or damaged devices.  The fault "
            "tolerance of the pool may be compromised if imported.";
    } else {
        switch (reason) {
        case ZPOOL_STATUS_VERSION_NEWER:
            tmp_ptr = "The pool cannot be "
                "imported.  Access the pool on a system running "
                "newer software, or recreate the pool from "
                "backup.";
            break;
        case ZPOOL_STATUS_UNSUP_FEAT_READ:
            tmp_ptr = "The pool cannot be "
                "imported. Access the pool on a system that "
                "supports the required feature(s), or recreate "
                "the pool from backup.";
            break;
        case ZPOOL_STATUS_UNSUP_FEAT_WRITE:
            tmp_ptr = "The pool cannot be "
                "imported in read-write mode. Import the pool "
                "with readonly property, access the pool on a system "
                "that supports the required feature(s), or "
                "recreate the pool from backup.";
            break;
        case ZPOOL_STATUS_MISSING_DEV_R:
        case ZPOOL_STATUS_MISSING_DEV_NR:
        case ZPOOL_STATUS_BAD_GUID_SUM:
            tmp_ptr = "The pool cannot be "
                "imported. Attach the missing devices and try "
                "again.";
            break;
        default:
            tmp_ptr = "The pool cannot be "
                "imported due to damaged devices or data.";
        }
    }
    if (tmp_ptr != NULL) {
        import_info->action = malloc(strlen(tmp_ptr) + 1); /*TODO free*/
        snprintf(import_info->action, strlen(tmp_ptr) + 1, "%s", tmp_ptr);
    } else {
        import_info->action = NULL;
    }
    import_info->comment = NULL;
    if (nvlist_lookup_string(config, ZPOOL_CONFIG_COMMENT, &comment) == 0) {
        import_info->comment = malloc(strlen(comment) + 1); /*TODO free*/
        snprintf(import_info->comment, strlen(comment) + 1, "%s", comment);
    }

    tmp_ptr = NULL;
    if (((vs->vs_state == VDEV_STATE_CLOSED) ||
        (vs->vs_state == VDEV_STATE_CANT_OPEN)) &&
        (vs->vs_aux == VDEV_AUX_CORRUPT_DATA)) {
        if (pool_state == POOL_STATE_DESTROYED) {
            tmp_ptr = "The pool was destroyed, "
                "but can be imported using the destroyed and force flags.";
        } else if (pool_state != POOL_STATE_EXPORTED) {
            tmp_ptr = "The pool may be active on "
                "another system, but can be imported using"
                "the force flag.";
        }
        if (tmp_ptr != NULL) {
            import_info->msg = malloc(strlen(tmp_ptr) + 1); /*TODO free*/
            snprintf(import_info->msg, strlen(tmp_ptr) + 1, "%s", tmp_ptr);
        } else {
            import_info->msg = NULL;
        }
    }

    zpool_get_import_config(g_zfs, name, nvroot, 0, &import_info->config);
    import_info->logs = NULL;
    if (num_logs(nvroot) > 0) 
        zpool_get_logs(g_zfs, nvroot, &import_info->logs);

    if (reason == ZPOOL_STATUS_BAD_GUID_SUM) {
        tmp_ptr = "Additional devices are known to "
            "be part of this pool, though their exact "
            "configuration cannot be determined.";
        import_info->warn = malloc(strlen(tmp_ptr) + 1); /*TODO free*/
        snprintf(import_info->warn, strlen(tmp_ptr) + 1, "%s", tmp_ptr);
    }
}

static void
zpool_get_logs(libzfs_handle_t *g_zfs, nvlist_t *nv, kzpool_import_config_t **logs)
{
    uint_t c, children;
    nvlist_t **child;

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN, &child,
        &children) != 0)
        return;

    
    if (*logs == NULL) {
        *logs = malloc(sizeof(kzpool_import_config_t));
        if (*logs == NULL)
            return;
    }
    (*logs)->config_count = 0;
    (*logs)->config_list = NULL;
    for (c = 0; c < children; c++) {
        uint64_t is_log = B_FALSE;
        char *name;

        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_LOG,
            &is_log);
        if (!is_log)
            continue;
        (*logs)->config_count++;
        (*logs)->config_list = realloc((*logs)->config_list, sizeof(kzpool_import_config_t *) * (*logs)->config_count); /*TODO free*/
        kzpool_import_config_t *st_conf = NULL;
        
        name = zpool_vdev_name(g_zfs, NULL, child[c], B_TRUE);
        zpool_get_import_config(g_zfs, name, child[c], 2, &st_conf);
        (*logs)->config_list[(*logs)->config_count - 1] = st_conf;
        free(name);
    }
}

static void
zpool_get_import_config(libzfs_handle_t *g_zfs, const char *name, nvlist_t *nv, int depth, kzpool_import_config_t **config)
{
    nvlist_t **child;
    uint_t c, children;
    vdev_stat_t *vs;
    char *type, *vname;

    nvlist_lookup_string(nv, ZPOOL_CONFIG_TYPE, &type);
    if (strcmp(type, VDEV_TYPE_MISSING) == 0 ||
        strcmp(type, VDEV_TYPE_HOLE) == 0)
        return;

    if (*config == NULL) {
        *config = malloc(sizeof(kzpool_status_config_t));
        if (*config == NULL)
            return;
        (*config)->msg = NULL;
        (*config)->config_list = NULL;
        (*config)->cache_list = (*config)->spares_list = NULL;
        (*config)->config_count = (*config)->cache_count = (*config)->spares_count = 0;
    }

    nvlist_lookup_uint64_array(nv, ZPOOL_CONFIG_VDEV_STATS,
        (uint64_t **)&vs, &c);

    if (depth != 0) {
        snprintf((*config)->name, MAXPATHLEN, "%s", name);
        snprintf((*config)->state, KZFS_ZPOOL_STATUS_STATE_LEN, "%s", zpool_state_to_name(vs->vs_state, vs->vs_aux));

        if (vs->vs_aux != 0) {
            char *tmp_msg = NULL;
            switch (vs->vs_aux) {
            case VDEV_AUX_OPEN_FAILED:
                tmp_msg = "cannot open";
                break;

            case VDEV_AUX_BAD_GUID_SUM:
                tmp_msg = "missing device";
                break;

            case VDEV_AUX_NO_REPLICAS:
                tmp_msg = "insufficient replicas";
                break;

            case VDEV_AUX_VERSION_NEWER:
                tmp_msg = "newer version";
                break;

            case VDEV_AUX_UNSUP_FEAT:
                tmp_msg = "unsupported feature(s)";
                break;

            case VDEV_AUX_ERR_EXCEEDED:
                tmp_msg = "too many errors";
                break;

            case VDEV_AUX_CHILDREN_OFFLINE:
                tmp_msg = "all children offline";
                break;

            default:
                tmp_msg = "corrupted data";
                break;
            }
            (*config)->msg = malloc(strlen(tmp_msg) + 1);
            snprintf((*config)->msg, strlen(tmp_msg) + 1, "%s", tmp_msg);
        }
    }

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
        &child, &children) != 0) {
        if ((*config)->msg != NULL)
            free((*config)->msg);
        return;
    }

    for (c = 0; c < children; c++) {
        uint64_t is_log = B_FALSE;
        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_LOG,
            &is_log);
        if (is_log)
            continue;
        (*config)->config_count++;
        (*config)->config_list = realloc((*config)->config_list, sizeof(kzpool_import_config_t *) * (*config)->config_count); /*TODO free*/
        kzpool_import_config_t *imp_conf = NULL;
        vname = zpool_vdev_name(g_zfs, NULL, child[c], B_TRUE);
        zpool_get_import_config(g_zfs, vname, child[c], depth + 2, &imp_conf);
        (*config)->config_list[(*config)->config_count - 1] = imp_conf;
        free(vname);
    }

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_L2CACHE,
        &child, &children) == 0) {
        for (c = 0; c < children; c++) {
            (*config)->cache_count++;
            (*config)->cache_list = realloc((*config)->cache_list, (*config)->cache_count - 1); /*TODO free*/
            vname = zpool_vdev_name(g_zfs, NULL, child[c], B_FALSE);
            (*config)->cache_list[(*config)->cache_count - 1] = malloc(strlen(vname) + 1); /*TODO free*/
            snprintf((*config)->cache_list[(*config)->cache_count - 1], strlen(vname) + 1, "%s", vname);
            free(vname);
        }
    }

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_SPARES,
        &child, &children) == 0) {
        for (c = 0; c < children; c++) {
            (*config)->spares_count++;
            (*config)->spares_list = realloc((*config)->spares_list, (*config)->spares_count - 1); /*TODO free*/
            vname = zpool_vdev_name(g_zfs, NULL, child[c], B_FALSE);
            (*config)->spares_list[(*config)->spares_count - 1] = malloc(strlen(vname) + 1); /*TODO free*/
            snprintf((*config)->spares_list[(*config)->spares_count - 1], strlen(vname) + 1, "%s", vname);
            free(vname);
        }
    }
}







/* FUNCTIONS */

static int
zfs_dataset_rb(const char *zname, long recursive)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "libzfs_init failed");
#endif
        return (1);
    }

    destroy_cbdata_t cb = { 0 };
    cb.g_zfs = g_zfs;
    int rv = 0;
    int err = 0;
    zfs_handle_t *zhp = NULL;
    char *at, *pound;
    zfs_type_t type = ZFS_TYPE_DATASET;
    cb.cb_force = B_TRUE;
    cb.cb_recurse = recursive;

    if ((zhp = zfs_open(g_zfs, zname, type)) == NULL) {
#ifdef ZDEBUG
        printf("%s\n", "zfs_open failed");
#endif
        libzfs_fini(g_zfs);
        return (1);
    }

    cb.cb_target = zhp;

    if (!cb.cb_recurse && strchr(zfs_get_name(zhp), '/') == NULL &&
        zfs_get_type(zhp) == ZFS_TYPE_FILESYSTEM) {
#ifdef ZDEBUG
        printf("%s\n", "not recurse and missed '/' and not a filesystem");
#endif
        libzfs_fini(g_zfs);
        return (1);
    }

    cb.cb_first = B_TRUE;

    if (zfs_iter_dependents(zhp, B_FALSE, destroy_check_dependent,
        &cb) != 0) {
#ifdef ZDEBUG
        printf("%s\n", "zfs_iter_dependents for check failed");
#endif
        rv = 1;
        goto out;
    }
    if (cb.cb_error) {
#ifdef ZDEBUG
        printf("%s\n", "error occured");
#endif
        rv = 1;
        goto out;
    }

    cb.cb_batchedsnaps = fnvlist_alloc();
    if (zfs_iter_dependents(zhp, B_FALSE, destroy_callback,
        &cb) != 0) {
#ifdef ZDEBUG
        printf("%s\n", "zfs_iter_dependents for destroy failed");
#endif
        rv = 1;
        goto out;
    }

    err = destroy_callback(zhp, &cb);
    zhp = NULL;
    if (err == 0) {
        err = zfs_destroy_snaps_nvl(g_zfs,
            cb.cb_batchedsnaps, cb.cb_defer_destroy);
    }
    if (err != 0) {
#ifdef ZDEBUG
        printf("%s\n", "zfs_destroy_snaps_nvl failed");
#endif
        rv = 1;
    }
    
out:
    fnvlist_free(cb.cb_batchedsnaps);
    fnvlist_free(cb.cb_nvl);
    if (zhp != NULL)
        zfs_close(zhp);
    libzfs_fini(g_zfs);
    return (rv);
}

static int
destroy_callback(zfs_handle_t *zhp, void *data)
{
    destroy_cbdata_t *cb = data;
    libzfs_handle_t *g_zfs = cb->g_zfs;
    const char *name = zfs_get_name(zhp);

    if (strchr(zfs_get_name(zhp), '/') == NULL &&
        zfs_get_type(zhp) == ZFS_TYPE_FILESYSTEM) {
        zfs_close(zhp);
        return (0);
    }
    if (cb->cb_dryrun) {
        zfs_close(zhp);
        return (0);
    }

    if (zfs_get_type(zhp) == ZFS_TYPE_SNAPSHOT) {
        fnvlist_add_boolean(cb->cb_batchedsnaps, name);
    } else {
        int error = zfs_destroy_snaps_nvl(g_zfs,
            cb->cb_batchedsnaps, B_FALSE);
        fnvlist_free(cb->cb_batchedsnaps);
        cb->cb_batchedsnaps = fnvlist_alloc();

        if (error != 0 ||
            zfs_unmount(zhp, NULL, cb->cb_force ? MS_FORCE : 0) != 0 ||
            zfs_destroy(zhp, cb->cb_defer_destroy) != 0) {
            zfs_close(zhp);
            return (-1);
        }
    }

    zfs_close(zhp);
    return (0);
}

static int
destroy_check_dependent(zfs_handle_t *zhp, void *data)
{
    destroy_cbdata_t *cbp = data;
    const char *tname = zfs_get_name(cbp->cb_target);
    const char *name = zfs_get_name(zhp);

    if (strncmp(tname, name, strlen(tname)) == 0 &&
        (name[strlen(tname)] == '/' || name[strlen(tname)] == '@')) {
        /*
         * This is a direct descendant, not a clone somewhere else in
         * the hierarchy.
         */
        if (cbp->cb_recurse)
            goto out;

        if (cbp->cb_first) {
            cbp->cb_first = B_FALSE;
            cbp->cb_error = B_TRUE;
        }

    } else {
        /*
         * This is a clone.  We only want to report this if the '-r'
         * wasn't specified, or the target is a snapshot.
         */
        if (!cbp->cb_recurse &&
            zfs_get_type(cbp->cb_target) != ZFS_TYPE_SNAPSHOT)
            goto out;

        if (cbp->cb_first) {
            cbp->cb_first = B_FALSE;
            cbp->cb_error = B_TRUE;
            cbp->cb_dryrun = B_TRUE;
        }
    }

out:
    zfs_close(zhp);
    return (0);
}
static int
zfs_snapshot_cb(zfs_handle_t *zhp, void *arg)
{
    snap_cbdata_t *sd = arg;
    char *name;
    int rv = 0;
    int error;

    if (sd->sd_recursive &&
        zfs_prop_get_int(zhp, ZFS_PROP_INCONSISTENT) != 0) {
        zfs_close(zhp);
        return (0);
    }

    error = asprintf(&name, "%s@%s", zfs_get_name(zhp), sd->sd_snapname);
    if (error == -1) {
        return (-1);
    }
    fnvlist_add_boolean(sd->sd_nvl, name);
    free(name);

    if (sd->sd_recursive)
        rv = zfs_iter_filesystems(zhp, zfs_snapshot_cb, sd);
    zfs_close(zhp);
    return (rv);
}


static int
zfs_snapshot_rb(const char *zname, const char *snapname, long recursive)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return (1);
    }

    destroy_cbdata_t cb = { 0 };
    zfs_handle_t *zhp = NULL;
    cb.cb_recurse = recursive;
    cb.cb_nvl = fnvlist_alloc();
    zhp = zfs_open(g_zfs, zname,
        ZFS_TYPE_FILESYSTEM | ZFS_TYPE_VOLUME);
    if (zhp == NULL) {
        fnvlist_free(cb.cb_nvl);
        libzfs_fini(g_zfs);
        return (1);
    }
    cb.cb_snapspec = snapname;
    int ret = gather_snapshots(zfs_handle_dup(zhp), &cb);
    zfs_close(zhp);

    if (ret != 0 || cb.cb_error) {
        fnvlist_free(cb.cb_nvl);
        libzfs_fini(g_zfs);
        return (1);
    }

    if (nvlist_empty(cb.cb_nvl)) {
        fnvlist_free(cb.cb_nvl);
        libzfs_fini(g_zfs);
        return (1);
    }
    ret = zfs_destroy_snaps_nvl(g_zfs, cb.cb_nvl,
                    B_FALSE);

    fnvlist_free(cb.cb_nvl);

    libzfs_fini(g_zfs);
    return (ret);
}

static int
gather_snapshots(zfs_handle_t *zhp, void *arg)
{
    destroy_cbdata_t *cb = arg;
    int err = 0;

    err = zfs_iter_snapspec(zhp, cb->cb_snapspec, snapshot_to_nvl_cb, cb);
    if (err == ENOENT)
        err = 0;
    if (err != 0) {
        zfs_close(zhp);
        return (err);
    }

    if (cb->cb_recurse)
        err = zfs_iter_filesystems(zhp, gather_snapshots, cb);

    zfs_close(zhp);
    return (err);
}

static int
snapshot_to_nvl_cb(zfs_handle_t *zhp, void *arg)
{
    destroy_cbdata_t *cb = arg;
    int err = 0;

    cb->cb_target = zhp;
    cb->cb_first = B_TRUE;
    err = zfs_iter_dependents(zhp, B_TRUE,
        destroy_check_dependent, cb);
    if (err == 0) {
        nvlist_add_boolean(cb->cb_nvl, zfs_get_name(zhp));
    }
    zfs_close(zhp);
    return (err);
}

static int
unshare_unmount_path(libzfs_handle_t *g_zfs, const char *path, int flags, boolean_t is_manual)
{
    zfs_handle_t *zhp;
    int ret = 0;
    struct stat64 statbuf;
    struct extmnttab entry;
    const char *cmdname = "unmount";
    ino_t path_inode;

    if (stat64(path, &statbuf) != 0) {
        return (1);
    }
    path_inode = statbuf.st_ino;
    struct statfs sfs;

    if (statfs(path, &sfs) != 0) {
        ret = -1;
    }
    statfs2mnttab(&sfs, &entry);
    if (ret != 0) {
        return (ret != 0);
    }

    if (strcmp(entry.mnt_fstype, MNTTYPE_ZFS) != 0) {
        return (1);
    }

    if ((zhp = zfs_open(g_zfs, entry.mnt_special,
        ZFS_TYPE_FILESYSTEM)) == NULL)
        return (1);

    ret = 1;
    if (stat64(entry.mnt_mountp, &statbuf) != 0) {
        goto out;
    } else if (statbuf.st_ino != path_inode) {
        goto out;
    }

    char mtpt_prop[ZFS_MAXPROPLEN];

    zfs_prop_get(zhp, ZFS_PROP_MOUNTPOINT, mtpt_prop,
        sizeof (mtpt_prop), NULL, NULL, 0, B_FALSE);

    if (is_manual) {
        ret = zfs_unmount(zhp, NULL, flags);
    } else if (strcmp(mtpt_prop, "legacy") == 0) {
    } else {
        ret = zfs_unmountall(zhp, flags);
    }

out:
    zfs_close(zhp);

    return (ret != 0);
}

static int
unshare_unmount_compare(const void *larg, const void *rarg, void *unused)
{
    const unshare_unmount_node_t *l = larg;
    const unshare_unmount_node_t *r = rarg;

    return (strcmp(l->un_mountp, r->un_mountp));
}

static int
share_mount_one(zfs_handle_t *zhp, int op, int flags, char *protocol,
    boolean_t explicit, const char *options)
{
    char mountpoint[ZFS_MAXPROPLEN];
    char shareopts[ZFS_MAXPROPLEN];
    char smbshareopts[ZFS_MAXPROPLEN];
    const char *cmdname = op == OP_SHARE ? "share" : "mount";
    struct mnttab mnt;
    uint64_t zoned, canmount;
    boolean_t shared_nfs, shared_smb;

    assert(zfs_get_type(zhp) & ZFS_TYPE_FILESYSTEM);

    zoned = zfs_prop_get_int(zhp, ZFS_PROP_ZONED);

    if (zoned && getzoneid() == GLOBAL_ZONEID) {
        if (!explicit)
            return (0);
        return (1);

    } else if (!zoned && getzoneid() != GLOBAL_ZONEID) {
        if (!explicit)
            return (0);
        return (1);
    }

    zfs_prop_get(zhp, ZFS_PROP_MOUNTPOINT, mountpoint,
        sizeof (mountpoint), NULL, NULL, 0, B_FALSE);
    zfs_prop_get(zhp, ZFS_PROP_SHARENFS, shareopts,
        sizeof (shareopts), NULL, NULL, 0, B_FALSE);
    zfs_prop_get(zhp, ZFS_PROP_SHARESMB, smbshareopts,
        sizeof (smbshareopts), NULL, NULL, 0, B_FALSE);

    if (op == OP_SHARE && strcmp(shareopts, "off") == 0 &&
        strcmp(smbshareopts, "off") == 0) {
        if (!explicit)
            return (0);
        return (1);
    }
    if (strcmp(mountpoint, "legacy") == 0) {
        if (!explicit)
            return (0);
        return (1);
    }

    if (strcmp(mountpoint, "none") == 0) {
        if (!explicit)
            return (0);
        return (1);
    }

    canmount = zfs_prop_get_int(zhp, ZFS_PROP_CANMOUNT);
    if (canmount == ZFS_CANMOUNT_OFF) {
        if (!explicit)
            return (0);
        return (1);
    } else if (canmount == ZFS_CANMOUNT_NOAUTO && !explicit) {
        return (0);
    }

    if (zfs_prop_get_int(zhp, ZFS_PROP_INCONSISTENT) &&
        zfs_prop_get(zhp, ZFS_PROP_RECEIVE_RESUME_TOKEN,
        NULL, 0, NULL, NULL, 0, B_TRUE) == 0) {
        if (!explicit)
            return (0);
        return (1);
    }

    switch (op) {
    case OP_SHARE:

        shared_nfs = zfs_is_shared_nfs(zhp, NULL);
        shared_smb = zfs_is_shared_smb(zhp, NULL);

        if ((shared_nfs && shared_smb) ||
            (shared_nfs && strcmp(shareopts, "on") == 0 &&
            strcmp(smbshareopts, "off") == 0) ||
            (shared_smb && strcmp(smbshareopts, "on") == 0 &&
            strcmp(shareopts, "off") == 0)) {
            if (!explicit)
                return (0);
            return (1);
        }

        if (!zfs_is_mounted(zhp, NULL) &&
            zfs_mount(zhp, NULL, 0) != 0)
            return (1);

        if (protocol == NULL) {
            if (zfs_shareall(zhp) != 0)
                return (1);
        } else if (strcmp(protocol, "nfs") == 0) {
            if (zfs_share_nfs(zhp))
                return (1);
        } else if (strcmp(protocol, "smb") == 0) {
            if (zfs_share_smb(zhp))
                return (1);
        } else {
            return (1);
        }

        break;

    case OP_MOUNT:
        if (options == NULL)
            mnt.mnt_mntopts = "";
        else
            mnt.mnt_mntopts = (char *)options;

        if (!hasmntopt(&mnt, MNTOPT_REMOUNT) &&
            zfs_is_mounted(zhp, NULL)) {
            if (!explicit)
                return (0);
            return (1);
        }

        if (zfs_mount(zhp, options, flags) != 0)
            return (1);
        break;
    }

    return (0);
}

#ifdef BSD112

static void
get_all_datasets(libzfs_handle_t *g_zfs, zfs_handle_t ***dslist, size_t *count)
{
    get_all_cb_t cb = { 0 };
    cb.cb_verbose = 0;
    cb.cb_getone = get_one_dataset;

    (void) zfs_iter_root(g_zfs, get_one_dataset, &cb);

    *dslist = cb.cb_handles;
    *count = cb.cb_used;
}

#elif defined(BSD12) || defined(BSD113)

static int
share_mount_one_cb(zfs_handle_t *zhp, void *arg)
{
    share_mount_state_t *sms = arg;
    int ret;

    ret = share_mount_one(zhp, sms->sm_op, sms->sm_flags, sms->sm_proto,
        B_FALSE, sms->sm_options);

    pthread_mutex_lock(&sms->sm_lock);
    if (ret != 0)
        sms->sm_status = ret;
    sms->sm_done++;
    pthread_mutex_unlock(&sms->sm_lock);
    return (ret);
}
static void
get_all_datasets(libzfs_handle_t *g_zfs, get_all_cb_t *cbp, boolean_t verbose)
{
    get_all_state_t state = {
        .ga_verbose = verbose,
        .ga_cbp = cbp
    };

    (void) zfs_iter_root(g_zfs, get_one_dataset, &state);
}
#endif

static int
get_one_dataset(zfs_handle_t *zhp, void *data)
{
    static char *spin[] = { "-", "\\", "|", "/" };
    static int spinval = 0;
    static int spincheck = 0;
    static time_t last_spin_time = (time_t)0;
    get_all_cb_t *cbp = data;
    zfs_type_t type = zfs_get_type(zhp);

    if (zfs_iter_filesystems(zhp, get_one_dataset, data) != 0) {
        zfs_close(zhp);
        return (1);
    }

    if ((type & ZFS_TYPE_FILESYSTEM) == 0) {
        zfs_close(zhp);
        return (0);
    }
    libzfs_add_handle(cbp, zhp);
    assert(cbp->cb_used <= cbp->cb_alloc);

    return (0);
}

static int
zfs_snap_callback(zfs_handle_t *zhp, void *data)
{
    callback_data_t *cb = data;
    char buf[ZFS_MAXPROPLEN];
    char source[ZFS_MAX_DATASET_NAME_LEN];
    zprop_source_t sourcetype;
    boolean_t should_close = B_TRUE;
    // if ((zfs_get_type(zhp) == ZFS_TYPE_FILESYSTEM && (cb->cb_types & ZFS_TYPE_SNAPSHOT)) || zfs_get_type(zhp) == ZFS_TYPE_SNAPSHOT) {
    if (zfs_get_type(zhp) == ZFS_TYPE_SNAPSHOT) {
        const char *zname = zfs_get_name(zhp);
        kzfs_snap_list_st_t *list = cb->tmp;
        list->count++;
        list->list = realloc(list->list, (sizeof(kzfs_snap_t*))*list->count);
        if (list->list == NULL) {
            return -1;
        }
        int cur = list->count - 1;
        list->list[cur] = malloc(sizeof(kzfs_snap_t));
        if (list->list[cur] == NULL) {
            if (!cur) {
                free(list->list);
            } else {
                /*TODO free list*/
            }
            return -1;
        }
        memset(buf, 0, sizeof(buf));
        int ret = zfs_prop_get(zhp, ZFS_PROP_USED, buf,
                sizeof (buf), &sourcetype, source,
                sizeof (source),
                B_FALSE);
        list->list[cur]->used = malloc(strlen(buf) + 1);
        if (list->list[cur]->used == NULL) {
            if (!cur) {
                free(list->list[cur]);
                free(list->list);
            } else {
                /*TODO free list*/
            }
            return -1;
        }
        snprintf(list->list[cur]->used, strlen(buf) + 1, "%s", buf);
        uint64_t date = 0;
        zfs_prop_get_numeric(zhp, ZFS_PROP_CREATION, &date,
            NULL, NULL, 0);
        list->list[cur]->creation = date;
        char *strval = NULL;//kzfs_get_uprop(zname, "snap:desc");
        nvlist_t *userprops, *propval;
        char *source_s = NULL;
        userprops = zfs_get_user_props(zhp);
        
        if (nvlist_lookup_nvlist(userprops, "snap:desc",
            &propval) == 0) {
                if (nvlist_lookup_string(propval, ZPROP_VALUE, &source_s) == 0) {
                    strval = fnvlist_lookup_string(propval, ZPROP_VALUE);
                    (void) nvlist_lookup_string(propval, ZPROP_SOURCE, &source_s);
                }
        } else {
            strval = NULL;
        }
        list->list[cur]->desc = malloc((strval == NULL ? 0 : strlen(strval)) + 1);
        if (list->list[cur]->desc == NULL) {
            if (!cur) {
                free(list->list[cur]->used);
                free(list->list[cur]);
                free(list->list);
            } else {
                /*TODO free list*/
            }
            return -1;
        }
        snprintf(list->list[cur]->desc, (strval == NULL ? 0 : strlen(strval)) + 1, "%s", strval == NULL ? "" : strval);
        char *p = strchr(zname, '@');
        p++;
        list->list[cur]->snapname = malloc(strlen(p) + 1);
        if (list->list[cur]->snapname == NULL) {
            if (!cur) {
                free(list->list[cur]->desc);
                free(list->list[cur]->used);
                free(list->list[cur]);
                free(list->list);
            } else {
                /*TODO free list*/
            }
            return -1;
        }
        snprintf(list->list[cur]->snapname, strlen(p) + 1, "%s", p);
    } else {
        (void) zfs_iter_snapshots(zhp,
            B_FALSE, zfs_snap_callback,
            data);
    }
    // }
    if (should_close)
        zfs_close(zhp);

    return 0;
}

static int
zfs_ds_callback(zfs_handle_t *zhp, void *data)
{
    callback_data_t *cb = data;
    char buf[ZFS_MAXPROPLEN];
    char source[ZFS_MAX_DATASET_NAME_LEN];
    zprop_source_t sourcetype;
    if ((zfs_get_type(zhp) == ZFS_TYPE_FILESYSTEM || zfs_get_type(zhp) == ZFS_TYPE_VOLUME) && (cb->cb_types & ZFS_TYPE_SNAPSHOT) == 0) {
        kzfs_ds_list_t *ds_list = cb->tmp;
        ds_list->count++;
        int cur = ds_list->count - 1;
        ds_list->ds_info_list = realloc(ds_list->ds_info_list, sizeof(kzfs_ds_info_t *) * ds_list->count);
        if (ds_list->ds_info_list == NULL) {
            /* TODO free list if not 1==count */
            return -1;
        }
        ds_list->ds_info_list[cur] = malloc(sizeof(kzfs_ds_info_t));
        ds_list->ds_info_list[cur]->zname = malloc(strlen(zfs_get_name(zhp)) + 1);
        snprintf(ds_list->ds_info_list[cur]->zname, strlen(zfs_get_name(zhp)) + 1, "%s", zfs_get_name(zhp));
        kzfs_prop_list_t *props = cb->proplist;
        ds_list->ds_info_list[cur]->propval_list = NULL;
        if (props != NULL) {
            ds_list->ds_info_list[cur]->propval_list = malloc(sizeof(kzfs_propval_list_t));
            kzfs_propval_list_t *propval_list = ds_list->ds_info_list[cur]->propval_list;
            propval_list->count = props->count;
            propval_list->props = malloc((sizeof(char *))*propval_list->count);
            propval_list->values = malloc((sizeof(char *))*propval_list->count);
            nvlist_t *userprops = zfs_get_user_props(zhp);
            for (int i = 0; i < props->count; i++) {
                zfs_prop_t prop_n = zfs_name_to_prop(props->props[i]);
                propval_list->props[i] = malloc(strlen(props->props[i]) + 1);
                snprintf(propval_list->props[i], strlen(props->props[i]) + 1, "%s", props->props[i]);
                if (prop_n != ZPROP_INVAL) {
                    if (prop_n == ZFS_PROP_CREATION) {
                        uint64_t date = 0;
                        zfs_prop_get_numeric(zhp, ZFS_PROP_CREATION, &date,
                            NULL, NULL, 0);
                        int len = snprintf(NULL, 0, "%lu", date);
                        propval_list->values[i] = malloc(len + 1);
                        snprintf(propval_list->values[i], len + 1, "%lu", date);
                    } else {
                        if (zfs_prop_get(zhp, prop_n, buf,
                                sizeof (buf), &sourcetype, source,
                                sizeof (source),
                                B_FALSE) != 0) {
                            snprintf(buf, sizeof(buf), "%s", "-");
                        }
                        propval_list->values[i] = malloc(strlen(buf) + 1);
                        snprintf(propval_list->values[i], strlen(buf) + 1, "%s", buf);
                    }
                } else {
                    nvlist_t *propval;
                    char *sourceval;
                    char *propstr;
                    if (nvlist_lookup_nvlist(userprops,
                        props->props[i], &propval) == 0) {
                        if (nvlist_lookup_string(propval,
                            ZPROP_SOURCE, &sourceval) == 0) {
                            if (strcmp(sourceval,
                            zfs_get_name(zhp)) == 0 || strcmp(sourceval,
                            ZPROP_SOURCE_VAL_RECVD) == 0) {
                                if (nvlist_lookup_string(propval,
                                    ZPROP_VALUE, &propstr) != 0) {
                                    propstr = "-";
                                }
                            } else {
                                propstr = "-";
                            }
                        } else {
                            propstr = "-";
                        }
                    } else {
                        propstr = "-";
                    }
                    propval_list->values[i] = malloc(strlen(propstr) + 1);
                    snprintf(propval_list->values[i], strlen(propstr) + 1, "%s", propstr);
                }
            }
        }
        (void) zfs_iter_filesystems(zhp, zfs_ds_callback, cb);
    }
    zfs_close(zhp);

    return 0;
}


static boolean_t
should_auto_mount(zfs_handle_t *zhp)
{
    if (!zfs_prop_valid_for_type(ZFS_PROP_CANMOUNT, zfs_get_type(zhp)))
        return (B_FALSE);
    return (zfs_prop_get_int(zhp, ZFS_PROP_CANMOUNT) == ZFS_CANMOUNT_ON);
}

static int
add_prop_list(const char *propname, char *propval, nvlist_t **props,
    boolean_t poolprop)
{
    zpool_prop_t prop = ZPOOL_PROP_INVAL;
    zfs_prop_t fprop;
    nvlist_t *proplist;
    const char *normnm;
    char *strval;

    if (*props == NULL &&
        nvlist_alloc(props, NV_UNIQUE_NAME, 0) != 0) {
        return (1);
    }

    proplist = *props;

    if (poolprop) {
        const char *vname = zpool_prop_to_name(ZPOOL_PROP_VERSION);

        if ((prop = zpool_name_to_prop(propname)) == ZPROP_INVAL &&
            !zpool_prop_feature(propname)) {
            return (2);
        }

        /*
         * feature@ properties and version should not be specified
         * at the same time.
         */
        if ((prop == ZPOOL_PROP_INVAL && zpool_prop_feature(propname) &&
            nvlist_exists(proplist, vname)) ||
            (prop == ZPOOL_PROP_VERSION &&
            prop_list_contains_feature(proplist))) {
            return (2);
        }


        if (zpool_prop_feature(propname))
            normnm = propname;
        else
            normnm = zpool_prop_to_name(prop);
    } else {
        if ((fprop = zfs_name_to_prop(propname)) != ZPROP_INVAL) {
            normnm = zfs_prop_to_name(fprop);
        } else {
            normnm = propname;
        }
    }

    if (nvlist_lookup_string(proplist, normnm, &strval) == 0 &&
        prop != ZPOOL_PROP_CACHEFILE) {
        return (2);
    }

    if (nvlist_add_string(proplist, normnm, propval) != 0) {
        return (1);
    }

    return (0);
}

static int
add_prop_list_default(const char *propname, char *propval, nvlist_t **props,
    boolean_t poolprop)
{
    char *pval;

    if (nvlist_lookup_string(*props, propname, &pval) == 0)
        return (0);

    return (add_prop_list(propname, propval, props, poolprop));
}
static boolean_t
prop_list_contains_feature(nvlist_t *proplist)
{
    nvpair_t *nvp;
    for (nvp = nvlist_next_nvpair(proplist, NULL); NULL != nvp;
        nvp = nvlist_next_nvpair(proplist, nvp)) {
        if (zpool_prop_feature(nvpair_name(nvp)))
            return (B_TRUE);
    }
    return (B_FALSE);
}
static nvlist_t *
make_root_vdev(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, int force, int check_rep,
    boolean_t replacing, boolean_t dryrun, zpool_boot_label_t boot_type,
    uint64_t boot_size, kzpool_dev_list_t *devs)
{
    nvlist_t *newroot = NULL;
    nvlist_t *poolconfig = NULL;

    if ((newroot = construct_spec(devs)) == NULL) {
        return (NULL);
    }

    if (zhp && ((poolconfig = zpool_get_config(zhp, NULL)) == NULL))
        return (NULL);

    if (is_device_in_use(g_zfs, NULL, newroot, force, replacing, B_FALSE)) {
        nvlist_free(newroot);
        return (NULL);
    }

    if (check_rep && check_replication(poolconfig, newroot) != 0) {
        nvlist_free(newroot);
        return (NULL);
    }

#ifdef illumos
    if (!dryrun && make_disks(zhp, newroot, boot_type, boot_size) != 0) {
        nvlist_free(newroot);
        return (NULL);
    }
#endif

    return (newroot);
}

static void
zpool_dev_list_sort(kzpool_dev_list_t *devs)
{
    if (devs == NULL)
        return;

    int log_index = -1;

    for (int i = 0; i < devs->count; i++) {
        if (devs->list[i]->is_log)
            log_index = i;
    }

    if (log_index < 0)
        return;

    if (log_index == (devs->count - 1))
        return;

    kzpool_dev_info_t *tmp = devs->list[log_index];
    devs->list[log_index] = devs->list[devs->count - 1];
    devs->list[devs->count - 1] = tmp;
}

static nvlist_t *
construct_spec(kzpool_dev_list_t *devs)
{
    nvlist_t *nvroot, *nv, **top, **spares, **l2cache;
    int t, toplevels, mindev, maxdev, nspares, nlogs, nl2cache;
    const char *type;
    uint64_t is_log;
    boolean_t seen_logs;

    top = NULL;
    toplevels = 0;
    spares = NULL;
    l2cache = NULL;
    nspares = 0;
    nlogs = 0;
    nl2cache = 0;
    is_log = B_FALSE;
    seen_logs = B_FALSE;

    if (devs != NULL) {
        zpool_dev_list_sort(devs);
        for(int q = 0; q < devs->count; q++) {
            kzpool_dev_info_t *el = devs->list[q];
            if (el->is_log) {
                if (seen_logs) {
                    return (NULL);
                }
                is_log = B_TRUE;
                seen_logs = B_TRUE;
            }
            nv = NULL;
            if (el->is_complex) {

                for (int i = 0; i < el->count; i++) {
                    kzpool_dev_info_t *subel = (kzpool_dev_info_t *)el->devs[i];

                    if ((type = is_grouping(subel->type, &mindev, &maxdev)) != NULL) {
                        nvlist_t **child = NULL;
                        int c, children = 0;

                        if (strcmp(type, VDEV_TYPE_SPARE) == 0) {
                            if (spares != NULL) {
                                return (NULL);
                            }
                            is_log = B_FALSE;
                        }

                        if (strcmp(type, VDEV_TYPE_L2CACHE) == 0) {
                            if (l2cache != NULL) {
                                return (NULL);
                            }
                            is_log = B_FALSE;
                        }
                        if (is_log) {
                            if (strcmp(type, VDEV_TYPE_MIRROR) != 0) {
                                return (NULL);
                            }
                            nlogs++;
                        }
                        for (int i = 0; i < subel->count; i++) {
                            children++;
                            child = realloc(child,
                                children * sizeof (nvlist_t *));
                            if (child == NULL)
                                return (NULL);
                            if ((nv = make_leaf_vdev((char *) subel->devs[i], B_FALSE))
                                == NULL)
                                return (NULL);
                            child[children - 1] = nv;
                        }

                        if (children < mindev) {
                            return (NULL);
                        }

                        if (children > maxdev) {
                            return (NULL);
                        }

                        if (strcmp(type, VDEV_TYPE_SPARE) == 0) {
                            spares = child;
                            nspares = children;
                            continue;
                        } else if (strcmp(type, VDEV_TYPE_L2CACHE) == 0) {
                            l2cache = child;
                            nl2cache = children;
                            continue;
                        } else {
                            nvlist_alloc(&nv, NV_UNIQUE_NAME,
                                0);
                            nvlist_add_string(nv, ZPOOL_CONFIG_TYPE,
                                type);
                            nvlist_add_uint64(nv,
                                ZPOOL_CONFIG_IS_LOG, is_log);
                            if (strcmp(type, VDEV_TYPE_RAIDZ) == 0) {
                                nvlist_add_uint64(nv,
                                    ZPOOL_CONFIG_NPARITY,
                                    mindev - 1);
                            }
                            nvlist_add_nvlist_array(nv,
                                ZPOOL_CONFIG_CHILDREN, child,
                                children);

                            for (c = 0; c < children; c++)
                                nvlist_free(child[c]);
                            free(child);
                        }

                        toplevels++;
                        top = realloc(top, toplevels * sizeof (nvlist_t *));
                        if (top == NULL)
                            return NULL;
                        top[toplevels - 1] = nv;
                    } else {
                        for (int j = 0; j < subel->count; j++) {
                            if ((nv = make_leaf_vdev((char *) subel->devs[j], is_log)) == NULL) {
                                return (NULL);
                            }
                            if (is_log)
                                nlogs++;

                            toplevels++;
                            top = realloc(top, toplevels * sizeof (nvlist_t *));
                            if (top == NULL) {
                                return NULL;
                            }
                            top[toplevels - 1] = nv;
                        }
                    }
                }
            } else {
                if ((type = is_grouping(el->type, &mindev, &maxdev)) != NULL) {
                    nvlist_t **child = NULL;
                    int c, children = 0;

                    if (strcmp(type, VDEV_TYPE_SPARE) == 0) {
                        if (spares != NULL) {
                            return (NULL);
                        }
                        is_log = B_FALSE;
                    }

                    if (strcmp(type, VDEV_TYPE_L2CACHE) == 0) {
                        if (l2cache != NULL) {
                            return (NULL);
                        }
                        is_log = B_FALSE;
                    }
                    if (is_log) {
                        if (strcmp(type, VDEV_TYPE_MIRROR) != 0) {
                            return (NULL);
                        }
                        nlogs++;
                    }
                    for (int i = 0; i < el->count; i++) {
                        children++;
                        child = realloc(child,
                            children * sizeof (nvlist_t *));
                        if (child == NULL)
                            return (NULL);
                        if ((nv = make_leaf_vdev((char *) el->devs[i], B_FALSE))
                            == NULL)
                            return (NULL);
                        child[children - 1] = nv;
                    }

                    if (children < mindev) {
                        return (NULL);
                    }

                    if (children > maxdev) {
                        return (NULL);
                    }

                    if (strcmp(type, VDEV_TYPE_SPARE) == 0) {
                        spares = child;
                        nspares = children;
                        continue;
                    } else if (strcmp(type, VDEV_TYPE_L2CACHE) == 0) {
                        l2cache = child;
                        nl2cache = children;
                        continue;
                    } else {
                        nvlist_alloc(&nv, NV_UNIQUE_NAME,
                            0);
                        nvlist_add_string(nv, ZPOOL_CONFIG_TYPE,
                            type);
                        nvlist_add_uint64(nv,
                            ZPOOL_CONFIG_IS_LOG, is_log);
                        if (strcmp(type, VDEV_TYPE_RAIDZ) == 0) {
                            nvlist_add_uint64(nv,
                                ZPOOL_CONFIG_NPARITY,
                                mindev - 1);
                        }
                        nvlist_add_nvlist_array(nv,
                            ZPOOL_CONFIG_CHILDREN, child,
                            children);

                        for (c = 0; c < children; c++)
                            nvlist_free(child[c]);
                        free(child);
                    }

                    toplevels++;
                    top = realloc(top, toplevels * sizeof (nvlist_t *));
                    if (top == NULL)
                        return NULL;
                    top[toplevels - 1] = nv;
                } else {
                    for (int i = 0; i < el->count; i++) {
                        if ((nv = make_leaf_vdev((char *) el->devs[i], is_log)) == NULL) {
                            return (NULL);
                        }
                        if (is_log)
                            nlogs++;

                        toplevels++;
                        top = realloc(top, toplevels * sizeof (nvlist_t *));
                        if (top == NULL)
                            return NULL;
                        top[toplevels - 1] = nv;
                    }
                }
            }
        }
    }
    if (toplevels == 0 && nspares == 0 && nl2cache == 0) {
        return (NULL);
    }

    if (seen_logs && nlogs == 0) {
        return (NULL);
    }

    /*
     * Finally, create nvroot and add all top-level vdevs to it.
     */
    nvlist_alloc(&nvroot, NV_UNIQUE_NAME, 0);
    nvlist_add_string(nvroot, ZPOOL_CONFIG_TYPE,
        VDEV_TYPE_ROOT);
    nvlist_add_nvlist_array(nvroot, ZPOOL_CONFIG_CHILDREN,
        top, toplevels);
    if (nspares != 0)
        nvlist_add_nvlist_array(nvroot, ZPOOL_CONFIG_SPARES,
            spares, nspares);
    if (nl2cache != 0)
        nvlist_add_nvlist_array(nvroot, ZPOOL_CONFIG_L2CACHE,
            l2cache, nl2cache);

    for (t = 0; t < toplevels; t++)
        nvlist_free(top[t]);
    for (t = 0; t < nspares; t++)
        nvlist_free(spares[t]);
    for (t = 0; t < nl2cache; t++)
        nvlist_free(l2cache[t]);
    if (spares)
        free(spares);
    if (l2cache)
        free(l2cache);
    free(top);

    return (nvroot);
}
static boolean_t
is_device_in_use(libzfs_handle_t *g_zfs, nvlist_t *config, nvlist_t *nv, boolean_t force,
    boolean_t replacing, boolean_t isspare)
{
    nvlist_t **child;
    uint_t c, children;
    char *type, *path;
    int ret = 0;
    char buf[MAXPATHLEN];
    uint64_t wholedisk;
    boolean_t anyinuse = B_FALSE;

    nvlist_lookup_string(nv, ZPOOL_CONFIG_TYPE, &type);

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
        &child, &children) != 0) {

        nvlist_lookup_string(nv, ZPOOL_CONFIG_PATH, &path);

        if (replacing) {
#ifdef illumos
            if (nvlist_lookup_uint64(nv, ZPOOL_CONFIG_WHOLE_DISK,
                &wholedisk) == 0 && wholedisk)
                (void) snprintf(buf, sizeof (buf), "%ss0",
                    path);
            else
#endif
                (void) strlcpy(buf, path, sizeof (buf));

            if (is_spare(g_zfs, config, buf))
                return (B_FALSE);
        }

        if (strcmp(type, VDEV_TYPE_DISK) == 0)
            ret = check_device(g_zfs, path, force, isspare);
        else if (strcmp(type, VDEV_TYPE_FILE) == 0)
            ret = check_file(g_zfs, path, force, isspare);

        return (ret != 0);
    }

    for (c = 0; c < children; c++)
        if (is_device_in_use(g_zfs, config, child[c], force, replacing,
            B_FALSE))
            anyinuse = B_TRUE;

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_SPARES,
        &child, &children) == 0)
        for (c = 0; c < children; c++)
            if (is_device_in_use(g_zfs, config, child[c], force, replacing,
                B_TRUE))
                anyinuse = B_TRUE;

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_L2CACHE,
        &child, &children) == 0)
        for (c = 0; c < children; c++)
            if (is_device_in_use(g_zfs, config, child[c], force, replacing,
                B_FALSE))
                anyinuse = B_TRUE;

    return (anyinuse);
}

static const char *
is_grouping(const char *type, int *mindev, int *maxdev)
{
    if (strncmp(type, "raidz", 5) == 0) {
        const char *p = type + 5;
        char *end;
        long nparity;

        if (*p == '\0') {
            nparity = 1;
        } else if (*p == '0') {
            return (NULL);
        } else {
            errno = 0;
            nparity = strtol(p, &end, 10);
            if (errno != 0 || nparity < 1 || nparity >= 255 ||
                *end != '\0')
                return (NULL);
        }

        if (mindev != NULL)
            *mindev = nparity + 1;
        if (maxdev != NULL)
            *maxdev = 255;
        return (VDEV_TYPE_RAIDZ);
    }

    if (maxdev != NULL)
        *maxdev = INT_MAX;

    if (strcmp(type, "mirror") == 0) {
        if (mindev != NULL)
            *mindev = 2;
        return (VDEV_TYPE_MIRROR);
    }

    if (strcmp(type, "spare") == 0) {
        if (mindev != NULL)
            *mindev = 1;
        return (VDEV_TYPE_SPARE);
    }

    if (strcmp(type, "log") == 0) {
        if (mindev != NULL)
            *mindev = 1;
        return (VDEV_TYPE_LOG);
    }

    if (strcmp(type, "cache") == 0) {
        if (mindev != NULL)
            *mindev = 1;
        return (VDEV_TYPE_L2CACHE);
    }

    return (NULL);
}

static int
check_device(libzfs_handle_t *g_zfs, const char *name, boolean_t force, boolean_t isspare)
{
    char path[MAXPATHLEN];

    if (strncmp(name, _PATH_DEV, sizeof(_PATH_DEV) - 1) != 0)
        snprintf(path, sizeof(path), "%s%s", _PATH_DEV, name);
    else
        strlcpy(path, name, sizeof(path));

    return (check_file(g_zfs, path, force, isspare));
}

static boolean_t
is_whole_disk(const char *arg)
{
    int fd;

    fd = g_open(arg, 0);
    if (fd >= 0) {
        g_close(fd);
        return (B_TRUE);
    }
    return (B_FALSE);
}

static boolean_t
is_spare(libzfs_handle_t *g_zfs, nvlist_t *config, const char *path)
{
    int fd;
    pool_state_t state;
    char *name = NULL;
    nvlist_t *label;
    uint64_t guid, spareguid;
    nvlist_t *nvroot;
    nvlist_t **spares;
    uint_t i, nspares;
    boolean_t inuse;

    if ((fd = open(path, O_RDONLY)) < 0)
        return (B_FALSE);

    if (zpool_in_use(g_zfs, fd, &state, &name, &inuse) != 0 ||
        !inuse ||
        state != POOL_STATE_SPARE ||
        zpool_read_label(fd, &label) != 0) {
        free(name);
        (void) close(fd);
        return (B_FALSE);
    }
    free(name);
    (void) close(fd);

    nvlist_lookup_uint64(label, ZPOOL_CONFIG_GUID, &guid);
    nvlist_free(label);

    nvlist_lookup_nvlist(config, ZPOOL_CONFIG_VDEV_TREE,
        &nvroot);
    if (nvlist_lookup_nvlist_array(nvroot, ZPOOL_CONFIG_SPARES,
        &spares, &nspares) == 0) {
        for (i = 0; i < nspares; i++) {
            nvlist_lookup_uint64(spares[i],
                ZPOOL_CONFIG_GUID, &spareguid);
            if (spareguid == guid)
                return (B_TRUE);
        }
    }

    return (B_FALSE);
}
static nvlist_t *
make_leaf_vdev(const char *arg, uint64_t is_log)
{
    char path[MAXPATHLEN];
    struct stat64 statbuf;
    nvlist_t *vdev = NULL;
    char *type = NULL;
    boolean_t wholedisk = B_FALSE;

    /*
     * Determine what type of vdev this is, and put the full path into
     * 'path'.  We detect whether this is a device of file afterwards by
     * checking the st_mode of the file.
     */
    if (arg[0] == '/') {
        /*
         * Complete device or file path.  Exact type is determined by
         * examining the file descriptor afterwards.
         */
        wholedisk = is_whole_disk(arg);
        if (!wholedisk && (stat64(arg, &statbuf) != 0)) {
            return (NULL);
        }

        (void) strlcpy(path, arg, sizeof (path));
    } else {
        /*
         * This may be a short path for a device, or it could be total
         * gibberish.  Check to see if it's a known device in
         * /dev/dsk/.  As part of this check, see if we've been given a
         * an entire disk (minus the slice number).
         */
        if (strncmp(arg, _PATH_DEV, sizeof(_PATH_DEV) - 1) == 0)
            strlcpy(path, arg, sizeof (path));
        else
            snprintf(path, sizeof (path), "%s%s", _PATH_DEV, arg);
        wholedisk = is_whole_disk(path);
        if (!wholedisk && (stat64(path, &statbuf) != 0)) {
            /*
             * If we got ENOENT, then the user gave us
             * gibberish, so try to direct them with a
             * reasonable error message.  Otherwise,
             * regurgitate strerror() since it's the best we
             * can do.
             */
            if (errno == ENOENT) {
                return (NULL);
            } else {
                return (NULL);
            }
        }
    }

#ifdef __FreeBSD__
    if (S_ISCHR(statbuf.st_mode)) {
        statbuf.st_mode &= ~S_IFCHR;
        statbuf.st_mode |= S_IFBLK;
        wholedisk = B_FALSE;
    }
#endif

    /*
     * Determine whether this is a device or a file.
     */
    if (wholedisk || S_ISBLK(statbuf.st_mode)) {
        type = VDEV_TYPE_DISK;
    } else if (S_ISREG(statbuf.st_mode)) {
        type = VDEV_TYPE_FILE;
    } else {
        return (NULL);
    }

    /*
     * Finally, we have the complete device or file, and we know that it is
     * acceptable to use.  Construct the nvlist to describe this vdev.  All
     * vdevs have a 'path' element, and devices also have a 'devid' element.
     */
    nvlist_alloc(&vdev, NV_UNIQUE_NAME, 0);
    nvlist_add_string(vdev, ZPOOL_CONFIG_PATH, path);
    nvlist_add_string(vdev, ZPOOL_CONFIG_TYPE, type);
    nvlist_add_uint64(vdev, ZPOOL_CONFIG_IS_LOG, is_log);
    if (strcmp(type, VDEV_TYPE_DISK) == 0)
        nvlist_add_uint64(vdev, ZPOOL_CONFIG_WHOLE_DISK,
            (uint64_t)wholedisk);

#ifdef have_devid
    /*
     * For a whole disk, defer getting its devid until after labeling it.
     */
    if (S_ISBLK(statbuf.st_mode) && !wholedisk) {
        /*
         * Get the devid for the device.
         */
        int fd;
        ddi_devid_t devid;
        char *minor = NULL, *devid_str = NULL;

        if ((fd = open(path, O_RDONLY)) < 0) {
            nvlist_free(vdev);
            return (NULL);
        }

        if (devid_get(fd, &devid) == 0) {
            if (devid_get_minor_name(fd, &minor) == 0 &&
                (devid_str = devid_str_encode(devid, minor)) !=
                NULL) {
                nvlist_add_string(vdev,
                    ZPOOL_CONFIG_DEVID, devid_str);
            }
            if (devid_str != NULL)
                devid_str_free(devid_str);
            if (minor != NULL)
                devid_str_free(minor);
            devid_free(devid);
        }

        (void) close(fd);
    }
#endif

    return (vdev);
}

static int
check_file(libzfs_handle_t *g_zfs, const char *file, boolean_t force, boolean_t isspare)
{
    char  *name;
    int fd;
    int ret = 0;
    int err;
    pool_state_t state;
    boolean_t inuse;


    if ((fd = open(file, O_RDONLY)) < 0)
        return (0);

    if (zpool_in_use(g_zfs, fd, &state, &name, &inuse) == 0 && inuse) {
        const char *desc;

        switch (state) {
        case POOL_STATE_ACTIVE:
            desc = gettext("active");
            break;

        case POOL_STATE_EXPORTED:
            desc = gettext("exported");
            break;

        case POOL_STATE_POTENTIALLY_ACTIVE:
            desc = gettext("potentially active");
            break;

        default:
            desc = gettext("unknown");
            break;
        }

        /*
         * Allow hot spares to be shared between pools.
         */
        if (state == POOL_STATE_SPARE && isspare)
            return (0);

        if (state == POOL_STATE_ACTIVE ||
            state == POOL_STATE_SPARE || !force) {
            switch (state) {
            case POOL_STATE_SPARE:
                break;
            default:
                break;
            }
            ret = -1;
        }

        free(name);
    }

    (void) close(fd);
    return (ret);
}

static int
check_replication(nvlist_t *config, nvlist_t *newroot)
{
    nvlist_t **child;
    uint_t  children;
    replication_level_t *current = NULL, *new;
    int ret;
    if (config != NULL) {
        nvlist_t *nvroot;

        nvlist_lookup_nvlist(config, ZPOOL_CONFIG_VDEV_TREE,
            &nvroot);
        if ((current = get_replication(nvroot, B_FALSE)) == NULL)
            return (0);
    }
    if ((nvlist_lookup_nvlist_array(newroot, ZPOOL_CONFIG_CHILDREN,
        &child, &children) != 0) || (children == 0)) {
        free(current);
        return (0);
    }

    if (num_logs(newroot) == children) {
        free(current);
        return (0);
    }

    if ((new = get_replication(newroot, B_TRUE)) == NULL) {
        free(current);
        return (-1);
    }

    ret = 0;
    if (current != NULL) {
        if (strcmp(current->zprl_type, new->zprl_type) != 0) {
            ret = -1;
        } else if (current->zprl_parity != new->zprl_parity) {
            ret = -1;
        } else if (current->zprl_children != new->zprl_children) {
            ret = -1;
        }
    }

    free(new);
    if (current != NULL)
        free(current);

    return (ret);
}

static uint_t
num_logs(nvlist_t *nv)
{
    uint_t nlogs = 0;
    uint_t c, children;
    nvlist_t **child;

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
        &child, &children) != 0)
        return (0);

    for (c = 0; c < children; c++) {
        uint64_t is_log = B_FALSE;

        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_LOG,
            &is_log);
        if (is_log)
            nlogs++;
    }
    return (nlogs);
}

static replication_level_t *
get_replication(nvlist_t *nvroot, boolean_t fatal)
{
    nvlist_t **top;
    uint_t t, toplevels;
    nvlist_t **child;
    uint_t c, children;
    nvlist_t *nv;
    char *type;
    replication_level_t lastrep = {0};
    replication_level_t rep;
    replication_level_t *ret;
    boolean_t dontreport;

    ret = malloc(sizeof (replication_level_t));

    nvlist_lookup_nvlist_array(nvroot, ZPOOL_CONFIG_CHILDREN,
        &top, &toplevels);

    for (t = 0; t < toplevels; t++) {
        uint64_t is_log = B_FALSE;

        nv = top[t];

        (void) nvlist_lookup_uint64(nv, ZPOOL_CONFIG_IS_LOG, &is_log);
        if (is_log)
            continue;

        nvlist_lookup_string(nv, ZPOOL_CONFIG_TYPE,
            &type);
        if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
            &child, &children) != 0) {
            /*
             * This is a 'file' or 'disk' vdev.
             */
            rep.zprl_type = type;
            rep.zprl_children = 1;
            rep.zprl_parity = 0;
        } else {
            uint64_t vdev_size;

            /*
             * This is a mirror or RAID-Z vdev.  Go through and make
             * sure the contents are all the same (files vs. disks),
             * keeping track of the number of elements in the
             * process.
             *
             * We also check that the size of each vdev (if it can
             * be determined) is the same.
             */
            rep.zprl_type = type;
            rep.zprl_children = 0;

            if (strcmp(type, VDEV_TYPE_RAIDZ) == 0) {
                nvlist_lookup_uint64(nv,
                    ZPOOL_CONFIG_NPARITY,
                    &rep.zprl_parity);
                assert(rep.zprl_parity != 0);
            } else {
                rep.zprl_parity = 0;
            }

            /*
             * The 'dontreport' variable indicates that we've
             * already reported an error for this spec, so don't
             * bother doing it again.
             */
            type = NULL;
            dontreport = 0;
            vdev_size = -1ULL;
            for (c = 0; c < children; c++) {
                boolean_t is_replacing, is_spare;
                nvlist_t *cnv = child[c];
                char *path;
                struct stat64 statbuf;
                uint64_t size = -1ULL;
                char *childtype;
                int fd, err;

                rep.zprl_children++;

                nvlist_lookup_string(cnv,
                    ZPOOL_CONFIG_TYPE, &childtype);

                /*
                 * If this is a replacing or spare vdev, then
                 * get the real first child of the vdev.
                 */
                is_replacing = strcmp(childtype,
                    VDEV_TYPE_REPLACING) == 0;
                is_spare = strcmp(childtype,
                    VDEV_TYPE_SPARE) == 0;
                if (is_replacing || is_spare) {
                    nvlist_t **rchild;
                    uint_t rchildren;

                    nvlist_lookup_nvlist_array(cnv,
                        ZPOOL_CONFIG_CHILDREN, &rchild,
                        &rchildren);
                    assert((is_replacing && rchildren == 2)
                        || (is_spare && rchildren >= 2));
                    cnv = rchild[0];

                    nvlist_lookup_string(cnv,
                        ZPOOL_CONFIG_TYPE,
                        &childtype);
                    if (strcmp(childtype,
                        VDEV_TYPE_SPARE) == 0) {
                        /* We have a replacing vdev with
                         * a spare child.  Get the first
                         * real child of the spare
                         */
                        
                            nvlist_lookup_nvlist_array(
                            cnv,
                            ZPOOL_CONFIG_CHILDREN,
                            &rchild,
                            &rchildren);
                        assert(rchildren >= 2);
                        cnv = rchild[0];
                    }
                }

                nvlist_lookup_string(cnv,
                    ZPOOL_CONFIG_PATH, &path);

                /*
                 * If we have a raidz/mirror that combines disks
                 * with files, report it as an error.
                 */
                if (!dontreport && type != NULL &&
                    strcmp(type, childtype) != 0) {
                    if (ret != NULL)
                        free(ret);
                    ret = NULL;
                    if (!fatal)
                        return (NULL);
                    dontreport = B_TRUE;
                }

                /*
                 * According to stat(2), the value of 'st_size'
                 * is undefined for block devices and character
                 * devices.  But there is no effective way to
                 * determine the real size in userland.
                 *
                 * Instead, we'll take advantage of an
                 * implementation detail of spec_size().  If the
                 * device is currently open, then we (should)
                 * return a valid size.
                 *
                 * If we still don't get a valid size (indicated
                 * by a size of 0 or MAXOFFSET_T), then ignore
                 * this device altogether.
                 */
                if ((fd = open(path, O_RDONLY)) >= 0) {
                    err = fstat64(fd, &statbuf);
                    (void) close(fd);
                } else {
                    err = stat64(path, &statbuf);
                }

                if (err != 0 ||
                    statbuf.st_size == 0 ||
                    statbuf.st_size == MAXOFFSET_T)
                    continue;

                size = statbuf.st_size;

                /*
                 * Also make sure that devices and
                 * slices have a consistent size.  If
                 * they differ by a significant amount
                 * (~16MB) then report an error.
                 */
                if (!dontreport &&
                    (vdev_size != -1ULL &&
                    (labs(size - vdev_size) >
                    ZPOOL_FUZZ))) {
                    if (ret != NULL)
                        free(ret);
                    ret = NULL;
                    if (!fatal)
                        return (NULL);
                    dontreport = B_TRUE;
                }

                type = childtype;
                vdev_size = size;
            }
        }

        /*
         * At this point, we have the replication of the last toplevel
         * vdev in 'rep'.  Compare it to 'lastrep' to see if its
         * different.
         */
        if (lastrep.zprl_type != NULL) {
            if (strcmp(lastrep.zprl_type, rep.zprl_type) != 0) {
                if (ret != NULL)
                    free(ret);
                ret = NULL;
                if (!fatal)
                    return (NULL);
            } else if (lastrep.zprl_parity != rep.zprl_parity) {
                if (ret)
                    free(ret);
                ret = NULL;
                if (!fatal)
                    return (NULL);
            } else if (lastrep.zprl_children != rep.zprl_children) {
                if (ret)
                    free(ret);
                ret = NULL;
                if (!fatal)
                    return (NULL);
            }
        }
        lastrep = rep;
    }

    if (ret != NULL)
        *ret = rep;

    return (ret);
}

static int
zpool_attach_or_replace(const char *zpool_name, const char *old_dev, const char *new_dev, int force, int replacing)
{
    libzfs_handle_t *g_zfs;
    if ((g_zfs = libzfs_init()) == NULL) {
        return -1;
    }

    int c;
    nvlist_t *nvroot;
    zpool_boot_label_t boot_type;
    uint64_t boot_size;
    int ret;

    zpool_handle_t *zhp;
    if ((zhp = zpool_open(g_zfs, zpool_name)) == NULL) {
        libzfs_fini(g_zfs);
        return -1;
    }

    if (zpool_get_config(zhp, NULL) == NULL) {
        zpool_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }

    if (zpool_is_bootable(zhp))
        boot_type = ZPOOL_COPY_BOOT_LABEL;
    else
        boot_type = ZPOOL_NO_BOOT_LABEL;

    kzpool_dev_info_t *info = NULL;
    kzpool_dev_info_fill(&info, "stripe", 0, 0, (char *)new_dev);
    kzpool_dev_list_t *list = NULL;
    kzpool_dev_list_fill(&list, info);

    boot_size = zpool_get_prop_int(zhp, ZPOOL_PROP_BOOTSIZE, NULL);
    nvroot = make_root_vdev(g_zfs, zhp, force, B_FALSE, replacing, B_FALSE,
        boot_type, boot_size, list);
    kzpool_free_dev_list(list);
    if (nvroot == NULL) {
        zpool_close(zhp);
        libzfs_fini(g_zfs);
        return -1;
    }

    ret = zpool_vdev_attach(zhp, old_dev, new_dev, nvroot, replacing);

    nvlist_free(nvroot);
    zpool_close(zhp);
    libzfs_fini(g_zfs);

    return ret;
}
static int
zpool_scrub_callback(zpool_handle_t *zhp, void *data)
{
    scrub_cbdata_t *cb = data;
    int err;

    if (zpool_get_state(zhp) == POOL_STATE_UNAVAIL) {
        return (1);
    }

    err = zpool_scan(zhp, cb->cb_type, cb->cb_scrub_cmd);

    if (err == 0 && zpool_has_checkpoint(zhp) &&
        cb->cb_type == POOL_SCAN_SCRUB) {
    }

    return (err != 0);
}
static boolean_t
zpool_has_checkpoint(zpool_handle_t *zhp)
{
    nvlist_t *config, *nvroot;

    config = zpool_get_config(zhp, NULL);

    if (config != NULL) {
        pool_checkpoint_stat_t *pcs = NULL;
        uint_t c;

        nvroot = fnvlist_lookup_nvlist(config, ZPOOL_CONFIG_VDEV_TREE);
        (void) nvlist_lookup_uint64_array(nvroot,
            ZPOOL_CONFIG_CHECKPOINT_STATS, (uint64_t **)&pcs, &c);

        if (pcs == NULL || pcs->pcs_state == CS_NONE)
            return (B_FALSE);

        return (B_TRUE);
    }

    return (B_FALSE);
}

static nvlist_t *split_mirror_vdev(zpool_handle_t *zhp, const char *newname, nvlist_t *props,
    splitflags_t flags, kzpool_dev_info_t *devs)
{
    nvlist_t *newroot = NULL, **child;
    uint_t c, children;
    if (devs != NULL) {
        kzpool_dev_list_t *list = NULL;
        kzpool_dev_list_fill(&list, devs);
        if ((newroot = construct_spec(list)) == NULL) {
            free(list->list);
            free(list);
            return (NULL);
        }
        free(list->list);
        free(list);
        nvlist_lookup_nvlist_array(newroot,
            ZPOOL_CONFIG_CHILDREN, &child, &children);
        for (c = 0; c < children; c++) {
            char *path;
            const char *type;
            int min, max;

            nvlist_lookup_string(child[c],
                ZPOOL_CONFIG_PATH, &path);
            if ((type = is_grouping(path, &min, &max)) != NULL) {
                nvlist_free(newroot);
                return (NULL);
            }
        }
    }

    if (zpool_vdev_split(zhp, (char *)newname, &newroot, props, flags) != 0) {
        nvlist_free(newroot);
        return (NULL);
    }

    return (newroot);
}

static int
zpool_callback(zpool_handle_t *zhp, void *data)
{
    zpool_cb_data_t *cb = data;
    char buf[ZPOOL_MAXPROPLEN];
    zprop_source_t sourcetype;
    kzfs_zpool_list_t *zlist = cb->tmp;
    zlist->count++;
    int cur = zlist->count-1;
    zlist->zpool_info_list = realloc(zlist->zpool_info_list, sizeof(kzfs_zpool_info_t *) * zlist->count); /*TODO free*/
    kzfs_zpool_info_t *info = malloc(sizeof(kzfs_zpool_info_t)); /*TODO free*/
    zlist->zpool_info_list[cur] = info;
    const char *zpool_name = zpool_get_name(zhp);
    info->zpool_name = malloc(strlen(zpool_name) + 1); /*TODO free*/
    info->propval_list = NULL;
    snprintf(info->zpool_name, strlen(zpool_name) + 1, "%s", zpool_name);
    kzfs_prop_list_t *props = cb->proplist;
    if (props != NULL) {
        kzfs_propval_list_t *pval = malloc(sizeof(kzfs_propval_list_t)); /*TODO free*/
        info->propval_list = pval;
        pval->props = malloc(sizeof(char *) * props->count);
        pval->values = malloc(sizeof(char *) * props->count);
        pval->count = 0;
        for (int i = 0; i < props->count; i++) {
            if (zpool_name_to_prop(props->props[i]) != ZPOOL_PROP_GUID &&
                zpool_name_to_prop(props->props[i]) != ZPOOL_PROP_NAME &&
                zpool_name_to_prop(props->props[i]) != ZPROP_INVAL) {
                    zpool_get_prop(zhp, zpool_name_to_prop(props->props[i]), buf, sizeof (buf), &sourcetype, B_FALSE);
                    pval->props[i] = malloc(strlen(props->props[i]) + 1); /*TODO free*/
                    snprintf(pval->props[i], strlen(props->props[i]) + 1, "%s", props->props[i]);
                    pval->values[i] = malloc(strlen(buf) + 1); /*TODO free*/
                    snprintf(pval->values[i], strlen(buf) + 1, "%s", buf);
                    pval->count++;
            }
        }
    }
    info->guid = zpool_get_prop_int(zhp, ZPOOL_PROP_GUID, NULL);
    zpool_close(zhp);
    return 0;
}

static void
zpool_devs_list_grouping(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t *nv,
        char *name, int islog, kzpool_dev_info_t **info)
{
    nvlist_t **child;
    char *vname;
    uint_t c, children;
    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
        &child, &children) != 0)
        return;
    for (c = 0; c < children; c++) {
        uint64_t ishole = B_FALSE;
        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_HOLE,
            &ishole);
        if (ishole)
            continue;
        vname = zpool_vdev_name(g_zfs, zhp, child[c], B_TRUE);
        kzpool_dev_info_fill(info, name, 0, islog, vname);
        free(vname);
    }
}

static void
zpool_devs_list(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t *nv, kzpool_dev_list_t **list)
{
    nvlist_t **child;
    char *vname;
    uint_t c, children;
    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
        &child, &children) != 0)
        return;
    int stripe = -1;
    int tlog = -1;
    int j = 0;
    kzpool_dev_info_t *log_info = NULL;
    kzpool_dev_info_t *st_info = NULL;
    for (c = 0; c < children; c++) {
        uint64_t islog = B_FALSE, ishole = B_FALSE;
        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_HOLE,
            &ishole);
        if (ishole)
            continue;
        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_LOG,
            &islog);
        vname = zpool_vdev_name(g_zfs, zhp, child[c], B_TRUE);
        // zpool_devs_list(zhp, child[c], vname, depth + 2, NULL);
        if (strncmp(vname, VDEV_TYPE_MIRROR, strlen(VDEV_TYPE_MIRROR)) == 0 ||
            strncmp(vname, VDEV_TYPE_RAIDZ, strlen(VDEV_TYPE_RAIDZ)) == 0 ||
            strncmp(vname, VDEV_TYPE_SPARE, strlen(VDEV_TYPE_SPARE)) == 0 ||
            strncmp(vname, VDEV_TYPE_L2CACHE, strlen(VDEV_TYPE_L2CACHE)) == 0) {
            kzpool_dev_info_t *info = NULL;
            zpool_devs_list_grouping(g_zfs, zhp, child[c], vname, islog, &info);
            if (info != NULL)
                kzpool_dev_list_fill(list, info);
        } else {
            if (!islog) {
                kzpool_dev_info_fill(&st_info, "stripe", 0, islog, vname);
            } else {
                kzpool_dev_info_fill(&log_info, "stripe", 0, islog, vname);
            }
        }
        free(vname);
    }
    kzpool_dev_list_fill(list, st_info);
    kzpool_dev_list_fill(list, log_info);
}

static int
zpool_status_callback(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, void *data)
{
    kzpool_status_t *st = data;
    nvlist_t *config, *nvroot;
    char *msgid;
    int reason;
    const char *health;
    uint_t c;
    vdev_stat_t *vs;

    config = zpool_get_config(zhp, NULL);
    reason = zpool_get_status(zhp, &msgid);

    nvroot = fnvlist_lookup_nvlist(config, ZPOOL_CONFIG_VDEV_TREE);
    nvlist_lookup_uint64_array(nvroot, ZPOOL_CONFIG_VDEV_STATS,
        (uint64_t **)&vs, &c);
    health = zpool_state_to_name(vs->vs_state, vs->vs_aux);

    snprintf(st->name, MAXPATHLEN, "%s", zpool_get_name(zhp));
    snprintf(st->state, KZFS_ZPOOL_STATUS_STATE_LEN, "%s", health);
    st->guid = zpool_get_prop_int(zhp, ZPOOL_PROP_GUID, NULL);

    char *status = st->status = NULL;
    char *action = st->action = NULL;
    switch (reason) {
    case ZPOOL_STATUS_MISSING_DEV_R:
        status = "One or more devices could not "
            "be opened.  Sufficient replicas exist for the pool to "
            "continue functioning in a degraded state.";
        action = "Attach the missing device and "
            "online it using 'zpool online'.";
        break;

    case ZPOOL_STATUS_MISSING_DEV_NR:
        status = "One or more devices could not "
            "be opened.  There are insufficient replicas for the "
            "pool to continue functioning.";
        action = "Attach the missing device and "
            "online it using 'zpool online'.";
        break;

    case ZPOOL_STATUS_CORRUPT_LABEL_R:
        status = "One or more devices could not "
            "be used because the label is missing or invalid.  "
            "Sufficient replicas exist for the pool to continue "
            "functioning in a degraded state.";
        action = "Replace the device using "
            "'zpool replace'.";
        break;

    case ZPOOL_STATUS_CORRUPT_LABEL_NR:
        status = "One or more devices could not "
            "be used because the label is missing or invalid.  "
            "There are insufficient replicas for the pool to "
            "continue functioning.";
        break;

    case ZPOOL_STATUS_FAILING_DEV:
        status = "One or more devices has "
            "experienced an unrecoverable error.  An attempt was "
            "made to correct the error.  Applications are "
            "unaffected.";
        action = "Determine if the device needs "
            "to be replaced, and clear the errors using "
            "'zpool clear' or replace the device with 'zpool "
            "replace'.";
        break;

    case ZPOOL_STATUS_OFFLINE_DEV:
        status = "One or more devices has "
            "been taken offline by the administrator. Sufficient "
            "replicas exist for the pool to continue functioning in "
            "a degraded state.";
        action = "Online the device using "
            "'zpool online' or replace the device with 'zpool "
            "replace'.";
        break;

    case ZPOOL_STATUS_REMOVED_DEV:
        status = "One or more devices has "
            "been removed by the administrator. Sufficient "
            "replicas exist for the pool to continue functioning in "
            "a degraded state.";
        action = "Online the device using "
            "'zpool online' or replace the device with 'zpool "
            "replace'.";
        break;

    case ZPOOL_STATUS_RESILVERING:
        status = "One or more devices is "
            "currently being resilvered.  The pool will continue "
            "to function, possibly in a degraded state.";
        action = "Wait for the resilver to "
            "complete.";
        break;

    case ZPOOL_STATUS_CORRUPT_DATA:
        status = "One or more devices has "
            "experienced an error resulting in data corruption.  "
            "Applications may be affected.";
        action = "Restore the file in question "
            "if possible.  Otherwise restore the entire pool from "
            "backup.";
        break;

    case ZPOOL_STATUS_CORRUPT_POOL:
        status = "The pool metadata is corrupted "
            "and the pool cannot be opened.";
        break;

    case ZPOOL_STATUS_VERSION_OLDER:
        status = "The pool is formatted using a "
            "legacy on-disk format.  The pool can still be used, "
            "but some features are unavailable.";
        action = "Upgrade the pool using 'zpool "
            "upgrade'.  Once this is done, the pool will no longer "
            "be accessible on software that does not support feature"
            " flags.";
        break;

    case ZPOOL_STATUS_VERSION_NEWER:
        status = "The pool has been upgraded to a "
            "newer, incompatible on-disk version. The pool cannot "
            "be accessed on this system.";
        action = "Access the pool from a system "
            "running more recent software, or restore the pool from "
            "backup.";
        break;

    case ZPOOL_STATUS_FEAT_DISABLED:
        status = "Some supported features are not "
            "enabled on the pool. The pool can still be used, but "
            "some features are unavailable.";
        action = "Enable all features using "
            "'zpool upgrade'. Once this is done, the pool may no "
            "longer be accessible by software that does not support "
            "the features. See zpool-features(7) for details.";
        break;

    case ZPOOL_STATUS_UNSUP_FEAT_READ:
        status = "The pool cannot be accessed on "
            "this system because it uses feature(s) "
            "that is not supported on this system.";
        action = "Access the pool from a system "
            "that supports the required feature(s), or restore the "
            "pool from backup.";
        break;

    case ZPOOL_STATUS_UNSUP_FEAT_WRITE:
        status = "The pool can only be accessed "
            "in read-only mode on this system. It cannot be "
            "accessed in read-write mode because it uses "
            "feature(s) that is not supported on this system.";
        action = "The pool cannot be accessed in "
            "read-write mode. Import the pool with"
            "readonly property, access the pool from a system that "
            "supports the required feature(s), or restore the "
            "pool from backup.";
        break;

    case ZPOOL_STATUS_FAULTED_DEV_R:
        status = "One or more devices are "
            "faulted in response to persistent errors. Sufficient "
            "replicas exist for the pool to continue functioning "
            "in a degraded state.";
        action = "Replace the faulted device, "
            "or use 'zpool clear' to mark the device repaired.";
        break;

    case ZPOOL_STATUS_FAULTED_DEV_NR:
        status = "One or more devices are "
            "faulted in response to persistent errors.  There are "
            "insufficient replicas for the pool to continue "
            "functioning.";
        action = "Destroy and re-create the pool "
            "from a backup source.  Manually marking the device"
            " repaired using 'zpool clear' may allow some data "
            "to be recovered.";
        break;

    case ZPOOL_STATUS_IO_FAILURE_WAIT:
    case ZPOOL_STATUS_IO_FAILURE_CONTINUE:
        status = "One or more devices are "
            "faulted in response to IO failures.";
        action = "Make sure the affected devices "
            "are connected, then run 'zpool clear'.";
        break;

    case ZPOOL_STATUS_BAD_LOG:
        status = "An intent log record "
            "could not be read."
            " Waiting for adminstrator intervention to fix the "
            "faulted pool.";
        action = "Either restore the affected "
            "device(s) and run 'zpool online', "
            "or ignore the intent log records by running "
            "'zpool clear'.";
        break;

    case ZPOOL_STATUS_NON_NATIVE_ASHIFT:
        status = "One or more devices are "
            "configured to use a non-native block size. "
            "Expect reduced performance.";
        action = "Replace affected devices with "
            "devices that support the configured block size, or "
            "migrate data to a properly configured pool.";
        break;
    default:
        break;
    }
    if (status != NULL) {
        st->status = malloc(strlen(status) + 1);
        if (st->status == NULL) {
            return -1;
        }
        snprintf(st->status, strlen(status) + 1, "%s", status);
    }
    if (action != NULL) {
        st->action = malloc(strlen(action) + 1);
        if (st->action == NULL) {
            free(st->status);
            return -1;
        }
        snprintf(st->action, strlen(action) + 1, "%s", action);
    }

    if (config != NULL) {
        int namewidth;
        uint64_t nerr;
        nvlist_t **spares, **l2cache;
        uint_t nspares, nl2cache;
        pool_checkpoint_stat_t *pcs = NULL;
        pool_scan_stat_t *ps = NULL;
        pool_removal_stat_t *prs = NULL;

        (void) nvlist_lookup_uint64_array(nvroot,
            ZPOOL_CONFIG_CHECKPOINT_STATS, (uint64_t **)&pcs, &c);
        (void) nvlist_lookup_uint64_array(nvroot,
            ZPOOL_CONFIG_SCAN_STATS, (uint64_t **)&ps, &c);
        (void) nvlist_lookup_uint64_array(nvroot,
            ZPOOL_CONFIG_REMOVAL_STATS, (uint64_t **)&prs, &c);
        st->scan = NULL;
        st->scan_warn = NULL;
        st->remove = NULL;
        st->checkpoint = NULL;
        st->config = NULL;
        st->logs = NULL;
        st->cache = NULL;
        st->spares = NULL;
        zpool_get_scan_status(ps, &st->scan);
        zpool_get_checkpoint_scan_warning(ps, pcs, &st->scan_warn);
        zpool_get_removal_status(g_zfs, zhp, prs, &st->remove);
        zpool_get_checkpoint_status(pcs, &st->checkpoint);
        zpool_get_status_config(g_zfs, zhp, zpool_get_name(zhp), nvroot, 0, B_FALSE, &st->config);

        if (num_logs(nvroot) > 0)
            zpool_get_logs_status(g_zfs, zhp, nvroot, &st->logs);
        if (nvlist_lookup_nvlist_array(nvroot, ZPOOL_CONFIG_L2CACHE,
            &l2cache, &nl2cache) == 0)
            zpool_get_l2cache(g_zfs, zhp, l2cache, nl2cache, &st->cache);

        if (nvlist_lookup_nvlist_array(nvroot, ZPOOL_CONFIG_SPARES,
            &spares, &nspares) == 0)
            zpool_get_spares(g_zfs, zhp, spares, nspares, &st->spares);

        if (nvlist_lookup_uint64(config, ZPOOL_CONFIG_ERRCOUNT,
            &nerr) == 0) {
            nvlist_t *nverrlist = NULL;
            if (nerr > 0 && nerr < 100 && zpool_get_errlog(zhp, &nverrlist) == 0) {
                nvpair_t *elem;

                elem = NULL;
                nerr = 0;
                while ((elem = nvlist_next_nvpair(nverrlist,
                    elem)) != NULL) {
                    nerr++;
                }
            }
            nvlist_free(nverrlist);

            if (nerr == 0) {
                st->errors = malloc(strlen("No known data errors") + 1);
                if (st->errors == NULL)
                    return -1;
                snprintf(st->errors, strlen("No known data errors") + 1, "%s", "No known data errors");
            } else if (1) {
                st->errors = malloc(strlen("data errors") + 1);
                if (st->errors == NULL)
                    return -1;
                snprintf(st->errors, strlen("data errors") + 1, "%s", "data errors");
            } else {
                st->errors = zpool_get_error_log(zhp);
            }
        }

    } else {
        // add_assoc_string(item, "config", "The configuration cannot be determined.");
    }

    return (0);
}


static void kzpool_free_status_config_list(kzpool_status_config_t *config_list)
{
    if (config_list == NULL)
        return;
    if (config_list->config_path != NULL)
        free(config_list->config_path);
    if (config_list->msg != NULL)
        free(config_list->msg);
    for (int i = 0; i < config_list->count; i++) {
        kzpool_free_status_config_list(config_list->config_list[i]);
    }
    free(config_list->config_list);
    free(config_list);
}

void kzpool_free_status(kzpool_status_t *status)
{
    if (status == NULL)
        return;

    if (status->status != NULL)
        free(status->status);
    if (status->action != NULL)
        free(status->action);
    if (status->scan != NULL)
        free(status->scan);
    if (status->scan_warn != NULL)
        free(status->scan_warn);
    if (status->remove != NULL)
        free(status->remove);
    if (status->checkpoint != NULL)
        free(status->checkpoint);
    if (status->errors != NULL)
        free(status->errors);
    kzpool_free_status_config_list(status->config);
    kzpool_free_status_config_list(status->logs);
    kzpool_free_status_config_list(status->cache);
    kzpool_free_status_config_list(status->spares);
    free(status);
}

static void
zpool_get_scan_status(pool_scan_stat_t *ps, char **scan_status)
{
    time_t start, end, pause;
    uint64_t elapsed, mins_left, hours_left;
    uint64_t pass_exam, examined, total;
    uint_t rate;
    double fraction_done;
    char processed_buf[7], examined_buf[7], total_buf[7], rate_buf[7];

    /* If there's never been a scan, there's not much to say. */
    if (ps == NULL || ps->pss_func == POOL_SCAN_NONE ||
        ps->pss_func >= POOL_SCAN_FUNCS) {

        *scan_status = malloc(strlen("none requested") + 1);
        snprintf(*scan_status, strlen("none requested") + 1, "%s", "none requested");
        return;
    }

    start = ps->pss_start_time;
    end = ps->pss_end_time;
    pause = ps->pss_pass_scrub_pause;
    zfs_nicenum(ps->pss_processed, processed_buf, sizeof (processed_buf));

    if(ps->pss_func == POOL_SCAN_SCRUB ||
        ps->pss_func == POOL_SCAN_RESILVER)
        return;
    /*
     * Scan is finished or canceled.
     */
    if (ps->pss_state == DSS_FINISHED) {
        uint64_t minutes_taken = (end - start) / 60;
        char *fmt = NULL;

        if (ps->pss_func == POOL_SCAN_SCRUB) {
            fmt = gettext("scrub repaired %s in %lluh%um with "
                "%llu errors on %s");
        } else if (ps->pss_func == POOL_SCAN_RESILVER) {
            fmt = gettext("resilvered %s in %lluh%um with "
                "%llu errors on %s");
        }
        /* LINTED */
        char tmp_fmt[strlen(fmt) + 50];
        snprintf(tmp_fmt, sizeof(tmp_fmt),fmt, processed_buf,
            (u_longlong_t)(minutes_taken / 60),
            (uint_t)(minutes_taken % 60),
            (u_longlong_t)ps->pss_errors,
            ctime((time_t *)&end));

        *scan_status = malloc(strlen(tmp_fmt) + 1);
        snprintf(*scan_status, strlen(tmp_fmt) + 1, "%s", tmp_fmt);
        // add_assoc_string(item, "scan", tmp_fmt);
        return;
    } else if (ps->pss_state == DSS_CANCELED) {
        if (ps->pss_func == POOL_SCAN_SCRUB) {
            char tmp_fmt[strlen("scrub canceled on %s") + 15];
            snprintf(tmp_fmt, sizeof(tmp_fmt), "scrub canceled on %s",
                ctime(&end));
            *scan_status = malloc(strlen(tmp_fmt) + 1);
            snprintf(*scan_status, strlen(tmp_fmt) + 1, "%s", tmp_fmt);
            // add_assoc_string(item, "scan", tmp_fmt);
        } else if (ps->pss_func == POOL_SCAN_RESILVER) {
            char tmp_fmt[strlen("resilver canceled on %s") + 15];
            snprintf(tmp_fmt, sizeof(tmp_fmt), "resilver canceled on %s",
                ctime(&end));
            *scan_status = malloc(strlen(tmp_fmt) + 1);
            snprintf(*scan_status, strlen(tmp_fmt) + 1, "%s", tmp_fmt);
            // add_assoc_string(item, "scan", tmp_fmt);
        }
        return;
    }

    if (ps->pss_state == DSS_SCANNING)
        return;
    // assert(ps->pss_state == DSS_SCANNING);

    char tmp_fmt[512];
    if (ps->pss_func == POOL_SCAN_SCRUB) {
        if (pause == 0) {
            snprintf(tmp_fmt, sizeof(tmp_fmt), "%s scrub in progress since %s", tmp_fmt,
                ctime(&start));
        } else {
            char buf[32];
            struct tm *p = localtime(&pause);
            (void) strftime(buf, sizeof (buf), "%a %b %e %T %Y", p);
            snprintf(tmp_fmt, sizeof(tmp_fmt), "%s scrub paused since %s, scrub started on %s", tmp_fmt, buf, ctime(&start));
        }
    } else if (ps->pss_func == POOL_SCAN_RESILVER) {
        snprintf(tmp_fmt, sizeof(tmp_fmt), "%s resilver in progress since %s", tmp_fmt,
            ctime(&start));
    }

    examined = ps->pss_examined ? ps->pss_examined : 1;
    total = ps->pss_to_examine;
    fraction_done = (double)examined / total;

    /* elapsed time for this pass */
    elapsed = time(NULL) - ps->pss_pass_start;
    elapsed -= ps->pss_pass_scrub_spent_paused;
    elapsed = elapsed ? elapsed : 1;
    pass_exam = ps->pss_pass_exam ? ps->pss_pass_exam : 1;
    rate = pass_exam / elapsed;
    rate = rate ? rate : 1;
    mins_left = ((total - examined) / rate) / 60;
    hours_left = mins_left / 60;

    zfs_nicenum(examined, examined_buf, sizeof (examined_buf));
    zfs_nicenum(total, total_buf, sizeof (total_buf));

    /*
     * do not print estimated time if hours_left is more than 30 days
     * or we have a paused scrub
     */
    if (pause == 0) {
        zfs_nicenum(rate, rate_buf, sizeof (rate_buf));
        snprintf(tmp_fmt, sizeof(tmp_fmt), "%s, %s scanned out of %s at %s", tmp_fmt,
            examined_buf, total_buf, rate_buf);
        if (hours_left < (30 * 24)) {
            snprintf(tmp_fmt, sizeof(tmp_fmt), "%s, %lluh%um to go", tmp_fmt,
                (u_longlong_t)hours_left, (uint_t)(mins_left % 60));
        } else {
            snprintf(tmp_fmt, sizeof(tmp_fmt), "%s, (scan is slow, no estimated time)", tmp_fmt);
        }
    } else {
        snprintf(tmp_fmt, sizeof(tmp_fmt), "%s, %s scanned out of %s", tmp_fmt,
            examined_buf, total_buf);
    }

    if (ps->pss_func == POOL_SCAN_RESILVER) {
        snprintf(tmp_fmt, sizeof(tmp_fmt), "%s, %s resilvered, %.2f%% done", tmp_fmt,
            processed_buf, 100 * fraction_done);
    } else if (ps->pss_func == POOL_SCAN_SCRUB) {
        snprintf(tmp_fmt, sizeof(tmp_fmt), "%s, %s repaired, %.2f%% done", tmp_fmt,
            processed_buf, 100 * fraction_done);
    }
    *scan_status = malloc(strlen(tmp_fmt) + 1);
    snprintf(*scan_status, strlen(tmp_fmt) + 1, "%s", tmp_fmt);
    // add_assoc_string(item, "scan", tmp_fmt);
}

static void
zpool_get_checkpoint_scan_warning(pool_scan_stat_t *ps, pool_checkpoint_stat_t *pcs, char **item)
{
    if (ps == NULL || pcs == NULL)
        return;

    if (pcs->pcs_state == CS_NONE ||
        pcs->pcs_state == CS_CHECKPOINT_DISCARDING)
        return;

    assert(pcs->pcs_state == CS_CHECKPOINT_EXISTS);

    if (ps->pss_state == DSS_NONE)
        return;

    if ((ps->pss_state == DSS_FINISHED || ps->pss_state == DSS_CANCELED) &&
        ps->pss_end_time < pcs->pcs_start_time)
        return;

    if (ps->pss_state == DSS_FINISHED || ps->pss_state == DSS_CANCELED) {
        *item = malloc(strlen("skipped blocks "
            "that are only referenced by the checkpoint.") + 1);
        snprintf(*item, strlen("skipped blocks "
            "that are only referenced by the checkpoint.") + 1, "%s", "skipped blocks "
            "that are only referenced by the checkpoint.");
        // add_assoc_string(item, "scan_warn", "skipped blocks "
        //     "that are only referenced by the checkpoint.");
    } else {
        if (ps->pss_state == DSS_SCANNING)
            return;
        *item = malloc(strlen("skipping blocks "
            "that are only referenced by the checkpoint.") + 1);
        snprintf(*item, strlen("skipping blocks "
            "that are only referenced by the checkpoint.") + 1, "%s", "skipping blocks "
            "that are only referenced by the checkpoint.");

        // add_assoc_string(item, "scan_warn", "skipping blocks "
        //     "that are only referenced by the checkpoint.");
    }
}
static void
zpool_get_removal_status(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, pool_removal_stat_t *prs, char **rm_st)
{
    char copied_buf[7], examined_buf[7], total_buf[7], rate_buf[7];
    time_t start, end;
    nvlist_t *config, *nvroot;
    nvlist_t **child;
    uint_t children;
    char *vdev_name;

    if (prs == NULL || prs->prs_state == DSS_NONE)
        return;

    config = zpool_get_config(zhp, NULL);
    nvroot = fnvlist_lookup_nvlist(config,
        ZPOOL_CONFIG_VDEV_TREE);
    nvlist_lookup_nvlist_array(nvroot, ZPOOL_CONFIG_CHILDREN,
        &child, &children);
    assert(prs->prs_removing_vdev < children);
    vdev_name = zpool_vdev_name(g_zfs, zhp,
        child[prs->prs_removing_vdev], B_TRUE);


    start = prs->prs_start_time;
    end = prs->prs_end_time;
    zfs_nicenum(prs->prs_copied, copied_buf, sizeof (copied_buf));

    /*
     * Removal is finished or canceled.
     */
    char tmp[512];
    if (prs->prs_state == DSS_FINISHED) {
        uint64_t minutes_taken = (end - start) / 60;
        snprintf(tmp, sizeof(tmp), "Removal of vdev %llu copied %s "
            "in %lluh%um, completed on %s", (longlong_t)prs->prs_removing_vdev,
            copied_buf,
            (u_longlong_t)(minutes_taken / 60),
            (uint_t)(minutes_taken % 60),
            ctime((time_t *)&end));
    } else if (prs->prs_state == DSS_CANCELED) {
        snprintf(tmp, sizeof(tmp), "Removal of %s canceled on %s",
            vdev_name, ctime(&end));
    } else {
        uint64_t copied, total, elapsed, mins_left, hours_left;
        double fraction_done;
        uint_t rate;

        assert(prs->prs_state == DSS_SCANNING);
        snprintf(tmp, sizeof(tmp), "Evacuation of %s in progress since %s",
            vdev_name, ctime(&start));

        copied = prs->prs_copied > 0 ? prs->prs_copied : 1;
        total = prs->prs_to_copy;
        fraction_done = (double)copied / total;

        /* elapsed time for this pass */
        elapsed = time(NULL) - prs->prs_start_time;
        elapsed = elapsed > 0 ? elapsed : 1;
        rate = copied / elapsed;
        rate = rate > 0 ? rate : 1;
        mins_left = ((total - copied) / rate) / 60;
        hours_left = mins_left / 60;

        zfs_nicenum(copied, examined_buf, sizeof (examined_buf));
        zfs_nicenum(total, total_buf, sizeof (total_buf));
        zfs_nicenum(rate, rate_buf, sizeof (rate_buf));

        /*
         * do not print estimated time if hours_left is more than
         * 30 days
         */
        snprintf(tmp, sizeof(tmp), "%s, %s copied out of %s at %s/s, "
            "%.2f%% done", tmp,
            examined_buf, total_buf, rate_buf, 100 * fraction_done);
        if (hours_left < (30 * 24)) {
            snprintf(tmp, sizeof(tmp), "%s, %lluh%um to go", tmp,
                (u_longlong_t)hours_left, (uint_t)(mins_left % 60));
        } else {
            snprintf(tmp, sizeof(tmp), "%s, (copy is slow, no estimated time)", tmp);
        }
    }

    if (prs->prs_mapping_memory > 0) {
        char mem_buf[7];
        zfs_nicenum(prs->prs_mapping_memory, mem_buf, sizeof (mem_buf));
        snprintf(tmp, sizeof(tmp), "%s, %s memory used for "
            "removed device mappings", tmp,
            mem_buf);
    }
    *rm_st = malloc(strlen(tmp) + 1);
    snprintf(*rm_st, strlen(tmp) + 1, "%s", tmp);
}

static void
zpool_get_checkpoint_status(pool_checkpoint_stat_t *pcs, char **checkpoint)
{
    time_t start;
    char space_buf[7];

    if (pcs == NULL || pcs->pcs_state == CS_NONE)
        return;


    start = pcs->pcs_start_time;
    zfs_nicenum(pcs->pcs_space, space_buf, sizeof (space_buf));
    char tmp[512];
    if (pcs->pcs_state == CS_CHECKPOINT_EXISTS) {
        char *date = ctime(&start);
        snprintf(tmp, sizeof(tmp), "created %.*s, consumes %s",
           (int) strlen(date) - 1, date, space_buf);
        *checkpoint = malloc(strlen(tmp) + 1);
        snprintf(*checkpoint, strlen(tmp) + 1, "%s", tmp);
        return;
    }

    if (pcs->pcs_state == CS_CHECKPOINT_DISCARDING)
        return;
    snprintf(tmp, sizeof(tmp), "discarding, %s remaining.",
        space_buf);
    *checkpoint = malloc(strlen(tmp) + 1);
    snprintf(*checkpoint, strlen(tmp) + 1, "%s", tmp);
}

static void
zpool_get_status_config(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, const char *name, nvlist_t *nv,
    int depth, boolean_t isspare, kzpool_status_config_t **config)
{
    nvlist_t **child;
    uint_t c, vsc, children;
    pool_scan_stat_t *ps = NULL;
    vdev_stat_t *vs;
    char rbuf[6], wbuf[6], cbuf[6];
    char *vname;
    uint64_t notpresent;
    uint64_t ashift;
    spare_cbdata_t cb;
    const char *state;
    char *type;
    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
        &child, &children) != 0)
        children = 0;

    if (*config == NULL) {
        *config = malloc(sizeof(kzpool_status_config_t));
        if (*config == NULL)
            return;
    }
    if (depth != 0) {

        nvlist_lookup_uint64_array(nv, ZPOOL_CONFIG_VDEV_STATS,
            (uint64_t **)&vs, &vsc);

        nvlist_lookup_string(nv, ZPOOL_CONFIG_TYPE, &type);

        if (strcmp(type, VDEV_TYPE_INDIRECT) == 0) {
            free(*config);
            return;
        }

        state = zpool_state_to_name(vs->vs_state, vs->vs_aux);
        if (isspare) {
            /*
             * For hot spares, we use the terms 'INUSE' and 'AVAILABLE' for
             * online drives.
             */
            if (vs->vs_aux == VDEV_AUX_SPARED)
                state = "INUSE";
            else if (vs->vs_state == VDEV_STATE_HEALTHY)
                state = "AVAIL";
        }
        snprintf((*config)->name, MAXPATHLEN, "%s", name);
        snprintf((*config)->state, KZFS_ZPOOL_STATUS_STATE_LEN, "%s", state);

        if (!isspare) {
            zfs_nicenum(vs->vs_read_errors, rbuf, sizeof (rbuf));
            zfs_nicenum(vs->vs_write_errors, wbuf, sizeof (wbuf));
            zfs_nicenum(vs->vs_checksum_errors, cbuf, sizeof (cbuf));
            snprintf((*config)->rbuf, KZFS_ZPOOL_STATUS_RBUF_LEN, "%s", rbuf);
            snprintf((*config)->wbuf, KZFS_ZPOOL_STATUS_WBUF_LEN, "%s", wbuf);
            snprintf((*config)->cbuf, KZFS_ZPOOL_STATUS_CBUF_LEN, "%s", cbuf);
        }
        char *msg = (*config)->msg = (*config)->config_path = (*config)->act = NULL;

        if (nvlist_lookup_uint64(nv, ZPOOL_CONFIG_NOT_PRESENT,
            &notpresent) == 0 ||
            vs->vs_state <= VDEV_STATE_CANT_OPEN) {
            char *path;
            if (nvlist_lookup_string(nv, ZPOOL_CONFIG_PATH, &path) == 0) {
                (*config)->config_path = malloc(strlen(path) + 6);
                if ((*config)->config_path == NULL) {
                    free((*config));
                    (*config) = NULL;
                    return;
                }
                snprintf((*config)->config_path, strlen(path) + 6, "was %s", path);
            }
        } else if (vs->vs_aux != 0) {
            switch (vs->vs_aux) {
            case VDEV_AUX_OPEN_FAILED:
                msg = "cannot open";
                break;

            case VDEV_AUX_BAD_GUID_SUM:
                msg = "missing device";
                break;

            case VDEV_AUX_NO_REPLICAS:
                msg = "insufficient replicas";
                break;

            case VDEV_AUX_VERSION_NEWER:
                msg = "newer version";
                break;

            case VDEV_AUX_UNSUP_FEAT:
                msg = "unsupported feature(s)";
                break;

            case VDEV_AUX_ASHIFT_TOO_BIG:
                msg = "unsupported minimum blocksize";
                break;

            case VDEV_AUX_SPARED:
                nvlist_lookup_uint64(nv, ZPOOL_CONFIG_GUID,
                    &cb.cb_guid);
                if (zpool_iter(g_zfs, find_spare, &cb) == 1) {
                    if (strcmp(zpool_get_name(cb.cb_zhp),
                        zpool_get_name(zhp)) == 0)
                        msg = "currently in use";
                    else
                        msg = "currently in use";
                    zpool_close(cb.cb_zhp);
                } else {
                        msg = "currently in use";
                }
                break;

            case VDEV_AUX_ERR_EXCEEDED:
                msg = "too many errors";
                break;

            case VDEV_AUX_IO_FAILURE:
                msg = "experienced I/O failures";
                break;

            case VDEV_AUX_BAD_LOG:
                msg = "bad intent log";
                break;

            case VDEV_AUX_EXTERNAL:
                msg = "external device fault";
                break;

            case VDEV_AUX_SPLIT_POOL:
                msg = "split into new pool";
                break;

            case VDEV_AUX_CHILDREN_OFFLINE:
                msg = "all children offline";
                break;

            default:
                msg = "corrupted data";
                break;
            }
        } else if (children == 0 && !isspare &&
            VDEV_STAT_VALID(vs_physical_ashift, vsc) &&
            vs->vs_configured_ashift < vs->vs_physical_ashift) {
            (*config)->block_size.configured = 1 << vs->vs_configured_ashift;
            (*config)->block_size.native = 1 << vs->vs_physical_ashift;
        }
        if (msg != NULL) {
            (*config)->msg = malloc(strlen(msg) + 1);
            if ((*config)->msg == NULL) {
                free((*config));
                (*config) = NULL;
                return;
            }
            snprintf((*config)->msg, strlen(msg) + 1, "%s", msg);
        }
        (void) nvlist_lookup_uint64_array(nv, ZPOOL_CONFIG_SCAN_STATS,
            (uint64_t **)&ps, &c);

        if (ps && ps->pss_state == DSS_SCANNING &&
            vs->vs_scan_processed != 0 && children == 0) {
            char *act = (ps->pss_func == POOL_SCAN_RESILVER) ? "resilvering" : "repairing";
            (*config)->act = malloc(strlen(act) + 1);
            if ((*config)->act == NULL) {
                if ((*config)->msg != NULL)
                    free((*config)->msg);
                if ((*config)->config_path != NULL)
                    free((*config)->config_path);
                free((*config));
                (*config) = NULL;
                return;
            }
            snprintf((*config)->act, strlen(act) + 1, "%s", act);
        }
    }
    (*config)->count = 0;
    (*config)->config_list = NULL;
    for (c = 0; c < children; c++) {
        uint64_t islog = B_FALSE, ishole = B_FALSE;

        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_LOG,
            &islog);
        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_HOLE,
            &ishole);
        if (islog || ishole)
            continue;
        (*config)->count++;
        (*config)->config_list = realloc((*config)->config_list, sizeof(kzpool_status_config_t *) * (*config)->count); /*TODO free*/
        kzpool_status_config_t *st_conf = NULL;

        vname = zpool_vdev_name(g_zfs, zhp, child[c], B_TRUE);
        zpool_get_status_config(g_zfs, zhp, vname, child[c], depth + 2, isspare, &st_conf);
        (*config)->config_list[(*config)->count - 1] = st_conf;
        // add_next_index_zval(&subsub, &subsubsub);
        free(vname);
    }
    // if (zend_hash_num_elements(Z_ARRVAL_P(&subsub)) > 0)
    //     add_assoc_zval(item, "config", &subsub);
}

static int
find_spare(zpool_handle_t *zhp, void *data)
{
    spare_cbdata_t *cbp = data;
    nvlist_t *config, *nvroot;

    config = zpool_get_config(zhp, NULL);
    nvlist_lookup_nvlist(config, ZPOOL_CONFIG_VDEV_TREE,
        &nvroot);

    if (find_vdev(nvroot, cbp->cb_guid)) {
        cbp->cb_zhp = zhp;
        return (1);
    }

    zpool_close(zhp);
    return (0);
}
static boolean_t
find_vdev(nvlist_t *nv, uint64_t search)
{
    uint64_t guid;
    nvlist_t **child;
    uint_t c, children;

    if (nvlist_lookup_uint64(nv, ZPOOL_CONFIG_GUID, &guid) == 0 &&
        search == guid)
        return (B_TRUE);

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN,
        &child, &children) == 0) {
        for (c = 0; c < children; c++)
            if (find_vdev(child[c], search))
                return (B_TRUE);
    }

    return (B_FALSE);
}

static void
zpool_get_logs_status(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t *nv, kzpool_status_config_t **logs)
{
    uint_t c, children;
    nvlist_t **child;

    if (nvlist_lookup_nvlist_array(nv, ZPOOL_CONFIG_CHILDREN, &child,
        &children) != 0)
        return;

    if (*logs == NULL) {
        *logs = malloc(sizeof(kzpool_status_config_t));
        if (*logs == NULL)
            return;
    }
    (*logs)->count = 0;
    (*logs)->config_list = NULL;
    for (c = 0; c < children; c++) {
        uint64_t is_log = B_FALSE;
        char *name;

        (void) nvlist_lookup_uint64(child[c], ZPOOL_CONFIG_IS_LOG,
            &is_log);
        if (!is_log)
            continue;
        (*logs)->count++;
        (*logs)->config_list = realloc((*logs)->config_list, sizeof(kzpool_status_config_t *) * (*logs)->count); /*TODO free*/
        kzpool_status_config_t *st_conf = NULL;

        name = zpool_vdev_name(g_zfs, zhp, child[c], B_TRUE);
        zpool_get_status_config(g_zfs, zhp, name, child[c], 2, B_FALSE, &st_conf);

        (*logs)->config_list[(*logs)->count - 1] = st_conf;
        free(name);
    }
    // if (zend_hash_num_elements(Z_ARRVAL_P(&subitem)) > 0)
    //     add_assoc_zval(item, "logs", &subitem);
}

static void
zpool_get_l2cache(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t **l2cache, uint_t nl2cache, kzpool_status_config_t **cache)
{
    uint_t i;
    char *name;

    if (nl2cache == 0)
        return;

    if (*cache == NULL) {
        *cache = malloc(sizeof(kzpool_status_config_t));
        if (*cache == NULL)
            return;
    }
    (*cache)->count = 0;
    (*cache)->config_list = NULL;
    for (i = 0; i < nl2cache; i++) {
        (*cache)->count++;
        (*cache)->config_list = realloc((*cache)->config_list, sizeof(kzpool_status_config_t *) * (*cache)->count); /*TODO free*/
        kzpool_status_config_t *st_conf = NULL;

        name = zpool_vdev_name(g_zfs, zhp, l2cache[i], B_FALSE);
        zpool_get_status_config(g_zfs, zhp, name, l2cache[i], 2, B_FALSE, &st_conf);

        (*cache)->config_list[(*cache)->count - 1] = st_conf;

        free(name);
    }
}

static void
zpool_get_spares(libzfs_handle_t *g_zfs, zpool_handle_t *zhp, nvlist_t **spares, uint_t nspares, kzpool_status_config_t **spares_cfg)
{
    uint_t i;
    char *name;

    if (nspares == 0)
        return;
    (*spares_cfg)->count = 0;
    (*spares_cfg)->config_list = NULL;
    for (i = 0; i < nspares; i++) {
        (*spares_cfg)->count++;
        (*spares_cfg)->config_list = realloc((*spares_cfg)->config_list, sizeof(kzpool_status_config_t *) * (*spares_cfg)->count); /*TODO free*/
        kzpool_status_config_t *st_conf = NULL;

        name = zpool_vdev_name(g_zfs, zhp, spares[i], B_FALSE);
        zpool_get_status_config(g_zfs, zhp, name, spares[i], 2, B_TRUE, &st_conf);

        (*spares_cfg)->config_list[(*spares_cfg)->count - 1] = st_conf;

        free(name);
    }
}

static char *
zpool_get_error_log(zpool_handle_t *zhp)
{
    nvlist_t *nverrlist = NULL;
    nvpair_t *elem;
    char *pathname;
    size_t len = MAXPATHLEN * 2;

    char tmp[512];
    if (zpool_get_errlog(zhp, &nverrlist) != 0) {
        snprintf(tmp, sizeof(tmp), "List of errors unavailable "
            "(insufficient privileges)");
        char *ret = malloc(strlen(tmp) + 1);
        if (ret == NULL)
            return NULL;
        snprintf(ret, strlen(tmp) + 1, "%s", tmp);
        return ret;
    }
    snprintf(tmp, sizeof(tmp), "Permanent errors have been "
        "detected in the following files:");

    pathname = malloc(len);
    elem = NULL;
    while ((elem = nvlist_next_nvpair(nverrlist, elem)) != NULL) {
        nvlist_t *nv;
        uint64_t dsobj, obj;

        nvpair_value_nvlist(elem, &nv);
        nvlist_lookup_uint64(nv, ZPOOL_ERR_DATASET,
            &dsobj);
        nvlist_lookup_uint64(nv, ZPOOL_ERR_OBJECT,
            &obj);
        zpool_obj_to_path(zhp, dsobj, obj, pathname, len);
        snprintf(tmp, sizeof(tmp), "%s, %s", tmp, pathname);
    }
    free(pathname);
    nvlist_free(nverrlist);
    char *ret = malloc(strlen(tmp) + 1);
    if (ret == NULL)
        return NULL;
    snprintf(ret, strlen(tmp) + 1, "%s", tmp);
    return ret;
}

static int
do_import(libzfs_handle_t *g_zfs, nvlist_t *config, const char *newname, const char *mntopts,
    nvlist_t *props, int flags)
{
    zpool_handle_t *zhp;
    char *name;
    uint64_t state;
    uint64_t version;
    nvlist_lookup_string(config, ZPOOL_CONFIG_POOL_NAME, &name);
    nvlist_lookup_uint64(config, ZPOOL_CONFIG_POOL_STATE, &state);
    nvlist_lookup_uint64(config, ZPOOL_CONFIG_VERSION, &version);
    if (!SPA_VERSION_IS_SUPPORTED(version)) {
        return (1);
    } else if (state != POOL_STATE_EXPORTED &&
        !(flags & ZFS_IMPORT_ANY_HOST)) {
        uint64_t hostid;

        if (nvlist_lookup_uint64(config, ZPOOL_CONFIG_HOSTID,
            &hostid) == 0) {
            if ((unsigned long)hostid != gethostid()) {
                char *hostname;
                uint64_t timestamp;
                time_t t;

                nvlist_lookup_string(config,
                    ZPOOL_CONFIG_HOSTNAME, &hostname);
                nvlist_lookup_uint64(config,
                    ZPOOL_CONFIG_TIMESTAMP, &timestamp);
                t = timestamp;
                return (1);
            }
        } else {
            return (1);
        }
    }

    if (zpool_import_props(g_zfs, config, newname, props, flags) != 0)
        return (1);

    if (newname != NULL)
        name = (char *)newname;

    if ((zhp = zpool_open_canfail(g_zfs, name)) == NULL)
        return (1);

    if (zpool_get_state(zhp) != POOL_STATE_UNAVAIL &&
        !(flags & ZFS_IMPORT_ONLY) &&
        zpool_enable_datasets(zhp, mntopts, 0) != 0) {
        zpool_close(zhp);
        return (1);
    }
    zpool_close(zhp);
    return (0);
}
