#ifndef KCS_KZFS_H
#define KCS_KZFS_H

#include <sys/types.h>
#include <sys/param.h>


#define KZFS_CONF_KENV_KEY							"kcs.kzfs.conf"
#define KZFS_CONF_KENV_DEFAULT						"zroot/cfg"
#define KZFS_PARAM_MAX_LEN							128

#define KZFS_ZPOOL_SCRUB_START						0
#define KZFS_ZPOOL_SCRUB_PAUSE						1
#define KZFS_ZPOOL_SCRUB_STOP						2

#define KZFS_ZPOOL_STATUS_STATE_LEN					10
#define KZFS_ZPOOL_STATUS_RBUF_LEN					6
#define KZFS_ZPOOL_STATUS_WBUF_LEN					6
#define KZFS_ZPOOL_STATUS_CBUF_LEN					6

#define KZFS_ZPOOL_DEV_TYPE_MAX_LEN					32

typedef struct kzpool_status_blk_size {
	int configured;
	int native;
} kzpool_status_blk_size_t;

typedef struct kzpool_status_config {
	char name[MAXPATHLEN];
	char state[KZFS_ZPOOL_STATUS_STATE_LEN];
	char rbuf[KZFS_ZPOOL_STATUS_RBUF_LEN];
	char wbuf[KZFS_ZPOOL_STATUS_WBUF_LEN];
	char cbuf[KZFS_ZPOOL_STATUS_CBUF_LEN];
	char *config_path;
	char *msg;
	kzpool_status_blk_size_t block_size;
	char *act;
	struct kzpool_status_config **config_list;
	int count;
} kzpool_status_config_t;

typedef struct kzpool_status {
	char name[MAXPATHLEN];
	uint64_t guid;
	char state[KZFS_ZPOOL_STATUS_STATE_LEN];
	char *status;
	char *action;
	char *scan;
	char *scan_warn;
	char *remove;
	char *checkpoint;
	kzpool_status_config_t *config;
	kzpool_status_config_t *logs;
	kzpool_status_config_t *cache;
	kzpool_status_config_t *spares;
	char *errors;
} kzpool_status_t;

typedef struct kzpool_import_config {
	char name[MAXPATHLEN];
	char state[KZFS_ZPOOL_STATUS_STATE_LEN];
	char *msg;
	struct kzpool_import_config **config_list;
	int config_count;
	char **cache_list;
	int cache_count;
	char **spares_list;
	int spares_count;
} kzpool_import_config_t;

typedef struct kzpool_import_info {
	char name[MAXPATHLEN];
	uint64_t guid;
	char state[KZFS_ZPOOL_STATUS_STATE_LEN];
	int destroyed;
	char *reason;
	char *action;
	char *comment;
	char *msg;
	char *warn;
	kzpool_import_config_t *logs;
	kzpool_import_config_t *config;
} kzpool_import_info_t;

typedef struct kzpool_import_list {
	kzpool_import_info_t **list;
	int count;
} kzpool_import_list_t;

typedef struct kzfs_snap {
	char *snapname;
	long creation;
	char *desc;
	char *used;
} kzfs_snap_t;

typedef struct kzfs_snap_list_st {
	kzfs_snap_t **list;
	int count;
} kzfs_snap_list_st_t;

typedef struct kzfs_mount_info {
	char *mi_special;
	char *mi_mountpoint;
} kzfs_mount_info_t;

typedef struct kzfs_mount_list_st {
	kzfs_mount_info_t **list;
	int count;
} kzfs_mount_list_st_t;

typedef struct kzfs_propval_list {
	char **props;
	char **values;
	int count;
} kzfs_propval_list_t;

typedef struct kzfs_prop_list {
	char **props;
	int count;
} kzfs_prop_list_t;

typedef struct kzfs_ds_info {
	char *zname;
	kzfs_propval_list_t *propval_list;
} kzfs_ds_info_t;

typedef struct kzfs_ds_list {
	kzfs_ds_info_t **ds_info_list;
	int count;
} kzfs_ds_list_t;

typedef struct kzfs_zpool_info {
	char *zpool_name;
	uint64_t guid;
	kzfs_propval_list_t *propval_list;
} kzfs_zpool_info_t;

typedef struct kzfs_zpool_list {
	kzfs_zpool_info_t **zpool_info_list;
	int count;
} kzfs_zpool_list_t;

typedef struct kzpool_dev_info {
	void **devs;
	char type[KZFS_ZPOOL_DEV_TYPE_MAX_LEN];
	int is_complex;
	int is_log;
	int count;
} kzpool_dev_info_t;

typedef struct kzpool_dev_list {
	kzpool_dev_info_t **list;
	int count;
} kzpool_dev_list_t;


int kzpool_destroy(const char *zpool_name);																				// done
int kzpool_export(const char *zpool_name, int force);																	// done
int kzpool_clear(const char *zpool_name, const char *dev, int do_rewind);												// wait (not tested)
int kzpool_reguid(const char *zpool_name);																				// wait (not tested)
int kzpool_reopen(const char *zpool_name);																				// wait (not tested)
int kzpool_labelclear(const char *dev, int force);																		// wait (not tested)
int kzpool_root_mount_from(char *value);																				// done
int kzpool_detach(const char *zpool_name, const char *dev);																// done
int kzpool_update(const char *zpool_name, kzfs_propval_list_t *list);													// wait (not tested)
int kzpool_attach(const char *zpool_name, const char *dev, const char *new_dev, int force);								// done
int kzpool_replace(const char *zpool_name, const char *dev, const char *new_dev, int force);							// done
int kzpool_import(const char *zpool_name, kzfs_propval_list_t *props_list);												// wait (not tested)
int kzpool_import_all(kzfs_propval_list_t *props_list);																	// wait (not tested)
kzfs_zpool_list_t *kzpool_list(kzfs_prop_list_t *props);																// done
int kzpool_scrub(const char *zpool_name, int cmd);																		// wait (not tested)
int kzpool_create(const char *zpool_name, kzpool_dev_list_t *devs_list, kzfs_propval_list_t *props_list,
	kzfs_propval_list_t *fs_props_list);																				// wait (not tested)
int kzpool_add(const char *zpool_name, kzpool_dev_list_t *devs_list, int force);										// done
int kzpool_split(const char *zpool_name, const char *new_zpool_name,
	kzfs_propval_list_t *props_list, kzpool_dev_info_t *devs);															// wait (not tested)
int kzpool_online(const char *zpool_name, kzpool_dev_info_t *devs, int expand);											// wait (not tested)
int kzpool_offline(const char *zpool_name, kzpool_dev_info_t *devs, int temp);											// wait (not tested)
kzpool_dev_list_t *kzpool_get_devs(const char *zpool_name);																// wait
kzpool_status_t *kzpool_status(const char *zpool_name);																	// wait (not tested)




kzpool_import_list_t *kzpool_import_list(char *cachefile, const char *search, int do_destroyed);						// wait (not tested)



int kzpool_prop_valid(const char *propname);																			// done
int kzpool_dev_info_fill(kzpool_dev_info_t **info, const char *type, int is_complex, int is_log, void *el);				// done
void kzpool_free_dev_info(kzpool_dev_info_t *info);																		// done
int kzpool_dev_list_fill(kzpool_dev_list_t **list, kzpool_dev_info_t *info);											// done
void kzpool_free_dev_list(kzpool_dev_list_t *list);																		// done
void kzpool_free_list(kzfs_zpool_list_t *list);																			// done
void kzpool_free_status(kzpool_status_t *status);																		// done
void kzpool_free_import_list(kzpool_import_list_t *import_list);														// wait (not tested)






char *kzfs_get_uprop(const char *dsname, const char *propname);
int kzfs_del_uprop(const char *dsname, const char *propname);
int kzfs_set_uprop(const char *dsname, const char *propname, const char *propval);


int kzfs_ds_destroy(const char *zname, int recursive);																	// done
int kzfs_ds_create(const char *zname, kzfs_propval_list_t *list);														// done
int kzfs_ds_rename(const char *zname, const char *new_zname, int force, int noumount, int parents);						// done
int kzfs_ds_update(const char *zname, kzfs_propval_list_t *list);														// done
kzfs_ds_list_t *kzfs_ds_list(kzfs_prop_list_t *props, const char *zname);												// done
void kzfs_free_ds_list(kzfs_ds_list_t *ds_list);																		// done
int kzfs_snap_create(const char *zname, const char *snapname, const char *desc, int recursive);							// done
int kzfs_snap_destroy(const char *zname, const char *snapname, int recursive);											// done
int kzfs_snap_rollback(const char *zname, const char *snapname);														// done
kzfs_snap_list_st_t *kzfs_snap_list(const char *zname);																	// done
void kzfs_free_snap_list(kzfs_snap_list_st_t *list);																	// done
int kzfs_snap_rename(const char *zname, const char *snapname, const char *new_snapname, int force, int recursive);		// done
int kzfs_snap_update(const char *zname, const char *snapname, const char *desc);										// done
int kzfs_send(const char *zname, const char *remote_ip, long remote_port, int move);									// done
int kzfs_recv(const char *zname, const char *local_ip, long local_port);												// done
int kzfs_settings_merge(char *from, char *to);																			// done
int kzfs_unmount(const char *entry, int force);																			// done
int kzfs_unmount_all(int force);																						// wait  (not tested)
int kzfs_mount(const char *zname, const char *mntopts);																	// done
int kzfs_mount_all(const char *mntopts);																				// done
kzfs_mount_list_st_t *kzfs_mount_list(void);																			// done
void kzfs_free_mount_list(kzfs_mount_list_st_t *list);																	// done
int kzfs_prop_valid(const char *propname);																				// done
int kzfs_props_val_fill(kzfs_propval_list_t **list, const char *propname, const char *value);							// done
void kzfs_free_props_val(kzfs_propval_list_t *list);																	// done
int kzfs_props_fill(kzfs_prop_list_t **list, const char *propname);														// done
void kzfs_free_props(kzfs_prop_list_t *list);																			// done



// PHP_FUNCTION(zfs_snap_rule_delete);			// done
// PHP_FUNCTION(zfs_snap_rule_set);				// done
// PHP_FUNCTION(zfs_snap_rule_get);				// done
// PHP_FUNCTION(zfs_all_props);					// done


#endif // KCS_KZFS_H