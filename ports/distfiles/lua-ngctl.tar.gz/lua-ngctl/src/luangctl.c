#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <ngraph.h>

static void l_pushtablestring(lua_State* L, char* key , char* value)
{
    lua_pushstring(L, key);
    lua_pushstring(L, value);
    lua_settable(L, -3);
}

static int libngctl_mkpeer(lua_State *L)
{
    const char *path = luaL_optstring(L, 1, NULL);
    const char *peer_type = luaL_optstring(L, 2, NULL);
    const char *our_hook = luaL_optstring(L, 3, NULL);
    const char *peer_hook = luaL_optstring(L, 4, NULL);
    if (peer_type != NULL && our_hook != NULL && peer_hook != NULL) {
        char buf[NG_PATHSIZ];
        int ret = ngraph_mkpeer_node_rc((char *)path, (char *)peer_type, (char *)our_hook, (char *)peer_hook, buf);
        if (!ret) {
            lua_pushstring(L, buf);
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int libngctl_connect(lua_State *L)
{
    const char *path = luaL_optstring(L, 1, NULL);
    const char *peer_node = luaL_optstring(L, 2, NULL);
    const char *our_hook = luaL_optstring(L, 3, NULL);
    const char *peer_hook = luaL_optstring(L, 4, NULL);
    if (path != NULL && peer_node != NULL && our_hook != NULL && peer_hook != NULL) {
        int ret = ngraph_connect_node(path, peer_node, our_hook, peer_hook);
        if (!ret) {
            lua_pushboolean(L, 1);
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int libngctl_shutdown(lua_State *L)
{
    const char *path = luaL_optstring(L, 1, NULL);
    if (path != NULL) {
        int type = luaL_optnumber(L, 2, 0);
        int ret = ngraph_shutdown_node(path, type);
        if (!ret) {
            lua_pushboolean(L, 1);
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int libngctl_name(lua_State *L)
{
    const char *path = luaL_optstring(L, 1, NULL);
    const char *name = luaL_optstring(L, 2, NULL);
    if (path != NULL && name != NULL) {
        int ret = ngraph_name_node(path, name);
        if (!ret) {
            lua_pushboolean(L, 1);
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int libngctl_msg(lua_State *L)
{
    const char *path = luaL_optstring(L, 1, NULL);
    const char *cmd = luaL_optstring(L, 2, NULL);
    const char *params = luaL_optstring(L, 3, NULL);
    if (path != NULL && cmd != NULL && params != NULL) {
        int ret = ngraph_msg_node(path, cmd, params);
        if (!ret) {
            lua_pushboolean(L, 1);
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int libngctl_msg_out(lua_State *L)
{
    const char *path = luaL_optstring(L, 1, NULL);
    const char *cmd = luaL_optstring(L, 2, NULL);
    const char *params = luaL_optstring(L, 3, NULL);
    if (path != NULL && cmd != NULL) {
        char *ret = ngraph_msg_node_rc(path, cmd, params == NULL ? "" : params);
        if (ret != NULL) {
            lua_pushstring(L, ret);
            free(ret);
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int libngctl_rmhook(lua_State *L)
{
    const char *path = luaL_optstring(L, 1, NULL);
    const char *hook = luaL_optstring(L, 2, NULL);
    if (path != NULL && hook != NULL) {
        int ret = ngraph_rmhook(path, hook);
        if (!ret) {
            lua_pushboolean(L, 1);
            return 1;
        }
    }

    lua_pushnil(L);
    return 1;
}

static int libngctl_list(lua_State *L)
{
    int size = 0;
    ngraph_info_t **ilist = ngraph_list(&size);
    if (size == 0 || ilist == NULL) {
        lua_pushnil(L);
        return 1;
    }

    for (int i = 0; i < size; i++) {
        if (!i)
            lua_newtable( L );
        lua_pushstring(L, ilist[i]->name);
        lua_newtable( L );
        l_pushtablestring(L, "type", ilist[i]->type);
        if (ilist[i]->hooks_count) {
            lua_pushstring(L, "hooks");
            lua_newtable( L );
            for (int j = 0; j < ilist[i]->hooks_count; j++) {
                lua_pushinteger(L, j + 1);
                lua_newtable( L );
                l_pushtablestring(L, "ourhook", ilist[i]->hooks[j]->ourhook);
                l_pushtablestring(L, "peerhook", ilist[i]->hooks[j]->peerhook);
                l_pushtablestring(L, "peername", ilist[i]->hooks[j]->peername);
                l_pushtablestring(L, "peertype", ilist[i]->hooks[j]->peertype);
                lua_settable( L, -3 );
            }
            lua_settable( L, -3 );
        }

        lua_settable( L, -3 );
        ngraph_info_node_free(ilist[i]);
    }
    free(ilist);

    return 1;
}

static int libngctl_load(lua_State *L)
{
    int ret = ngraph_load();
    if (!ret) {
        lua_pushboolean(L, 1);
    } else {
        lua_pushnil(L);
    }
    return 1;
}

static const luaL_Reg ngctl[] = {
    {"mkpeer", libngctl_mkpeer},
    {"connect", libngctl_connect},
    {"shutdown", libngctl_shutdown},
    {"name", libngctl_name},
    {"msg", libngctl_msg},
    {"msg_out", libngctl_msg_out},
    {"rmhook", libngctl_rmhook},
    {"list", libngctl_list},
    {"load", libngctl_load},
    {NULL, NULL}
};


#ifdef STATIC
LUAMOD_API int luaopen_libluangctl(lua_State *L)
#else
LUALIB_API int luaopen_libluangctl(lua_State *L)
#endif
{
    luaL_newlib(L, ngctl);
    return 1;
}