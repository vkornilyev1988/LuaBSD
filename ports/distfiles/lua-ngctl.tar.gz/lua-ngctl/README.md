REQUIREMENTS
	lua-5.3 or >, libkcs-ngraph, libm (standard)
	PREFIX=/usr/local/lib/lua/5.3
	CFLAGS+= -I/usr/local/include/lua53 -fsanitize=safe-stack
	LDFLAGS+= -L/usr/local/lib

DESCRIPTION
	libluangctl.so - модуль lua для работы с Netgraph

FUNCTIONS
    mkpeer(string path, string peer_type, string our_hook, string peer_hook);
		описание:
			Присоединить новый узел. Если необходимо только создать узел, то path = nil
		параметры:
			path - путь куда присоединить новый узел
			peer_type - тип создаваемого узла
			our_hook - хук к которому присоединить новый узел
			peer_hook - хук создаваемого узла
		возврат:
			nil/string - имя созданного узла или "unnamed"

    connect(string path, string peer_node, string our_hook, string peer_hook);
		описание:
			соединить два узла
		параметры:
			path - путь до первого узла
			peer_node - путь до второго узла
			our_hook - хук первого узла
			peer_hook - хук второго узла
		возврат:
			nil/true

    shutdown(string node [, int mode]);
		описание:
			удалить узел (узел с типом ether нельзя удалить). Если mode 0, то node это путь или имя узла, если mode 1 то node - это тип узлов
		параметры:
			node - путь/имя узла или тип узлов
			mode - режим удаления, по имени (0) или по типу (1) (по умолчанию 0)
		возврат:
			nil/true

    name(string path, string name);
		описание:
			назвать узел
		параметры:
			path - путь до узла
			name - новое имя узла
		возврат:
			nil/true

    msg(string path, string msg, string params);
		описание:
			отправить сообщение на узел
		параметры:
			path - путь до узла
			msg - сообщение (например setpromisc)
			params - дополнительные параметры
		возврат:
			nil/true

    msg_out(string path, string msg [, string params]);
		описание:
			отправить сообщение на узел и получить результат (если отправить сообщение которое в принципе не дает результата то функция зависает в ожидании него).
		параметры:
			path - путь до узла
			msg - сообщение (например getpromisc)
			params - дополнительные параметры (необязательный параметр)
		возврат:
			nil/true

    rmhook(string path, string hook);
		описание:
			отсоединить хук у узла. у узлов типа vlan, bridge если все хуки отсоединены узел удаляется автоматически
		параметры:
			path - путь до узла
			hook - имя хука
		возврат:
			nil/true

    list();
		описание:
			получить список узлов
		возврат:
			nil или таблица (пример 1 ниже)

    load();
		описание:
			применить конфигурацию из БД
		возврат:
			nil/true

EXAMPLES
	Пример 1. list();
		Листинг:
			#!/usr/local/bin/lua53
			ng = require('libluangctl')
			tb = ng.list();
			for k,v in pairs(tb) do
			        print("Name: " .. k .. "\t\t\tType: " .. v.type)
			        if (v.hooks) then
			                print("\tLocal hook\tPeer hook\tPeer name\tPeer type")
			                for k1, v1 in pairs(v.hooks) do
			                        print("\t" .. v1.ourhook .. "\t\t" .. v1.peerhook .. "\t\t" .. v1.peername .. "\t\t" .. v1.peertype)
			                end
			        end
			        print("-------------------------------------------------------------------------")
			end

		Вывод:
			Name: vtnet0			Type: ether
			-------------------------------------------------------------------------
			Name: vtnet1			Type: ether
			-------------------------------------------------------------------------
			Name: ngeth1			Type: eiface
				Local hook	Peer hook	Peer name	Peer type
				ether		vlan100		vl0			vlan
			-------------------------------------------------------------------------
			Name: ngeth0			Type: eiface
			-------------------------------------------------------------------------
			Name: vl0			Type: vlan
				Local hook	Peer hook	Peer name	Peer type
				vlan0		ether		ngeth2		eiface
				vlan100		ether		ngeth1		eiface
				downstream	lower		tap0		ether
			-------------------------------------------------------------------------
			Name: tap0			Type: ether
				Local hook	Peer hook	Peer name	Peer type
				lower		downstream		vl0		vlan
			-------------------------------------------------------------------------
			Name: ngctl21976			Type: socket
			-------------------------------------------------------------------------
			Name: ngeth2			Type: eiface
				Local hook	Peer hook	Peer name	Peer type
				ether		vlan0		vl0		vlan
			-------------------------------------------------------------------------
