REQUIREMENTS
	lua-5.3 or >, libkcs-base, libm, libutil, libkvm (standard)
	PREFIX=/usr/local/lib/lua/5.3
	CFLAGS+= -I/usr/local/include/lua53 -fsanitize=safe-stack
	LDFLAGS+= -L/usr/local/lib

DESCRIPTION
	libluasystem_os.so - модуль lua для работы с системой

FUNCTIONS
    pciconf();
		описание:
			получить информацию об устройствах
		возврат:
			nil или таблица (пример 4)

    ps([bool ret_table]);
		описание:
			получить информацию о процессах
		параметры:
			ret_table - если false, nil или отсутствует то информация выводится на экран, иначе возвращает таблицу с информацией
		возврат:
			nil или таблица (пример 3)

    diskinfo(string diskname [, bool ret_table]);
		описание:
			получить информацию о диске
		параметры:
			dickname - имя диска
			ret_table - если false, nil или отсутствует то информация выводится на экран, иначе возвращает таблицу с информацией
		возврат:
			nil или таблица (пример 2)

    fork(function f, args ...);
		описание:
			выполнить функцию lua в отдельном процессе
		параметры:
			f - функция которую необходимо выполнить, не название а именно функция
			args - агрументы функции
		возврат:
			nil/true

    chroot(string dir, string cmd [, bool is_parent]);
		описание:
			сменить корневую папку и выполнить команду
		параметры:
			dir - на какую папку сменить
			cmd - команда
			is_parent - если true то комнда заменить изначальную оболочку, иначе команда выполнится в дочернем процессе и после завершения вернется в изначальную оболочку
		возврат:
			nil/true

    cp(string from, string to);
		описание:
			копировать from в to
		параметры:
			from - что скопировать
			to - куда скопировать
		возврат:
			nil/true

    hostname(string hostname);
		описание:
			установить имя хоста
		параметры:
			hostname - имя хоста
		возврат:
			nil/true

    cmd(string cmd, string path_env);
		описание:
			выполнить команду в интерактивном режиме, без возврата в переменную
		параметры:
			cmd - команда для выполнения
			path_env - строка с переменной окружения PATH
		возврат:
			nil/true

    clear();
		описание:
			очистить экран
		возврат:
			nil

    exec(string cmd, string path_env);
		описание:
			выполнить команду
		параметры:
			cmd - команда для выполнения
			path_env - строка с переменной окружения PATH
		возврат:
			nil или string output

    exec_nowait(string cmd, string path_env);
		описание:
			выполнить команду в фоне
		параметры:
			cmd - команда для выполнения
			path_env - строка с переменной окружения PATH
		возврат:
			nil/pid

    execv(string path, string args, string path_env);
		описание:
			выполнить команду
		параметры:
			path - путь до команды
			args - аргументы команды, одной строкой
			path_env - строка с переменной окружения PATH
		возврат:
			nil или string output

    execv_nowait(string path, string args, string path_env);
		описание:
			выполнить команду в фоне
		параметры:
			path - путь до команды
			args - аргументы команды, одной строкой
			path_env - строка с переменной окружения PATH
		возврат:
			nil/pid

    kldload(string libname);
		описание:
			загрузить модуль в ядро
		параметры:
			libname - имя или путь до модуль
		возврат:
			nil/true

    kldunload(string libname [, int force]);
		описание:
			выгрузить модуль из ядра
		параметры:
			libname - имя или путь до модуль
			force - принудительная выгрузка
		возврат:
			nil/true

    kldstat([string libname]);
		описание:
			получить информацию обо всех или одном загруженных модулях
		параметры:
			libname - имя модуля
		возврат:
			nil или таблица (пример 1)

    kenv_get([string key]);
		описание:
			получить все значения из kenv, если указан key то одно значение
		параметры:
			key - ключ по которому получить значение
		возврат:
			nil/string значение/таблица {key1='value1', key2='value2'}

    kenv_set(string key, string value);
		описание:
			установить значение в kenv
		параметры:
			key - ключ по которому установить значение
			value - значение
		возврат:
			nil/true

    kenv_unset(string key);
		описание:
			удалить значение из kenv
		параметры:
			key - ключ по которому удалить значение
		возврат:
			nil/true

    mkdir(string path [, string mode [, bool is_all_path]]);
		описание:
			создать директорию
		параметры:
			path - путь до директории
			mode - режим создания директории. например 660
			is_all_path - создать отсутствующие директории в path автоматически
		возврат:
			nil/true

    ls(bool is_print [, string path]);
		описание:
			показать содержимое директории
		параметры:
			is_print - если true, то функция не вернет содержимое, а лишь выведет в консоль
			path - путь до директории
		возврат:
			nil

    rm(string path);
		описание:
			удалить директорию или файл
		параметры:
			path - путь до директории или файла
		возврат:
			nil/true

    pwd(bool logical);
		описание:
			получить имя рабочей директории. без параметра logical будет получена физическая текущая рабочая директория
		параметры:
			logical - получить логическую текущую рабочую дирукторию
		возврат:
			nil/string имя рабочей директории

    mount(string type, string mountpoint, string source);
		описание:
			примонтировать файловую систему. если параметров нет, то возвращает список примонтированных файловых систем.
		параметры:
			type - тип файловой системы (tmpfs, nullfs, devfs, procfs, fdescfs, cd9660)
			mountpoint - точка монтирования
			source - что монтировать (только для nullfs)
		возврат:
			nil/true/таблица список примонтированных файловых систем

    umount(string mountpoint);
		описание:
			размонтировать точку монтирования mountpoint
		параметры:
			mountpoint - точка монтирования
		возврат:
			nil/true

    reboot();
		описание:
			перезапустить хост
		возврат:
			nil/true

    shutdown();
		описание:
			выключить хост
		возврат:
			nil/true

    chown(string path, string username, string groupname, bool recursive);
		описание:
			установить пользователя и/или группу
		параметры:
			path - путь до директории или файла
			username - имя пользователя. может быть nil, если устанавливается только группа
			groupname - имя группы. может быть nil, если устанавливается только пользователь
			recursive - рекурсивная установка если true.
		возврат:
			nil/true

    chmod(string path, string mod, bool recursive);
		описание:
			изменить режимы файла или директории
		параметры:
			path - путь до директории или файла
			mode - режим, числовой ("660") или символьный ("+x"). числовой тоже желательно отправлять как string
			recursive - рекурсивная изменение если true.
		возврат:
			nil/true

    kill(int pid [, string signal]);
		описание:
			отправить сигнал процессу
		параметры:
			pid - идентификатор процесса
			signal - сигнал, который необходимо отправить. может быть в следующих вариантах:
				-SIGKILL
				SIGKILL
				-9
				9
				все вышеперечисленные варианты равнозначны.по умолчанию сигнал 15
		возврат:
			nil/true

EXAMPLES
	Пример 1. kldstat();
		Листинг:
			#!/usr/local/bin/lua53
			s = require('libluasystem_os')
			t = s.kldstat()
			for k,v in pairs(t) do print(k, v.name, v.path, v.refs, v.size) end

		Вывод:
			1	kernel	/boot/kernel/kernel	20	33488232
			2	zfs.ko	/boot/kernel/zfs.ko	1	4546192
			3	opensolaris.ko	/boot/kernel/opensolaris.ko	2	43088
			4	if_bridge.ko	/boot/kernel/if_bridge.ko	1	27240
			5	bridgestp.ko	/boot/kernel/bridgestp.ko	1	16576
			6	if_epair.ko	/boot/kernel/if_epair.ko	1	7744
			7	ng_ether.ko	/boot/kernel/ng_ether.ko	1	5600
			8	netgraph.ko	/boot/kernel/netgraph.ko	1	42840

	Пример 2. diskinfo(string diskname, bool ret_table);
		Листинг:
			s = require('libluasystem_os')
			t = s.diskinfo('/dev/vtbd0p1', true)
			for k,v in pairs(t) do print(k,v) end

		Вывод:
			sectorsize	512
			TRIM_UNMAP	No
			heads_firmware	255
			stripesize	8192
			rotation_rate	Unknown
			ident	BHYVE-31A6-D84F-5922
			stripeoffset	4096
			mediasize	512K
			cylinders_firmware	0
			sectors_firmware	63
			descr	

	Пример 3. ps(bool ret_table);
		Листинг:
			s = require('libluasystem_os')
			t = s.ps(true)
			for pid,val in pairs(t) do
				print(pid);
				for k,v in pairs(val) do
					print('\t' .. k, v)
				end
			end

		Вывод:
			72693
				command	lua53
				uid	0
				cmdline	lua53 
			0
				command	kernel
				uid	0
				cmdline	
			1
				command	init
				uid	0
				cmdline	/sbin/init -- 

			18083
				command	nano
				uid	1002
				cmdline	/usr/local/bin/nano /tmp/ke 

	Пример 4. pciconf();
		Листинг:
			s = require('libluasystem_os')
			t = s.pciconf()
			for k,v in pairs(t) do
				print(k);
				for k1,v1 in pairs(v) do
					print('\t',k1,v1)
				end
			end

		Вывод:
			1
				pc_class	0x060000
				pc_bus	0
				subclass	HOST-PCI
				pc_func	0
				chip	0x12751275
				class	bridge
				pc_name	hostb0
				pc_dev	0
				device	1275
				pc_domain	0
				vendor	1275
				hdr	0x00
				card	0x00000000
				rev	0x00
			2
				pc_class	0x010601
				pc_bus	0
				subclass	SATA
				pc_func	0
				chip	0x28218086
				class	mass storage
				pc_name	ahci0
				pc_dev	3
				device	2821
				pc_domain	0
				vendor	8086
				hdr	0x00
				card	0x00000000
				rev	0x00
