#define _ACL_PRIVATE
#define VM_AND_BUFFER_CACHE_SYNCHRONIZED

#include <sys/types.h>
#include <sys/fcntl.h>
#include <sys/stat.h>
#include <sys/reboot.h>
#include <sys/sysctl.h>
#include <sys/acl.h>
#include <sys/param.h>
#include <sys/wait.h>
#include <signal.h>
#ifdef VM_AND_BUFFER_CACHE_SYNCHRONIZED
#include <sys/mman.h>
#endif
#include <ctype.h>

#include <lua.h>
#include <lualib.h>
#include <lauxlib.h>
#include <time.h>
#include <sys/disk.h>
#include <sys/param.h>
#include <sys/linker.h>
#include <geom/geom_disk.h>
#include <sys/user.h>
#include <string.h>
#include <stdlib.h>
#include <libutil.h>
#include <kvm.h>
#include <paths.h>
#include <inttypes.h>
#include <err.h>
#include <errno.h>
#include <fts.h>
#include <kenv.h>
#include <sysexits.h>
#include <pwd.h>
#include <grp.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mount.h>
#include <sys/uio.h>
#include <dirent.h>
#include <base.h>

#include <sys/pciio.h>
#include <sys/queue.h>

#include <dev/pci/pcireg.h>


enum op { FILE_TO_FILE, FILE_TO_DIR, DIR_TO_DNE };

volatile sig_atomic_t info;
static int
cp_copy2(char *argv[], enum op type, int fts_options);

#define	STRIP_TRAILING_SLASH(p) {					\
	while ((p).p_end > (p).p_path + 1 && (p).p_end[-1] == '/')	\
	*--(p).p_end = 0;						\
}

static char emptystring[] = "";

typedef struct {
	char	*p_end;			/* pointer to NULL at end of path */
	char	*target_end;		/* pointer to end of target base */
	char	p_path[PATH_MAX];	/* pointer to the start of a path */
} PATH_T;

PATH_T to = { to.p_path, emptystring, "" };

#define	cp_pct(x, y)	((y == 0) ? 0 : (int)(100.0 * (x) / (y)))

static int copy_link(const FTSENT *p, int exists);
static int copy_fifo(struct stat *from_stat, int exists);
static int copy_special(struct stat *from_stat, int exists);
static int setfile(struct stat *fs, int fd);
static int preserve_fd_acls(int source_fd, int dest_fd);
static int preserve_dir_acls(struct stat *fs, char *source_dir, char *dest_dir);
static int copy_file(const FTSENT *entp, int dne);
/*
 * Memory strategy threshold, in pages: if physmem is larger then this, use a 
 * large buffer.
 */
#define PHYSPAGES_THRESHOLD (32*1024)

/* Maximum buffer size in bytes - do not allow it to grow larger than this. */
#define BUFSIZE_MAX (2*1024*1024)

/*
 * Small (default) buffer size in bytes. It's inefficient for this to be
 * smaller than MAXPHYS.
 */
#define BUFSIZE_SMALL (MAXPHYS)

static int
copy_file(const FTSENT *entp, int dne)
{
	static char *buf = NULL;
	static size_t bufsize;
	struct stat *fs;
	ssize_t wcount;
	size_t wresid;
	off_t wtotal;
	int ch, checkch, from_fd, rcount, rval, to_fd;
	char *bufp;
#ifdef VM_AND_BUFFER_CACHE_SYNCHRONIZED
	char *p;
#endif

	from_fd = to_fd = -1;
	if ((from_fd = open(entp->fts_path, O_RDONLY, 0)) == -1) {
		warn("%s", entp->fts_path);
		return (1);
	}

	fs = entp->fts_statp;

	/*
	 * If the file exists and we're interactive, verify with the user.
	 * If the file DNE, set the mode to be the from file, minus setuid
	 * bits, modified by the umask; arguably wrong, but it makes copying
	 * executables work right and it's been that way forever.  (The
	 * other choice is 666 or'ed with the execute bits on the from file
	 * modified by the umask.)
	 */
	if (!dne) {
		(void)unlink(to.p_path);
			to_fd = open(to.p_path,
			    O_WRONLY | O_TRUNC | O_CREAT,
			    fs->st_mode & ~(S_ISUID | S_ISGID));
	} else {
		to_fd = open(to.p_path, O_WRONLY | O_TRUNC | O_CREAT,
		    fs->st_mode & ~(S_ISUID | S_ISGID));
	}

	if (to_fd == -1) {
		warn("%s", to.p_path);
		rval = 1;
		goto done;
	}

	rval = 0;

		/*
		 * Mmap and write if less than 8M (the limit is so we don't
		 * totally trash memory on big files.  This is really a minor
		 * hack, but it wins some CPU back.
		 * Some filesystems, such as smbnetfs, don't support mmap,
		 * so this is a best-effort attempt.
		 */
#ifdef VM_AND_BUFFER_CACHE_SYNCHRONIZED
	if (S_ISREG(fs->st_mode) && fs->st_size > 0 &&
	    fs->st_size <= 8 * 1024 * 1024 &&
	    (p = mmap(NULL, (size_t)fs->st_size, PROT_READ,
	    MAP_SHARED, from_fd, (off_t)0)) != MAP_FAILED) {
		wtotal = 0;
		for (bufp = p, wresid = fs->st_size; ;
		    bufp += wcount, wresid -= (size_t)wcount) {
			wcount = write(to_fd, bufp, wresid);
			if (wcount <= 0)
				break;
			wtotal += wcount;
			if (info) {
				info = 0;
				(void)fprintf(stderr,
				    "%s -> %s %3d%%\n",
				    entp->fts_path, to.p_path,
				    cp_pct(wtotal, fs->st_size));
			}
			if (wcount >= (ssize_t)wresid)
				break;
		}
		if (wcount != (ssize_t)wresid) {
			warn("%s", to.p_path);
			rval = 1;
		}
		/* Some systems don't unmap on close(2). */
		if (munmap(p, fs->st_size) < 0) {
			warn("%s", entp->fts_path);
			rval = 1;
		}
	} else
#endif
	{
		if (buf == NULL) {
			/*
			 * Note that buf and bufsize are static. If
			 * malloc() fails, it will fail at the start
			 * and not copy only some files. 
			 */ 
			if (sysconf(_SC_PHYS_PAGES) > 
			    PHYSPAGES_THRESHOLD)
				bufsize = MIN(BUFSIZE_MAX, MAXPHYS * 8);
			else
				bufsize = BUFSIZE_SMALL;
			buf = malloc(bufsize);
			if (buf == NULL) {
				printf("%s\n", "Not enough memory");
				goto done;
			}

		}
		wtotal = 0;
		while ((rcount = read(from_fd, buf, bufsize)) > 0) {
			for (bufp = buf, wresid = rcount; ;
			    bufp += wcount, wresid -= wcount) {
				wcount = write(to_fd, bufp, wresid);
				if (wcount <= 0)
					break;
				wtotal += wcount;
				if (info) {
					info = 0;
					(void)fprintf(stderr,
					    "%s -> %s %3d%%\n",
					    entp->fts_path, to.p_path,
					    cp_pct(wtotal, fs->st_size));
				}
				if (wcount >= (ssize_t)wresid)
					break;
			}
			if (wcount != (ssize_t)wresid) {
				warn("%s", to.p_path);
				rval = 1;
				break;
			}
		}
		if (rcount < 0) {
			warn("%s", entp->fts_path);
			rval = 1;
		}
	}

	/*
	 * Don't remove the target even after an error.  The target might
	 * not be a regular file, or its attributes might be important,
	 * or its contents might be irreplaceable.  It would only be safe
	 * to remove it if we created it and its length is 0.
	 */

	if (setfile(fs, to_fd))
		rval = 1;
	if (preserve_fd_acls(from_fd, to_fd) != 0) 
		rval = 1;
	if (close(to_fd)) {
		warn("%s", to.p_path);
		rval = 1;
	}

done:
	if (from_fd != -1)
		(void)close(from_fd);
	return (rval);
}

static int
copy_link(const FTSENT *p, int exists)
{
	int len;
	char llink[PATH_MAX];

	if ((len = readlink(p->fts_path, llink, sizeof(llink) - 1)) == -1) {
		warn("readlink: %s", p->fts_path);
		return (1);
	}
	llink[len] = '\0';
	if (exists && unlink(to.p_path)) {
		warn("unlink: %s", to.p_path);
		return (1);
	}
	if (symlink(llink, to.p_path)) {
		warn("symlink: %s", llink);
		return (1);
	}
	return (setfile(p->fts_statp, -1));
}

static int
copy_fifo(struct stat *from_stat, int exists)
{
	if (exists && unlink(to.p_path)) {
		warn("unlink: %s", to.p_path);
		return (1);
	}
	if (mkfifo(to.p_path, from_stat->st_mode)) {
		warn("mkfifo: %s", to.p_path);
		return (1);
	}
	return (setfile(from_stat, -1));
}

static int
copy_special(struct stat *from_stat, int exists)
{
	if (exists && unlink(to.p_path)) {
		warn("unlink: %s", to.p_path);
		return (1);
	}
	if (mknod(to.p_path, from_stat->st_mode, from_stat->st_rdev)) {
		warn("mknod: %s", to.p_path);
		return (1);
	}
	return (setfile(from_stat, -1));
}

static int
setfile(struct stat *fs, int fd)
{
	static struct timespec tspec[2];
	struct stat ts;
	int rval, gotstat, islink, fdval;

	rval = 0;
	fdval = fd != -1;
	islink = !fdval && S_ISLNK(fs->st_mode);
	fs->st_mode &= S_ISUID | S_ISGID | S_ISVTX |
	    S_IRWXU | S_IRWXG | S_IRWXO;

	tspec[0] = fs->st_atim;
	tspec[1] = fs->st_mtim;
	if (fdval ? futimens(fd, tspec) : utimensat(AT_FDCWD, to.p_path, tspec,
	    islink ? AT_SYMLINK_NOFOLLOW : 0)) {
		warn("utimensat: %s", to.p_path);
		rval = 1;
	}
	if (fdval ? fstat(fd, &ts) :
	    (islink ? lstat(to.p_path, &ts) : stat(to.p_path, &ts)))
		gotstat = 0;
	else {
		gotstat = 1;
		ts.st_mode &= S_ISUID | S_ISGID | S_ISVTX |
		    S_IRWXU | S_IRWXG | S_IRWXO;
	}
	/*
	 * Changing the ownership probably won't succeed, unless we're root
	 * or POSIX_CHOWN_RESTRICTED is not set.  Set uid/gid before setting
	 * the mode; current BSD behavior is to remove all setuid bits on
	 * chown.  If chown fails, lose setuid/setgid bits.
	 */
	if (!gotstat || fs->st_uid != ts.st_uid || fs->st_gid != ts.st_gid)
		if (fdval ? fchown(fd, fs->st_uid, fs->st_gid) :
		    (islink ? lchown(to.p_path, fs->st_uid, fs->st_gid) :
		    chown(to.p_path, fs->st_uid, fs->st_gid))) {
			if (errno != EPERM) {
				warn("chown: %s", to.p_path);
				rval = 1;
			}
			fs->st_mode &= ~(S_ISUID | S_ISGID);
		}

	if (!gotstat || fs->st_mode != ts.st_mode)
		if (fdval ? fchmod(fd, fs->st_mode) :
		    (islink ? lchmod(to.p_path, fs->st_mode) :
		    chmod(to.p_path, fs->st_mode))) {
			warn("chmod: %s", to.p_path);
			rval = 1;
		}

	if (!gotstat || fs->st_flags != ts.st_flags)
		if (fdval ?
		    fchflags(fd, fs->st_flags) :
		    (islink ? lchflags(to.p_path, fs->st_flags) :
		    chflags(to.p_path, fs->st_flags))) {
			warn("chflags: %s", to.p_path);
			rval = 1;
		}

	return (rval);
}

static int
preserve_fd_acls(int source_fd, int dest_fd)
{
	acl_t acl;
	acl_type_t acl_type;
	int acl_supported = 0, ret, trivial;

	ret = fpathconf(source_fd, _PC_ACL_NFS4);
	if (ret > 0 ) {
		acl_supported = 1;
		acl_type = ACL_TYPE_NFS4;
	} else if (ret < 0 && errno != EINVAL) {
		warn("fpathconf(..., _PC_ACL_NFS4) failed for %s", to.p_path);
		return (1);
	}
	if (acl_supported == 0) {
		ret = fpathconf(source_fd, _PC_ACL_EXTENDED);
		if (ret > 0 ) {
			acl_supported = 1;
			acl_type = ACL_TYPE_ACCESS;
		} else if (ret < 0 && errno != EINVAL) {
			warn("fpathconf(..., _PC_ACL_EXTENDED) failed for %s",
			    to.p_path);
			return (1);
		}
	}
	if (acl_supported == 0)
		return (0);

	acl = acl_get_fd_np(source_fd, acl_type);
	if (acl == NULL) {
		warn("failed to get acl entries while setting %s", to.p_path);
		return (1);
	}
	if (acl_is_trivial_np(acl, &trivial)) {
		warn("acl_is_trivial() failed for %s", to.p_path);
		acl_free(acl);
		return (1);
	}
	if (trivial) {
		acl_free(acl);
		return (0);
	}
	if (acl_set_fd_np(dest_fd, acl, acl_type) < 0) {
		warn("failed to set acl entries for %s", to.p_path);
		acl_free(acl);
		return (1);
	}
	acl_free(acl);
	return (0);
}

static int
preserve_dir_acls(struct stat *fs, char *source_dir, char *dest_dir)
{
	acl_t (*aclgetf)(const char *, acl_type_t);
	int (*aclsetf)(const char *, acl_type_t, acl_t);
	struct acl *aclp;
	acl_t acl;
	acl_type_t acl_type;
	int acl_supported = 0, ret, trivial;

	ret = pathconf(source_dir, _PC_ACL_NFS4);
	if (ret > 0) {
		acl_supported = 1;
		acl_type = ACL_TYPE_NFS4;
	} else if (ret < 0 && errno != EINVAL) {
		warn("fpathconf(..., _PC_ACL_NFS4) failed for %s", source_dir);
		return (1);
	}
	if (acl_supported == 0) {
		ret = pathconf(source_dir, _PC_ACL_EXTENDED);
		if (ret > 0) {
			acl_supported = 1;
			acl_type = ACL_TYPE_ACCESS;
		} else if (ret < 0 && errno != EINVAL) {
			warn("fpathconf(..., _PC_ACL_EXTENDED) failed for %s",
			    source_dir);
			return (1);
		}
	}
	if (acl_supported == 0)
		return (0);

	/*
	 * If the file is a link we will not follow it.
	 */
	if (S_ISLNK(fs->st_mode)) {
		aclgetf = acl_get_link_np;
		aclsetf = acl_set_link_np;
	} else {
		aclgetf = acl_get_file;
		aclsetf = acl_set_file;
	}
	if (acl_type == ACL_TYPE_ACCESS) {
		/*
		 * Even if there is no ACL_TYPE_DEFAULT entry here, a zero
		 * size ACL will be returned. So it is not safe to simply
		 * check the pointer to see if the default ACL is present.
		 */
		acl = aclgetf(source_dir, ACL_TYPE_DEFAULT);
		if (acl == NULL) {
			warn("failed to get default acl entries on %s",
			    source_dir);
			return (1);
		}
		aclp = &acl->ats_acl;
		if (aclp->acl_cnt != 0 && aclsetf(dest_dir,
		    ACL_TYPE_DEFAULT, acl) < 0) {
			warn("failed to set default acl entries on %s",
			    dest_dir);
			acl_free(acl);
			return (1);
		}
		acl_free(acl);
	}
	acl = aclgetf(source_dir, acl_type);
	if (acl == NULL) {
		warn("failed to get acl entries on %s", source_dir);
		return (1);
	}
	if (acl_is_trivial_np(acl, &trivial)) {
		warn("acl_is_trivial() failed on %s", source_dir);
		acl_free(acl);
		return (1);
	}
	if (trivial) {
		acl_free(acl);
		return (0);
	}
	if (aclsetf(dest_dir, acl_type, acl) < 0) {
		warn("failed to set acl entries on %s", dest_dir);
		acl_free(acl);
		return (1);
	}
	acl_free(acl);
	return (0);
}

static int
cp_copy(char *from, char *target)
{
	int fts_options, r, have_trailing_slash;
	struct stat to_stat, tmp_stat;
	enum op type;

	fts_options = FTS_NOCHDIR | FTS_PHYSICAL;
	memset(to.p_path, 0, sizeof(to.p_path));
	if (strlcpy(to.p_path, target, sizeof(to.p_path)) >= sizeof(to.p_path)) {
		return -1;
	}
	to.p_end = to.p_path + strlen(to.p_path);
	if (to.p_path == to.p_end) {
		*to.p_end++ = '.';
		*to.p_end = 0;
	}
	have_trailing_slash = (to.p_end[-1] == '/');
	if (have_trailing_slash)
		STRIP_TRAILING_SLASH(to);
	to.target_end = to.p_end;

	r = stat(to.p_path, &to_stat);
	if (r == -1 && errno != ENOENT) {
		printf("%s\n", strerror(errno));
		return -1;
	}
	if (r == -1 || !S_ISDIR(to_stat.st_mode)) {
		if (r == -1) {
				lstat(from, &tmp_stat);

			if (S_ISDIR(tmp_stat.st_mode))
				type = DIR_TO_DNE;
			else
				type = FILE_TO_FILE;
		} else
			type = FILE_TO_FILE;

		if (have_trailing_slash && type == FILE_TO_FILE) {
			if (r == -1) {
				printf("directory %s does not exist",
				    to.p_path);
				return -1;
			} else
				printf("%s is not a directory", to.p_path);
		}
	} else
		type = FILE_TO_DIR;

	char *argv[2];
	argv[0] = from;
	argv[1] = NULL;

	return (cp_copy2(argv, type, fts_options));
}

static int
cp_copy2(char *argv[], enum op type, int fts_options)
{
	struct stat to_stat;
	FTS *ftsp;
	FTSENT *curr;
	int base = 0, dne, badcp, rval;
	size_t nlen;
	char *p, *target_mid;
	mode_t mask, mode;
	int pflag = 1;

	mask = ~umask(0777);
	umask(~mask);

	if ((ftsp = fts_open(argv, fts_options, NULL)) == NULL) {
		printf("fts_read: %s", strerror(errno));
		return -1;
	}
	for (badcp = rval = 0; (curr = fts_read(ftsp)) != NULL; badcp = 0) {
		switch (curr->fts_info) {
		case FTS_NS:
		case FTS_DNR:
		case FTS_ERR:
			warnx("%s: %s",
			    curr->fts_path, strerror(curr->fts_errno));
			badcp = rval = 1;
			continue;
		case FTS_DC:			/* Warn, continue. */
			warnx("%s: directory causes a cycle", curr->fts_path);
			badcp = rval = 1;
			continue;
		default:
			;
		}

		if (type != FILE_TO_FILE) {
			if (curr->fts_level == FTS_ROOTLEVEL) {
				if (type != DIR_TO_DNE) {
					p = strrchr(curr->fts_path, '/');
					base = (p == NULL) ? 0 :
					    (int)(p - curr->fts_path + 1);

					if (!strcmp(&curr->fts_path[base],
					    ".."))
						base += 1;
				} else
					base = curr->fts_pathlen;
			}

			p = &curr->fts_path[base];
			nlen = curr->fts_pathlen - base;
			target_mid = to.target_end;
			if (*p != '/' && target_mid[-1] != '/')
				*target_mid++ = '/';
			*target_mid = 0;
			if (target_mid - to.p_path + nlen >= PATH_MAX) {
				warnx("%s%s: name too long (not copied)",
				    to.p_path, p);
				badcp = rval = 1;
				continue;
			}
			(void)strncat(target_mid, p, nlen);
			to.p_end = target_mid + nlen;
			*to.p_end = 0;
			STRIP_TRAILING_SLASH(to);
		}

		if (curr->fts_info == FTS_DP) {
			if (!curr->fts_number)
				continue;
			if (pflag) {
				if (setfile(curr->fts_statp, -1))
					rval = 1;
				if (preserve_dir_acls(curr->fts_statp,
				    curr->fts_accpath, to.p_path) != 0)
					rval = 1;
			} else {
				mode = curr->fts_statp->st_mode;
				if ((mode & (S_ISUID | S_ISGID | S_ISTXT)) ||
				    ((mode | S_IRWXU) & mask) != (mode & mask))
					if (chmod(to.p_path, mode & mask) !=
					    0) {
						warn("chmod: %s", to.p_path);
						rval = 1;
					}
			}
			continue;
		}

		/* Not an error but need to remember it happened. */
		if (stat(to.p_path, &to_stat) == -1)
			dne = 1;
		else {
			if (to_stat.st_dev == curr->fts_statp->st_dev &&
			    to_stat.st_ino == curr->fts_statp->st_ino) {
				warnx("%s and %s are identical (not copied).",
				    to.p_path, curr->fts_path);
				badcp = rval = 1;
				if (S_ISDIR(curr->fts_statp->st_mode))
					(void)fts_set(ftsp, curr, FTS_SKIP);
				continue;
			}
			if (!S_ISDIR(curr->fts_statp->st_mode) &&
			    S_ISDIR(to_stat.st_mode)) {
				warnx("cannot overwrite directory %s with "
				    "non-directory %s",
				    to.p_path, curr->fts_path);
				badcp = rval = 1;
				continue;
			}
			dne = 0;
		}

		switch (curr->fts_statp->st_mode & S_IFMT) {
		case S_IFLNK:
			/* Catch special case of a non-dangling symlink. */
			if ((fts_options & FTS_LOGICAL) ||
			    ((fts_options & FTS_COMFOLLOW) &&
			    curr->fts_level == 0)) {
				if (copy_file(curr, dne))
					badcp = rval = 1;
			} else {	
				if (copy_link(curr, !dne))
					badcp = rval = 1;
			}
			break;
		case S_IFDIR:
			if (dne) {
				if (mkdir(to.p_path,
				    curr->fts_statp->st_mode | S_IRWXU) < 0) {
					printf("%s: %s", to.p_path, strerror(errno));
					return -1;
				}
			} else if (!S_ISDIR(to_stat.st_mode)) {
				errno = ENOTDIR;
				printf("%s: %s", to.p_path, strerror(errno));
				return -1;
			}
			curr->fts_number = pflag || dne;
			break;
		case S_IFBLK:
		case S_IFCHR:
			if (copy_special(curr->fts_statp, !dne))
				badcp = rval = 1;
			break;
		case S_IFSOCK:
			warnx("%s is a socket (not copied).",
			    curr->fts_path);
			break;
		case S_IFIFO:
			if (copy_fifo(curr->fts_statp, !dne))
				badcp = rval = 1;
			break;
		default:
			if (copy_file(curr, dne))
				badcp = rval = 1;
			break;
		}
	}
	if (errno) {
		printf("fts_read: %s", strerror(errno));
		return -1;
	}
	fts_close(ftsp);
	return (rval);
}

/*
 * Returns 1 if a directory has been created,
 * 2 if it already existed, and 0 on failure.
 */
static int
mkdir_build(char *path, mode_t omode)
{
	int vflag = 0;
	struct stat sb;
	mode_t numask, oumask;
	int first, last, retval;
	char *p;

	p = path;
	oumask = 0;
	retval = 1;
	if (p[0] == '/')		/* Skip leading '/'. */
		++p;
	for (first = 1, last = 0; !last ; ++p) {
		if (p[0] == '\0')
			last = 1;
		else if (p[0] != '/')
			continue;
		*p = '\0';
		if (!last && p[1] == '\0')
			last = 1;
		if (first) {
			oumask = umask(0);
			numask = oumask & ~(S_IWUSR | S_IXUSR);
			(void)umask(numask);
			first = 0;
		}
		if (last)
			(void)umask(oumask);
		if (mkdir(path, last ? omode : S_IRWXU | S_IRWXG | S_IRWXO) < 0) {
			if (errno == EEXIST || errno == EISDIR) {
				if (stat(path, &sb) < 0) {
					retval = 0;
					break;
				} else if (!S_ISDIR(sb.st_mode)) {
					if (last)
						errno = EEXIST;
					else
						errno = ENOTDIR;
					retval = 0;
					break;
				}
				if (last)
					retval = 2;
			} else {
				retval = 0;
				break;
			}
		}
		if (!last)
		    *p = '/';
	}
	if (!first && !last)
		(void)umask(oumask);
	return (retval);
}

static u_int
get_pageins(void)
{
	u_int pageins;
	size_t len;

	len = sizeof(pageins);
	if (sysctlbyname("vm.stats.vm.v_swappgsin", &pageins, &len, NULL, 0)
	    != 0) {
		warnx("v_swappgsin");
		return (0);
	}
	return pageins;
}


static char *
getcwd_logical(void)
{
	struct stat lg, phy;
	char *pwd;

	/*
	 * Check that $PWD is an absolute logical pathname referring to
	 * the current working directory.
	 */
	if ((pwd = getenv("PWD")) != NULL && *pwd == '/') {
		if (stat(pwd, &lg) == -1 || stat(".", &phy) == -1)
			return (NULL);
		if (lg.st_dev == phy.st_dev && lg.st_ino == phy.st_ino)
			return (pwd);
	}

	errno = ENOENT;
	return (NULL);
}

static int
signame_to_signum(const char *sig)
{
        int n;
                
        if (strncasecmp(sig, "SIG", 3) == 0)
                sig += 3;
        for (n = 1; n < sys_nsig; n++) {
                if (!strcasecmp(sys_signame[n], sig))
                        return (n);
        }
        return (-1);
}
         
static int
recursive_delete(const char *dir)
{
    int ret = 0;
    FTS *ftsp = NULL;
    FTSENT *curr;

    // Cast needed (in C) because fts_open() takes a "char * const *", instead
    // of a "const char * const *", which is only allowed in C++. fts_open()
    // does not modify the argument.
    char *files[] = { (char *) dir, NULL };

    // FTS_NOCHDIR  - Avoid changing cwd, which could cause unexpected behavior
    //                in multithreaded programs
    // FTS_PHYSICAL - Don't follow symlinks. Prevents deletion of files outside
    //                of the specified directory
    // FTS_XDEV     - Don't cross filesystem boundaries
    ftsp = fts_open(files, FTS_NOCHDIR | FTS_PHYSICAL | FTS_XDEV, NULL);
    if (!ftsp) {
        fprintf(stderr, "%s: fts_open failed: %s\n", dir, strerror(errno));
        ret = -1;
        goto finish;
    }

    while ((curr = fts_read(ftsp))) {
        switch (curr->fts_info) {
        case FTS_NS:
        case FTS_DNR:
        case FTS_ERR:
            fprintf(stderr, "%s: fts_read error: %s\n",
                    curr->fts_accpath, strerror(curr->fts_errno));
            break;

        case FTS_DC:
        case FTS_DOT:
        case FTS_NSOK:
            // Not reached unless FTS_LOGICAL, FTS_SEEDOT, or FTS_NOSTAT were
            // passed to fts_open()
            break;

        case FTS_D:
            // Do nothing. Need depth-first search, so directories are deleted
            // in FTS_DP
            break;

        case FTS_DP:
        case FTS_F:
        case FTS_SL:
        case FTS_SLNONE:
        case FTS_DEFAULT:
            if (remove(curr->fts_accpath) < 0) {
                fprintf(stderr, "%s: Failed to remove: %s\n",
                        curr->fts_path, strerror(errno));
                ret = -1;
            }
            break;
        }
    }

finish:
    if (ftsp) {
        fts_close(ftsp);
    }

    return ret;
}

static uid_t
id(const char *name, const char *type)
{
	uid_t val;
	char *ep;

	/*
	 * XXX
	 * We know that uid_t's and gid_t's are unsigned longs.
	 */
	errno = 0;
	val = strtoul(name, &ep, 10);
	if (errno || *ep != '\0')
		warnx("%s: illegal %s name", name, type);
	return (val);
}


static void
a_gid(const char *s, gid_t *gid)
{
	struct group *gr;

	if (s == NULL)			/* Argument was "uid[:.]". */
		return;
	*gid = ((gr = getgrnam(s)) != NULL) ? gr->gr_gid : id(s, "group");
}

static void
a_uid(const char *s, uid_t *uid)
{
	struct passwd *pw;

	if (s == NULL)			/* Argument was "[:.]gid". */
		return;
	*uid = ((pw = getpwnam(s)) != NULL) ? pw->pw_uid : id(s, "user");
}

static void
chownerr(const char *file, uid_t uid, gid_t gid)
{
	static uid_t euid = -1;
	static int ngroups = -1;
	static long ngroups_max;
	gid_t *groups;

	/* Check for chown without being root. */
	if (errno != EPERM || (uid != (uid_t)-1 &&
	    euid == (uid_t)-1 && (euid = geteuid()) != 0)) {
		warn("%s", file);
		return;
	}

	/* Check group membership; kernel just returns EPERM. */
	if (gid != (gid_t)-1 && ngroups == -1 &&
	    euid == (uid_t)-1 && (euid = geteuid()) != 0) {
		ngroups_max = sysconf(_SC_NGROUPS_MAX) + 1;
		if ((groups = malloc(sizeof(gid_t) * ngroups_max)) == NULL){
			return;
		}
		ngroups = getgroups(ngroups_max, groups);
		while (--ngroups >= 0 && gid != groups[ngroups]);
		free(groups);
		if (ngroups < 0) {
			warnx("you are not a member of group");
			return;
		}
	}
	warn("%s", file);
}

static int
may_have_nfs4acl(const FTSENT *ent, int hflag)
{
	int ret;
	static dev_t previous_dev = NODEV;
	static int supports_acls = -1;

	if (previous_dev != ent->fts_statp->st_dev) {
		previous_dev = ent->fts_statp->st_dev;
		supports_acls = 0;

		if (hflag)
			ret = lpathconf(ent->fts_accpath, _PC_ACL_NFS4);
		else
			ret = pathconf(ent->fts_accpath, _PC_ACL_NFS4);
		if (ret > 0)
			supports_acls = 1;
		else if (ret < 0 && errno != EINVAL)
			warn("%s", ent->fts_path);
	}

	return (supports_acls);
}



static void l_pushtablestring(lua_State* L, char* key , char* value)
{
    lua_pushstring(L, key);
    lua_pushstring(L, value);
    lua_settable(L, -3);
}

static void l_pushtablenumber(lua_State* L, char* key , int value)
{
    lua_pushstring(L, key);
    lua_pushnumber(L, value);
    lua_settable(L, -3);
}

static void l_pushtable_numkey_string(lua_State* L, int key , char* value)
{
    lua_pushinteger(L, key);
    lua_pushstring(L, value);
    lua_settable(L, -3);
}

static void l_pushtableinteger(lua_State* L, char* key , int value)
{
    lua_pushstring(L, key);
    lua_pushinteger(L, value);
    lua_settable(L, -3);
}

static int libsystem_os_cmd(lua_State *L)
{
	const char *cmd = luaL_optstring(L, 1, NULL);
	const char *path_env = luaL_optstring(L, 2, NULL);
	if (cmd != NULL) {
		int result = base_execs(cmd, path_env);
		if (!result) {
		    lua_pushboolean(L, 1);
		    return 1;
		}
	}
	lua_pushnil(L);
    return 1;
}


static int libsystem_os_execute(lua_State *L)
{
	const char *cmd = luaL_optstring(L, 1, NULL);
	const char *path_env = luaL_optstring(L, 2, NULL);
	if (cmd != NULL) {
		char *result = base_execs_out(cmd, path_env);
		if (result != NULL) {
		    lua_pushstring(L, result);
		    return 1;
		}
	}
	lua_pushnil(L);
    return 1;
}

static int libsystem_os_execute_v(lua_State *L)
{
	const char *path = luaL_optstring(L, 1, NULL);
	const char *args = luaL_optstring(L, 2, NULL);
	const char *path_env = luaL_optstring(L, 3, NULL);
	if (path != NULL && args != NULL) {
		char *result = base_execs_path_out((char *)path, args, path_env);
		if (result != NULL) {
		    lua_pushstring(L, result);
		    return 1;
		}
	}
	lua_pushnil(L);
    return 1;
}

static int libsystem_os_execute_nowait(lua_State *L)
{
	const char *cmd = luaL_optstring(L, 1, NULL);
	const char *path_env = luaL_optstring(L, 2, NULL);
	if (cmd != NULL) {
		pid_t pid = base_execl_nowait(cmd, path_env);
		lua_pushinteger(L, pid);
		return 1;
	}
	lua_pushnil(L);
    return 1;
}

static int libsystem_os_execute_nowait_v(lua_State *L)
{
	const char *path = luaL_optstring(L, 1, NULL);
	const char *args = luaL_optstring(L, 2, NULL);
	const char *path_env = luaL_optstring(L, 3, NULL);
	if (path != NULL && args != NULL) {
		pid_t pid = base_execl_path_nowait((char *)path, args, path_env);
		lua_pushinteger(L, pid);
		return 1;
	}
	lua_pushnil(L);
    return 1;
}

static int libsystem_os_kldload(lua_State *L)
{
	const char *libname = luaL_optstring(L, 1, NULL);
	int check_loaded = lua_toboolean(L, 2);

	if (libname != NULL) {
		int ret = kldload(libname);
		if (ret != -1 || (check_loaded && errno == EEXIST)) {
			lua_pushboolean(L, 1);
		    return 1;
		}
	}

	lua_pushnil(L);
    return 1;
}

static int libsystem_os_kldunload(lua_State *L)
{
	const char *libname = luaL_optstring(L, 1, NULL);
	int force = luaL_optnumber(L, 2, 0);

	if (libname != NULL) {
		int fid = kldfind(libname);
		if (fid != -1) {
			int ret = kldunloadf(fid, force ? LINKER_UNLOAD_FORCE : LINKER_UNLOAD_NORMAL);
			if (!ret) {
				lua_pushboolean(L, 1);
				return 1;
			}
		}
	}

	lua_pushnil(L);
    return 1;
}

static void kldstat_fill(lua_State *L, int fid, const char *libname)
{
	struct kld_file_stat stat;
	memset(&stat, 0, sizeof(struct kld_file_stat));

	stat.version = sizeof(struct kld_file_stat);

	if (kldstat(fid, &stat) == -1)
		return;

	if (libname != NULL && strncmp(libname, stat.name, strlen(stat.name) - 3) != 0)
		return;
	lua_pushinteger(L, fid);
    lua_newtable( L );

    l_pushtableinteger(L, "refs", stat.refs);
    l_pushtableinteger(L, "size", stat.size);
    l_pushtablestring(L, "name", stat.name);
    l_pushtablestring(L, "path", stat.pathname);

    lua_settable(L, -3);

}

static int libsystem_os_kldstat(lua_State *L)
{
	const char *libname = luaL_optstring(L, 1, NULL);
	int fid = 0;
	int first = 1;
	for (fid = kldnext(0); fid > 0; fid = kldnext(fid)) {
		if (first) {
			first = 0;
            lua_newtable( L );
		}

		kldstat_fill(L, fid, libname);
	}
	if (first)
		lua_pushnil(L);
    return 1;
}


/*
	string key
*/
static int libsystem_os_kenv_get(lua_State *L)
{
	const char *key = luaL_optstring(L, 1, NULL);
	if (key != NULL) {
		char value[KENV_MVALLEN + 1];

		if (key != NULL) {
			if (kenv(KENV_GET, key, value, KENV_MVALLEN + 1) > 0) {
				lua_pushstring(L, value);
				return 1;
			}
		}
	} else {
        char *buf, *bp, *cp;
        int buflen, envlen;

        envlen = kenv(KENV_DUMP, NULL, NULL, 0);
        if (envlen < 0) {
			lua_pushnil(L);
		    return 1;
        }
        for (;;) {
            buflen = envlen * 120 / 100;
            buf = calloc(1, buflen + 1);
            if (buf == NULL) {
				lua_pushnil(L);
			    return 1;
            }
            envlen = kenv(KENV_DUMP, NULL, buf, buflen);
            if (envlen < 0) {
                free(buf);
				lua_pushnil(L);
			    return 1;
            }
            if (envlen > buflen)
                free(buf);
            else
                break;
        }

        lua_newtable( L );
        for (bp = buf; *bp != '\0'; bp += strlen(bp) + 1) {
            cp = strchr(bp, '=');
            if (cp == NULL)
                continue;
            *cp++ = '\0';
            l_pushtablestring(L, bp, cp);
            bp = cp;
        }

        free(buf);
        return 1;
	}

	lua_pushnil(L);
    return 1;
}


/*
	string key
	string value
*/
static int libsystem_os_kenv_set(lua_State *L)
{
	const char *key = luaL_optstring(L, 1, NULL);
	
	const char *value = luaL_optstring(L, 2, NULL);
	if (key != NULL && value != NULL) {
		if (kenv(KENV_SET, key, (char *)value, strlen(value) + 1) == 0) {
			lua_pushboolean(L, 1);
			return 1;
		}
	}

	lua_pushnil(L);
    return 1;
}


/*
	string key
*/
static int libsystem_os_kenv_unset(lua_State *L)
{
	const char *key = luaL_optstring(L, 1, NULL);

	if (key != NULL) {
		if (kenv(KENV_UNSET, key, NULL, 0) == 0) {
			lua_pushboolean(L, 1);
			return 1;
		}
	}

	lua_pushnil(L);
    return 1;
}

/*
	string path
	int mode
	bool all_path
*/
static int libsystem_os_mkdir(lua_State *L)
{
	const char *path = luaL_optstring(L, 1, NULL);
	if (path == NULL) {
		lua_pushnil(L);
	    return 1;
	}
	const char *mode = luaL_optstring(L, 2, NULL);
	int pflag = lua_toboolean(L, 3);

	int exitval = 0, success = 0;
	mode_t omode = 0;
	void *set = NULL;

	if (mode == NULL) {
		omode = S_IRWXU | S_IRWXG | S_IRWXO;
	} else {
		if ((set = setmode(mode)) == NULL) {
			lua_pushnil(L);
		    return 1;
		}
		omode = getmode(set, S_IRWXU | S_IRWXG | S_IRWXO);
		free(set);
	}

	if (pflag) {
		success = mkdir_build((char *)path, omode);
	} else if (mkdir(path, omode) < 0) {
		success = 0;
	} else {
		success = 1;
	}
	if (!success) {
		exitval = 1;
	}
	if (success == 1 && mode != NULL && chmod(path, omode) == -1) {
		exitval = 1;
	}

	if (exitval)
		lua_pushnil(L);
	else
		lua_pushboolean(L, 1);
    return 1;
}

static int libsystem_os_ls(lua_State *L)
{
	const char *path = luaL_optstring(L, 1, NULL);
	int is_var = lua_toboolean(L, 2);
	DIR *dirp;
    struct stat states;
    struct dirent *direntp;

    if (path != NULL) {
    	if (access(path, F_OK) == 0) {
		    struct stat sb;
		    if (lstat(path, &sb) == 0) {
		    	if (S_ISLNK(sb.st_mode)) {
	                char targetName[PATH_MAX + 1];
				    if (is_var) {
						lua_newtable( L );
				    	lua_pushstring(L, path);

						if (readlink(path, targetName, PATH_MAX) != -1) {
					    	lua_pushstring(L, targetName);
		                } else {
					    	lua_pushstring(L, "invalid symbolic link!");
		                }
				    } else {
						if (readlink(path, targetName, PATH_MAX) != -1) {
		                    printf("%s -> %s\n", path, targetName);
		                } else {
		                    printf("%s -> (invalid symbolic link!)\n", path);
		                }
						lua_pushnil(L);
		            }
			    	return 1;
			    } else if (!S_ISDIR(sb.st_mode)) {
				    if (is_var) {
				    	lua_pushstring(L, path);
				    } else {
				    	printf("%s\n", path);
						lua_pushnil(L);
				    }
			    	return 1;
			    }
		    } else {
				lua_pushnil(L);
		    	return 1;
		    }
    	} else {
			lua_pushnil(L);
	    	return 1;
	    }
    }

    if (path == NULL)
    	path = ".";

    dirp = opendir(path);
    int i = 1;
    if (is_var)
		lua_newtable( L );

    while((direntp = readdir(dirp))!=NULL)
    {
    	if (!is_var) {
		    struct stat sb;
	        char full_path[PATH_MAX + 1];
	        char *del = "/";
	        if (path[strlen(path) - 1] == '/')
	        	del = "";
	    	snprintf(full_path, PATH_MAX, "%s%s%s", path, del, direntp->d_name);
		    if (lstat(full_path, &sb) == 0) {
		    	if (S_ISLNK(sb.st_mode)) {
	                char targetName[PATH_MAX + 1];
					if (readlink(full_path, targetName, PATH_MAX) != -1) {
	                    printf("%s -> %s\n", full_path, targetName);
	                } else {
	                    printf("%s -> (invalid symbolic link!)\n", full_path);
	                }
		    	} else {
		            printf("%s\n", full_path);
		    	}
	    	}
	    } else {
			l_pushtable_numkey_string(L, i++, direntp->d_name);
    	}
    }   

    if (!is_var)
		lua_pushnil(L);
    return 1;
}

static int libsystem_os_rm(lua_State *L)
{
	const char *path = luaL_optstring(L, 1, NULL);
	if (recursive_delete(path) < 0)
		lua_pushnil(L);
	else
		lua_pushboolean(L, 1);
    return 1;
}

static int libsystem_os_pwd(lua_State *L)
{
	int physical;
	physical = 1;

	int lflag = lua_toboolean(L, 1);
	if (lflag)
		physical = 0;

	char *p;
	if ((!physical && (p = getcwd_logical()) != NULL) ||
	    (p = getcwd(NULL, 0)) != NULL)
		lua_pushstring(L, p);
	else
		lua_pushnil(L);

    return 1;
}

static void l_get_mount_list(lua_State *L)
{
	int mntsize;
	struct statfs *mntbuf;
	if ((mntsize = getmntinfo(&mntbuf, MNT_NOWAIT)) == 0) {
		lua_pushnil(L);
		return;
	}

	lua_newtable( L );

	for (int i = 0; i < mntsize; i++) {
		lua_pushinteger(L, i + 1);
		lua_newtable( L );
		l_pushtablestring(L, "type", mntbuf[i].f_fstypename);
		l_pushtablestring(L, "mountpoint", mntbuf[i].f_mntonname);
		l_pushtablestring(L, "source", mntbuf[i].f_mntfromname);
		lua_settable( L, -3 );
	}
}

// int force = luaL_optnumber(L, 2, 0);
static int libsystem_os_mount(lua_State *L)
{
	if (lua_gettop(L) == 0) {
		l_get_mount_list(L);
	    return 1;
	}


	const char *type = luaL_optstring(L, 1, NULL);
	const char *mountpoint = luaL_optstring(L, 2, NULL);
	const char *source = luaL_optstring(L, 3, NULL);

	if (type == NULL || mountpoint == NULL) {
		lua_pushnil(L);
	    return 1;
	}

	int f = 0;
	if (strcmp(type, "nullfs") == 0 || 
		strcmp(type, "cd9660") == 0) {
		if(source == NULL) {
			lua_pushnil(L);
		    return 1;
		} else {
			f = 1;
		}
	}

	if (!f && source != NULL) {
		lua_pushnil(L);
	    return 1;
	}

	char *names[] = {"fstype", "fspath", "from"};

	struct iovec iov[6];
	int i = 4;
	iov[0].iov_base = __DECONST(char *, names[0]);
	iov[0].iov_len = strlen(names[0]) + 1;
	iov[1].iov_base = __DECONST(char *, type);
	iov[1].iov_len = strlen(type) + 1;
	iov[2].iov_base = __DECONST(char *, names[1]);
	iov[2].iov_len = strlen(names[1]) + 1;
	iov[3].iov_base = __DECONST(char *, mountpoint);
	iov[3].iov_len = strlen(mountpoint) + 1;

	if (f) {
		i = 6;
		iov[4].iov_base = __DECONST(char *, names[2]);
		iov[4].iov_len = strlen(names[2]) + 1;
		iov[5].iov_base = __DECONST(char *, source);
		iov[5].iov_len = strlen(source) + 1;
	}

	int ret = nmount(iov, i, 0);
	if (ret) {
		lua_pushnil(L);
	} else {
		lua_pushboolean(L, 1);
	}
    return 1;
}

static int libsystem_os_umount(lua_State *L)
{
	const char *mountpoint = luaL_optstring(L, 1, NULL);
	if (mountpoint != NULL)
		if (!unmount(mountpoint, 0)) {
			lua_pushboolean(L, 1);
			return 1;
		}
	lua_pushnil(L);
    return 1;
}

static int libsystem_os_reboot(lua_State *L)
{
	// char *cmd = INI_STR("kcs.reboot.cmd");
	// if (cmd == NULL)
	// 	RETURN_FALSE;
	// if (strcmp(cmd, "none") != 0) {
	// 	pid_t pid = fork();
	// 	if (pid == 0) {

	// 	} else if (pid == -1) {
	// 		RETURN_FALSE;
	// 	} else {
	// 		if (waitpid(pid, NULL, 0) < 0) {
	// 			RETURN_FALSE;
	//         }
	//     }
	// }

	u_int pageins;
	int howto = 0, sverrno, i;
	sync();
	(void)signal(SIGHUP,  SIG_IGN);
	(void)signal(SIGINT,  SIG_IGN);
	(void)signal(SIGQUIT, SIG_IGN);
	(void)signal(SIGTERM, SIG_IGN);
	(void)signal(SIGTSTP, SIG_IGN);
	(void)signal(SIGPIPE, SIG_IGN);
	if (kill(1, SIGTSTP) == -1) {
		lua_pushnil(L);
	    return 1;
	}

	if (kill(-1, SIGTERM) == -1 && errno != ESRCH) {
		lua_pushnil(L);
	    return 1;
	}
	sleep(2);
	for (i = 0; i < 20; i++) {
		pageins = get_pageins();
		sync();
		sleep(3);
		if (get_pageins() == pageins)
			break;
	}

	reboot(RB_AUTOBOOT);

restart:
	sverrno = errno;
	errx(1, "%s%s", kill(1, SIGHUP) == -1 ? "(can't restart init): " : "",
	    strerror(sverrno));
	lua_pushboolean(L, 1);
    return 1;
}

static int libsystem_os_shutdown(lua_State *L)
{
	u_int pageins;
	int howto = 0, sverrno, i;
	sync();
	(void)signal(SIGHUP,  SIG_IGN);
	(void)signal(SIGINT,  SIG_IGN);
	(void)signal(SIGQUIT, SIG_IGN);
	(void)signal(SIGTERM, SIG_IGN);
	(void)signal(SIGTSTP, SIG_IGN);
	(void)signal(SIGPIPE, SIG_IGN);
	if (kill(1, SIGTSTP) == -1) {
		lua_pushnil(L);
	    return 1;
	}

	if (kill(-1, SIGTERM) == -1 && errno != ESRCH) {
		lua_pushnil(L);
	    return 1;
	}
	sleep(2);
	for (i = 0; i < 20; i++) {
		pageins = get_pageins();
		sync();
		sleep(3);
		if (get_pageins() == pageins)
			break;
	}

	reboot(RB_HALT | RB_POWEROFF);

restart:
	sverrno = errno;
	errx(1, "%s%s", kill(1, SIGHUP) == -1 ? "(can't restart init): " : "",
	    strerror(sverrno));
	lua_pushboolean(L, 1);
    return 1;
}

static int libsystem_os_chown(lua_State *L)
{
	const char *path = luaL_optstring(L, 1, NULL);
	const char *u = luaL_optstring(L, 2, NULL);
	const char *g = luaL_optstring(L, 3, NULL);
	int Rflag = lua_toboolean(L, 4);

	if (u == NULL && g == NULL) {
		lua_pushnil(L);
	    return 1;
	}
	char *const pt = (char *)path;
	char *const path_tmp[] = {pt, NULL};

	FTS *ftsp;
	FTSENT *p;
	char *cp;
	int fts_options, rval;
	fts_options = FTS_PHYSICAL;

	uid_t uid;
	gid_t gid;
	uid = (uid_t)-1;
	gid = (gid_t)-1;
	a_gid(g, &gid);
	a_uid(u, &uid);

	if ((ftsp = fts_open(path_tmp, fts_options, 0)) == NULL) {
		lua_pushnil(L);
	    return 1;
	}

	for (rval = 0; (p = fts_read(ftsp)) != NULL;) {
		int atflag;

		if ((fts_options & FTS_LOGICAL) ||
		    ((fts_options & FTS_COMFOLLOW) &&
		    p->fts_level == FTS_ROOTLEVEL))
			atflag = 0;
		else
			atflag = AT_SYMLINK_NOFOLLOW;

		switch (p->fts_info) {
		case FTS_D:			/* Change it at FTS_DP. */
			if (!Rflag)
				fts_set(ftsp, p, FTS_SKIP);
			continue;
		case FTS_DNR:			/* Warn, chown. */
			warnx("%s: %s", p->fts_path, strerror(p->fts_errno));
			rval = 1;
			break;
		case FTS_ERR:			/* Warn, continue. */
		case FTS_NS:
			warnx("%s: %s", p->fts_path, strerror(p->fts_errno));
			rval = 1;
			continue;
		default:
			break;
		}
		if ((uid == (uid_t)-1 || uid == p->fts_statp->st_uid) &&
		    (gid == (gid_t)-1 || gid == p->fts_statp->st_gid))
			continue;
		if (fchownat(AT_FDCWD, p->fts_accpath, uid, gid, atflag) == -1) {
			chownerr(p->fts_path, uid, gid);
			rval = 1;
		}
	}
	if (errno)
		lua_pushnil(L);
	else
		lua_pushboolean(L, 1);

    return 1;
}

static int libsystem_os_chmod(lua_State *L)
{
	const char *path = luaL_optstring(L, 1, NULL);
	const char *mode = luaL_optstring(L, 2, NULL);

	if (path == NULL || mode == NULL) {
		lua_pushnil(L);
	    return 1;
	}

	FTS *ftsp;
	FTSENT *p;
	mode_t *set;
	char *const pt = (char *)path;
	char *const path_tmp[] = {pt, NULL};

	mode_t newmode;
	int Rflag = lua_toboolean(L, 3), rval, fts_options;
	if ((set = setmode(mode)) == NULL) {
		warnx("invalid file mode: %s", mode);
		lua_pushnil(L);
	    return 1;
	}

	if ((ftsp = fts_open(path_tmp, fts_options, 0)) == NULL) {
		warnx("fts_open failed");
		lua_pushnil(L);
	    return 1;
	}
	for (rval = 0; (p = fts_read(ftsp)) != NULL;) {
		int atflag;

		if ((fts_options & FTS_LOGICAL) ||
		    ((fts_options & FTS_COMFOLLOW) &&
		    p->fts_level == FTS_ROOTLEVEL))
			atflag = 0;
		else
			atflag = AT_SYMLINK_NOFOLLOW;

		switch (p->fts_info) {
		case FTS_D:
			if (!Rflag)
				fts_set(ftsp, p, FTS_SKIP);
			break;
		case FTS_DNR:			/* Warn, chmod. */
			warnx("%s: %s", p->fts_path, strerror(p->fts_errno));
			rval = 1;
			break;
		case FTS_DP:			/* Already changed at FTS_D. */
			continue;
		case FTS_ERR:			/* Warn, continue. */
		case FTS_NS:
			warnx("%s: %s", p->fts_path, strerror(p->fts_errno));
			rval = 1;
			continue;
		default:
			break;
		}
		newmode = getmode(set, p->fts_statp->st_mode);
		/*
		 * With NFSv4 ACLs, it is possible that applying a mode
		 * identical to the one computed from an ACL will change
		 * that ACL.
		 */
		if (may_have_nfs4acl(p, 0) == 0 &&
		    (newmode & ALLPERMS) == (p->fts_statp->st_mode & ALLPERMS))
				continue;
		if (fchmodat(AT_FDCWD, p->fts_accpath, newmode, atflag) == -1) {
			warn("%s", p->fts_path);
			rval = 1;
		}
	}
	if (errno)
		lua_pushnil(L);
	else
		lua_pushboolean(L, 1);
    return 1;
}

static int libsystem_os_kill(lua_State *L)
{
	int pid = luaL_optnumber(L, 1, -1);
	const char *sig = luaL_optstring(L, 2, NULL);

	if (pid == -1) {
		lua_pushnil(L);
	    return 1;
	}

	int numsig = SIGTERM;

	int len = 1;
	if (sig != NULL) {
		len += strlen(sig);
	}
	char buf[len];
	memset(buf, 0, len);
	snprintf(buf, len, "%s", sig == NULL ? "" : sig);

	char *p = buf;

	if (*p == '-') {
		p++;
	}

	if (isdigit(*p)) {
		numsig = strtol(p, NULL, 10);
		if (numsig < 0 || numsig >= sys_nsig) {
			lua_pushnil(L);
		    return 1;
		}
	} else if (isalpha(*p)) {
		numsig = signame_to_signum(p);
		if (numsig < 0)  {
			lua_pushnil(L);
		    return 1;
		}
	}

	int ret = kill(pid, numsig);

	if (ret)
		lua_pushnil(L);
	else
		lua_pushboolean(L, 1);
    return 1;
}

static int libsystem_os_clear(lua_State *L)
{
	const char clr[] ="\e[1;1H\e[2J";
	printf("%s", clr);
	
	lua_pushnil(L);
    return 1;
}

static int libsystem_os_cp(lua_State *L)
{
	const char *from = luaL_optstring(L, 1, NULL);
	const char *to = luaL_optstring(L, 2, NULL);

	if (from != NULL && to != NULL) {
		if (!cp_copy((char *)from, (char *)to)) {
			lua_pushboolean(L, 1);
		    return 1;
		}
	}

	lua_pushnil(L);
    return 1;
}

static int libsystem_os_hostname(lua_State *L)
{
	const char *new_hostname = luaL_optstring(L, 1, NULL);

	if (new_hostname != NULL) {
		char buf[_POSIX_HOST_NAME_MAX + 1];
		if (gethostname(buf, sizeof(buf)) != -1) {
			if (strcmp(new_hostname, buf) != 0) {
				if (sethostname(new_hostname, strlen(new_hostname) + 1) != -1) {
					lua_pushboolean(L, 1);
					return 1;
				}
			}
		}
	}

	lua_pushnil(L);
    return 1;
}

static int libsystem_os_chroot(lua_State *L)
{
	const char *dir = luaL_optstring(L, 1, NULL);
	const char *cmd = luaL_optstring(L, 2, NULL);
	int is_parent = lua_toboolean(L, 3);

	if (dir != NULL && cmd != NULL) {
		if (!is_parent) {
			pid_t child;
			child = fork();
			if (!child) {
				if (chdir(dir) == -1 || chroot(".") == -1)
					_exit(1);
				char *list[BASE_EXEC_MAX_ARGS];
				int list_count;
				char cmd2[strlen(cmd) + 1];
				snprintf(cmd2, sizeof(cmd2), "%s", cmd);
				parse_line(cmd2, list, BASE_EXEC_MAX_ARGS - 1, &list_count, " ");
				execvp(list[0], list);
				_exit(-1);
			} else {
				int status;
				if (waitpid(child, &status, 0) < 0 || status) {
					lua_pushnil(L);
					return 1;
		        }
				lua_pushboolean(L, 1);
				return 1;
			}
		} else {
			if (chdir(dir) == -1 || chroot(".") == -1) {
				lua_pushnil(L);
				return 1;
	        }	
			char *list[BASE_EXEC_MAX_ARGS];
			int list_count;
			char cmd2[strlen(cmd) + 1];
			snprintf(cmd2, sizeof(cmd2), "%s", cmd);
			parse_line(cmd2, list, BASE_EXEC_MAX_ARGS - 1, &list_count, " ");
			execvp(list[0], list);

		}
	}

	lua_pushnil(L);
    return 1;
}

static int libsystem_os_run_func(lua_State *L)
{
	pid_t child;
	child = fork();
	signal(SIGCHLD, SIG_IGN);
	if (!child) {
			char infile[] = "/dev/null";

			close(STDIN_FILENO);
		    stdin=fopen(infile,"r");   //fd=0
			lua_call(L, lua_gettop(L) - 1, 0);
			_exit(1);
	} else if (child > 0) {
		lua_pushinteger(L, child);
		return 1;
	}

	lua_pushnil(L);
    return 1;
}
#define	MAXTX	(8*1024*1024)

static int
candelete(int fd)
{
	struct diocgattr_arg arg;

	strlcpy(arg.name, "GEOM::candelete", sizeof(arg.name));
	arg.len = sizeof(arg.value.i);
	if (ioctl(fd, DIOCGATTR, &arg) == 0)
		return (arg.value.i != 0);
	else
		return (0);
}
static void
rotationrate(int fd, char *rate, size_t buflen)
{
	struct diocgattr_arg arg;
	int ret;

	strlcpy(arg.name, "GEOM::rotation_rate", sizeof(arg.name));
	arg.len = sizeof(arg.value.u16);

	ret = ioctl(fd, DIOCGATTR, &arg);
	if (ret < 0 || arg.value.u16 == DISK_RR_UNKNOWN)
		snprintf(rate, buflen, "Unknown");
	else if (arg.value.u16 == DISK_RR_NON_ROTATING)
		snprintf(rate, buflen, "%d", 0);
	else if (arg.value.u16 >= DISK_RR_MIN && arg.value.u16 <= DISK_RR_MAX)
		snprintf(rate, buflen, "%d", arg.value.u16);
	else
		snprintf(rate, buflen, "Invalid");
}


static int
zonecheck(int fd, uint32_t *zone_mode, char *zone_str, size_t zone_str_len)
{
	struct disk_zone_args zone_args;
	int error;

	bzero(&zone_args, sizeof(zone_args));

	zone_args.zone_cmd = DISK_ZONE_GET_PARAMS;
	error = ioctl(fd, DIOCZONECMD, &zone_args);

	if (error == 0) {
		*zone_mode = zone_args.zone_params.disk_params.zone_mode;

		switch (*zone_mode) {
		case DISK_ZONE_MODE_NONE:
			snprintf(zone_str, zone_str_len, "Not_Zoned");
			break;
		case DISK_ZONE_MODE_HOST_AWARE:
			snprintf(zone_str, zone_str_len, "Host_Aware");
			break;
		case DISK_ZONE_MODE_DRIVE_MANAGED:
			snprintf(zone_str, zone_str_len, "Drive_Managed");
			break;
		case DISK_ZONE_MODE_HOST_MANAGED:
			snprintf(zone_str, zone_str_len, "Host_Managed");
			break;
		default:
			snprintf(zone_str, zone_str_len, "Unknown_zone_mode_%u",
			    *zone_mode);
			break;
		}
	}
	return (error);
}



static int libsystem_os_diskinfo(lua_State *L)
{
	if (lua_gettop(L) > 2) {
		lua_pushnil(L);
	    return 1;
	}
	struct stat sb;
	uint8_t *buf;
	int fd, error;
	char tstr[BUFSIZ], ident[DISK_IDENT_SIZE], physpath[MAXPATHLEN];
	char zone_desc[64];
	char rrate[64];
	uint32_t zone_mode;

	off_t mediasize, stripesize, stripeoffset;
	u_int sectorsize, fwsectors, fwheads, zoned = 0, isreg;

	if (posix_memalign((void **)&buf, PAGE_SIZE, MAXTX)) {
		lua_pushnil(L);
	    return 1;
	}

	if (lua_isstring(L, 1)) {
		const char *disk = luaL_optstring(L, 1, NULL);

		fd = open(disk, O_RDONLY | O_DIRECT);
		if (fd < 0 && errno == ENOENT && *disk != '/') {
			snprintf(tstr, sizeof(tstr), "%s%s", _PATH_DEV, disk);
			fd = open(tstr, O_RDONLY);
		}
		if (fd < 0) {
			goto error;
		}
		error = fstat(fd, &sb);
		if (error != 0) {
			goto error;
		}
		isreg = S_ISREG(sb.st_mode);
		if (isreg) {
			mediasize = sb.st_size;
			sectorsize = S_BLKSIZE;
			fwsectors = 0;
			fwheads = 0;
			stripesize = sb.st_blksize;
			stripeoffset = 0;
		} else {
			error = ioctl(fd, DIOCGMEDIASIZE, &mediasize);
			if (error) {
				goto error;
			}
			error = ioctl(fd, DIOCGSECTORSIZE, &sectorsize);
			if (error) {
				goto error;
			}
			error = ioctl(fd, DIOCGFWSECTORS, &fwsectors);
			if (error)
				fwsectors = 0;
			error = ioctl(fd, DIOCGFWHEADS, &fwheads);
			if (error)
				fwheads = 0;
			error = ioctl(fd, DIOCGSTRIPESIZE, &stripesize);
			if (error)
				stripesize = 0;
			error = ioctl(fd, DIOCGSTRIPEOFFSET, &stripeoffset);
			if (error)
				stripeoffset = 0;
			error = zonecheck(fd, &zone_mode, zone_desc, sizeof(zone_desc));
			if (error == 0)
				zoned = 1;
		}
		humanize_number(tstr, 5, (int64_t)mediasize, "",
		    HN_AUTOSCALE, HN_B | HN_NOSPACE | HN_DECIMAL);

		struct diocgattr_arg arg;
		if (lua_gettop(L) == 1) {

			printf("\t%-12u\t# sectorsize\n", sectorsize);
			printf("\t%-12jd\t# mediasize in bytes (%s)\n",
			    (intmax_t)mediasize, tstr);
			printf("\t%-12jd\t# mediasize in sectors\n",
			    (intmax_t)mediasize/sectorsize);
			printf("\t%-12jd\t# stripesize\n", stripesize);
			printf("\t%-12jd\t# stripeoffset\n", stripeoffset);
			if (fwsectors != 0 && fwheads != 0) {
				printf("\t%-12jd\t# Cylinders according to firmware.\n", (intmax_t)mediasize /
				    (fwsectors * fwheads * sectorsize));
				printf("\t%-12u\t# Heads according to firmware.\n", fwheads);
				printf("\t%-12u\t# Sectors according to firmware.\n", fwsectors);
			}
			strlcpy(arg.name, "GEOM::descr", sizeof(arg.name));
			arg.len = sizeof(arg.value.str);
			if (ioctl(fd, DIOCGATTR, &arg) == 0)
				printf("\t%-12s\t# Disk descr.\n", arg.value.str);
			if (ioctl(fd, DIOCGIDENT, ident) == 0)
				printf("\t%-12s\t# Disk ident.\n", ident);
			if (ioctl(fd, DIOCGPHYSPATH, physpath) == 0)
				printf("\t%-12s\t# Physical path\n", physpath);
			printf("\t%-12s\t# TRIM/UNMAP support\n",
			    candelete(fd) ? "Yes" : "No");
			rotationrate(fd, rrate, sizeof(rrate));
			printf("\t%-12s\t# Rotation rate in RPM\n", rrate);
			if (zoned != 0)
				printf("\t%-12s\t# Zone Mode\n", zone_desc);
		} else if (lua_gettop(L) == 2 && lua_toboolean(L, 2)) {
			lua_newtable(L);
			l_pushtableinteger(L, "sectorsize", sectorsize);
			l_pushtablestring(L, "mediasize", tstr);

			l_pushtableinteger(L, "stripesize", stripesize);
			l_pushtableinteger(L, "stripeoffset", stripeoffset);

			if (fwsectors != 0 && fwheads != 0) {
				l_pushtableinteger(L, "cylinders_firmware", mediasize / (fwsectors * fwheads * sectorsize));
				l_pushtableinteger(L, "heads_firmware", fwheads);
				l_pushtableinteger(L, "sectors_firmware", fwsectors);
			}
			strlcpy(arg.name, "GEOM::descr", sizeof(arg.name));
			arg.len = sizeof(arg.value.str);
			if (ioctl(fd, DIOCGATTR, &arg) == 0) {
				l_pushtablestring(L, "descr", arg.value.str);
			}
			if (ioctl(fd, DIOCGIDENT, ident) == 0) {
				l_pushtablestring(L, "ident", ident);
			}
			if (ioctl(fd, DIOCGPHYSPATH, physpath) == 0) {
				l_pushtablestring(L, "physpath", physpath);
			}
			l_pushtablestring(L, "TRIM_UNMAP", candelete(fd) ? "Yes" : "No");
			rotationrate(fd, rrate, sizeof(rrate));
			l_pushtablestring(L, "rotation_rate", rrate);
			if (zoned != 0) {
				l_pushtablestring(L, "zone_mode", zone_desc);
			}
			free(buf);
			return 1;
		}
	}

error:
	free(buf);
	lua_pushnil(L);
    return 1;
}

static int libsystem_os_ps(lua_State *L)
{
	if (lua_gettop(L) > 1) {
		lua_pushnil(L);
	    return 1;
	}
	char errbuf[_POSIX2_LINE_MAX];
    kvm_t *kernel = kvm_openfiles(NULL, NULL, NULL, O_RDONLY, errbuf);
    int n = 0;
    struct kinfo_proc *kinfo = kvm_getprocs(kernel, KERN_PROC_PROC, 0, &n);
    int f = lua_toboolean(L, 1);
	if (f) {
		lua_newtable(L);
        for (int i = 0; i < n; i++) {
        	lua_pushinteger(L, kinfo[i].ki_pid);
			lua_newtable(L);
			l_pushtableinteger(L, "uid", kinfo[i].ki_uid);
			l_pushtablestring(L, "command", kinfo[i].ki_comm);
			char buf[ARG_MAX];
			int len = 0;
            memset(buf, 0, sizeof(buf));
            char *p = buf;
            char **args = kvm_getargv(kernel, &kinfo[i], 0);
            if (args != NULL)
                while (*args) {
                	len = strlen(*args);
                	memmove(p, *args, len);
                	p = p + len;
                    *p = ' ';
                    p++;
                    args++;
                }
            l_pushtablestring(L, "cmdline", buf[0] ? buf : "");
			lua_settable( L, -3 );
        }

	} else {
		printf("%s\t%s\t%s\t\t%s\n", "UID", "PID", "COMMAND", "CMDLINE");
        for (int i = 0; i < n; i++) {
            char **args = kvm_getargv(kernel, &kinfo[i], 0);
            printf("%u\t%u\t%s\t\t", kinfo[i].ki_uid, kinfo[i].ki_pid, kinfo[i].ki_comm);
            if (args != NULL)
                while (*args) {
                    printf("%s ", (*args));
                    args++;
                }
            printf("%s", "\n");
        }
	}
    kvm_close(kernel);
    if (!f)
		lua_pushnil(L);
    return 1;
}

static const char *guess_class(struct pci_conf *p);
static const char *guess_subclass(struct pci_conf *p);
static struct pcisel getsel(const char *str);
static struct pcisel parsesel(const char *str);
static struct pcisel getdevice(const char *name);

#define	_PATH_DEVPCI	"/dev/pci"

static struct
{
	int	class;
	int	subclass;
	const char *desc;
} pci_nomatch_tab[] = {
	{PCIC_OLD,		-1,			"old"},
	{PCIC_OLD,		PCIS_OLD_NONVGA,	"non-VGA display device"},
	{PCIC_OLD,		PCIS_OLD_VGA,		"VGA-compatible display device"},
	{PCIC_STORAGE,		-1,			"mass storage"},
	{PCIC_STORAGE,		PCIS_STORAGE_SCSI,	"SCSI"},
	{PCIC_STORAGE,		PCIS_STORAGE_IDE,	"ATA"},
	{PCIC_STORAGE,		PCIS_STORAGE_FLOPPY,	"floppy disk"},
	{PCIC_STORAGE,		PCIS_STORAGE_IPI,	"IPI"},
	{PCIC_STORAGE,		PCIS_STORAGE_RAID,	"RAID"},
	{PCIC_STORAGE,		PCIS_STORAGE_ATA_ADMA,	"ATA (ADMA)"},
	{PCIC_STORAGE,		PCIS_STORAGE_SATA,	"SATA"},
	{PCIC_STORAGE,		PCIS_STORAGE_SAS,	"SAS"},
	{PCIC_STORAGE,		PCIS_STORAGE_NVM,	"NVM"},
	{PCIC_NETWORK,		-1,			"network"},
	{PCIC_NETWORK,		PCIS_NETWORK_ETHERNET,	"ethernet"},
	{PCIC_NETWORK,		PCIS_NETWORK_TOKENRING,	"token ring"},
	{PCIC_NETWORK,		PCIS_NETWORK_FDDI,	"fddi"},
	{PCIC_NETWORK,		PCIS_NETWORK_ATM,	"ATM"},
	{PCIC_NETWORK,		PCIS_NETWORK_ISDN,	"ISDN"},
	{PCIC_DISPLAY,		-1,			"display"},
	{PCIC_DISPLAY,		PCIS_DISPLAY_VGA,	"VGA"},
	{PCIC_DISPLAY,		PCIS_DISPLAY_XGA,	"XGA"},
	{PCIC_DISPLAY,		PCIS_DISPLAY_3D,	"3D"},
	{PCIC_MULTIMEDIA,	-1,			"multimedia"},
	{PCIC_MULTIMEDIA,	PCIS_MULTIMEDIA_VIDEO,	"video"},
	{PCIC_MULTIMEDIA,	PCIS_MULTIMEDIA_AUDIO,	"audio"},
	{PCIC_MULTIMEDIA,	PCIS_MULTIMEDIA_TELE,	"telephony"},
	{PCIC_MULTIMEDIA,	PCIS_MULTIMEDIA_HDA,	"HDA"},
	{PCIC_MEMORY,		-1,			"memory"},
	{PCIC_MEMORY,		PCIS_MEMORY_RAM,	"RAM"},
	{PCIC_MEMORY,		PCIS_MEMORY_FLASH,	"flash"},
	{PCIC_BRIDGE,		-1,			"bridge"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_HOST,	"HOST-PCI"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_ISA,	"PCI-ISA"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_EISA,	"PCI-EISA"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_MCA,	"PCI-MCA"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_PCI,	"PCI-PCI"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_PCMCIA,	"PCI-PCMCIA"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_NUBUS,	"PCI-NuBus"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_CARDBUS,	"PCI-CardBus"},
	{PCIC_BRIDGE,		PCIS_BRIDGE_RACEWAY,	"PCI-RACEway"},
	{PCIC_SIMPLECOMM,	-1,			"simple comms"},
	{PCIC_SIMPLECOMM,	PCIS_SIMPLECOMM_UART,	"UART"},	/* could detect 16550 */
	{PCIC_SIMPLECOMM,	PCIS_SIMPLECOMM_PAR,	"parallel port"},
	{PCIC_SIMPLECOMM,	PCIS_SIMPLECOMM_MULSER,	"multiport serial"},
	{PCIC_SIMPLECOMM,	PCIS_SIMPLECOMM_MODEM,	"generic modem"},
	{PCIC_BASEPERIPH,	-1,			"base peripheral"},
	{PCIC_BASEPERIPH,	PCIS_BASEPERIPH_PIC,	"interrupt controller"},
	{PCIC_BASEPERIPH,	PCIS_BASEPERIPH_DMA,	"DMA controller"},
	{PCIC_BASEPERIPH,	PCIS_BASEPERIPH_TIMER,	"timer"},
	{PCIC_BASEPERIPH,	PCIS_BASEPERIPH_RTC,	"realtime clock"},
	{PCIC_BASEPERIPH,	PCIS_BASEPERIPH_PCIHOT,	"PCI hot-plug controller"},
	{PCIC_BASEPERIPH,	PCIS_BASEPERIPH_SDHC,	"SD host controller"},
	{PCIC_BASEPERIPH,	PCIS_BASEPERIPH_IOMMU,	"IOMMU"},
	{PCIC_INPUTDEV,		-1,			"input device"},
	{PCIC_INPUTDEV,		PCIS_INPUTDEV_KEYBOARD,	"keyboard"},
	{PCIC_INPUTDEV,		PCIS_INPUTDEV_DIGITIZER,"digitizer"},
	{PCIC_INPUTDEV,		PCIS_INPUTDEV_MOUSE,	"mouse"},
	{PCIC_INPUTDEV,		PCIS_INPUTDEV_SCANNER,	"scanner"},
	{PCIC_INPUTDEV,		PCIS_INPUTDEV_GAMEPORT,	"gameport"},
	{PCIC_DOCKING,		-1,			"docking station"},
	{PCIC_PROCESSOR,	-1,			"processor"},
	{PCIC_SERIALBUS,	-1,			"serial bus"},
	{PCIC_SERIALBUS,	PCIS_SERIALBUS_FW,	"FireWire"},
	{PCIC_SERIALBUS,	PCIS_SERIALBUS_ACCESS,	"AccessBus"},
	{PCIC_SERIALBUS,	PCIS_SERIALBUS_SSA,	"SSA"},
	{PCIC_SERIALBUS,	PCIS_SERIALBUS_USB,	"USB"},
	{PCIC_SERIALBUS,	PCIS_SERIALBUS_FC,	"Fibre Channel"},
	{PCIC_SERIALBUS,	PCIS_SERIALBUS_SMBUS,	"SMBus"},
	{PCIC_WIRELESS,		-1,			"wireless controller"},
	{PCIC_WIRELESS,		PCIS_WIRELESS_IRDA,	"iRDA"},
	{PCIC_WIRELESS,		PCIS_WIRELESS_IR,	"IR"},
	{PCIC_WIRELESS,		PCIS_WIRELESS_RF,	"RF"},
	{PCIC_INTELLIIO,	-1,			"intelligent I/O controller"},
	{PCIC_INTELLIIO,	PCIS_INTELLIIO_I2O,	"I2O"},
	{PCIC_SATCOM,		-1,			"satellite communication"},
	{PCIC_SATCOM,		PCIS_SATCOM_TV,		"sat TV"},
	{PCIC_SATCOM,		PCIS_SATCOM_AUDIO,	"sat audio"},
	{PCIC_SATCOM,		PCIS_SATCOM_VOICE,	"sat voice"},
	{PCIC_SATCOM,		PCIS_SATCOM_DATA,	"sat data"},
	{PCIC_CRYPTO,		-1,			"encrypt/decrypt"},
	{PCIC_CRYPTO,		PCIS_CRYPTO_NETCOMP,	"network/computer crypto"},
	{PCIC_CRYPTO,		PCIS_CRYPTO_NETCOMP,	"entertainment crypto"},
	{PCIC_DASP,		-1,			"dasp"},
	{PCIC_DASP,		PCIS_DASP_DPIO,		"DPIO module"},
	{PCIC_DASP,		PCIS_DASP_PERFCNTRS,	"performance counters"},
	{PCIC_DASP,		PCIS_DASP_COMM_SYNC,	"communication synchronizer"},
	{PCIC_DASP,		PCIS_DASP_MGMT_CARD,	"signal processing management"},
	{PCIC_ACCEL,		-1,			"processing accelerators"},
	{PCIC_ACCEL,		PCIS_ACCEL_PROCESSING,	"processing accelerators"},
	{PCIC_INSTRUMENT,	-1,			"non-essential instrumentation"},
	{0, 0,		NULL}
};


static int
list_devs(lua_State *L, const char *name)
{
	int fd;
	struct pci_conf_io pc;
	struct pci_conf conf[255], *p;
	struct pci_match_conf patterns[1];
	int none_count = 0;

	fd = open(_PATH_DEVPCI, O_RDONLY,
	    0);
	if (fd < 0) {
		printf("%s:%s\n", _PATH_DEVPCI, strerror(errno));
		return -1;
	}

	bzero(&pc, sizeof(struct pci_conf_io));
	pc.match_buf_len = sizeof(conf);
	pc.matches = conf;
	if (name != NULL) {
		bzero(&patterns, sizeof(patterns));
		patterns[0].pc_sel = getsel(name);

		patterns[0].flags = PCI_GETCONF_MATCH_DOMAIN |
		    PCI_GETCONF_MATCH_BUS | PCI_GETCONF_MATCH_DEV |
		    PCI_GETCONF_MATCH_FUNC;
		pc.num_patterns = 1;
		pc.pat_buf_len = sizeof(patterns);
		pc.patterns = patterns;
	}

	do {
		if (ioctl(fd, PCIOCGETCONF, &pc) == -1) {
			printf("%s:%s\n", "ioctl(PCIOCGETCONF)", strerror(errno));
			close(fd);
			return -1;
		}

		/*
		 * 255 entries should be more than enough for most people,
		 * but if someone has more devices, and then changes things
		 * around between ioctls, we'll do the cheesy thing and
		 * just bail.  The alternative would be to go back to the
		 * beginning of the list, and print things twice, which may
		 * not be desirable.
		 */
		if (pc.status == PCI_GETCONF_LIST_CHANGED) {
			warnx("PCI device list changed, please try again");
			close(fd);
			return -1;
		} else if (pc.status ==  PCI_GETCONF_ERROR) {
			warnx("error returned from PCIOCGETCONF ioctl");
			close(fd);
			return -1;
		}
		int i = 1;
		for (p = conf; p < &conf[pc.num_matches]; p++) {
			char buf[64];
			memset(buf, 0, sizeof(buf));
			lua_pushinteger(L, i++);
			lua_newtable(L);

			snprintf(buf, sizeof(buf), "%s%d", *p->pd_name ? p->pd_name : "none", *p->pd_name ? (int)p->pd_unit : none_count++);
			l_pushtablestring(L, "pc_name", buf);
			memset(buf, 0, sizeof(buf));

			l_pushtableinteger(L, "pc_domain", p->pc_sel.pc_domain);
			l_pushtableinteger(L, "pc_bus", p->pc_sel.pc_bus);
			l_pushtableinteger(L, "pc_dev", p->pc_sel.pc_dev);
			l_pushtableinteger(L, "pc_func", p->pc_sel.pc_func);

			snprintf(buf, sizeof(buf), "0x%06x", (p->pc_class << 16) | (p->pc_subclass << 8) | p->pc_progif);
			l_pushtablestring(L, "pc_class", buf);
			memset(buf, 0, sizeof(buf));

			snprintf(buf, sizeof(buf), "0x%08x", (p->pc_subdevice << 16) | p->pc_subvendor);
			l_pushtablestring(L, "card", buf);
			memset(buf, 0, sizeof(buf));

			snprintf(buf, sizeof(buf), "0x%08x", (p->pc_device << 16) | p->pc_vendor);
			l_pushtablestring(L, "chip", buf);
			memset(buf, 0, sizeof(buf));

			snprintf(buf, sizeof(buf), "0x%02x", p->pc_revid);
			l_pushtablestring(L, "rev", buf);
			memset(buf, 0, sizeof(buf));

			snprintf(buf, sizeof(buf), "0x%02x", p->pc_hdr);
			l_pushtablestring(L, "hdr", buf);
			memset(buf, 0, sizeof(buf));

			snprintf(buf, sizeof(buf), "%02x", p->pc_vendor);
			l_pushtablestring(L, "vendor", buf);
			memset(buf, 0, sizeof(buf));

			snprintf(buf, sizeof(buf), "%02x", p->pc_device);
			l_pushtablestring(L, "device", buf);
			memset(buf, 0, sizeof(buf));

			const char *dp;

			if ((dp = guess_class(p)) != NULL) {
				l_pushtablestring(L, "class", (char *)dp);
			}
			if ((dp = guess_subclass(p)) != NULL)
				l_pushtablestring(L, "subclass", (char *)dp);
			lua_settable(L, -3);

		}
	} while (pc.status == PCI_GETCONF_MORE_DEVS);

	close(fd);
	return 0;
}

static struct pcisel
getsel(const char *str)
{

	/*
	 * No device names contain colons and selectors always contain
	 * at least one colon.
	 */
	if (strchr(str, ':') == NULL)
		return (getdevice(str));
	else
		return (parsesel(str));
}

static const char *
guess_class(struct pci_conf *p)
{
	int	i;

	for (i = 0; pci_nomatch_tab[i].desc != NULL; i++) {
		if (pci_nomatch_tab[i].class == p->pc_class)
			return(pci_nomatch_tab[i].desc);
	}
	return(NULL);
}
static const char *
guess_subclass(struct pci_conf *p)
{
	int	i;

	for (i = 0; pci_nomatch_tab[i].desc != NULL; i++) {
		if ((pci_nomatch_tab[i].class == p->pc_class) &&
		    (pci_nomatch_tab[i].subclass == p->pc_subclass))
			return(pci_nomatch_tab[i].desc);
	}
	return(NULL);
}


static struct pcisel
getdevice(const char *name)
{
	struct pci_conf_io pc;
	struct pci_conf conf[1];
	struct pci_match_conf patterns[1];
	char *cp;
	int fd;	
	struct pcisel ps;
	memset(&ps, 0, sizeof(struct pcisel));

	fd = open(_PATH_DEVPCI, O_RDONLY, 0);
	if (fd < 0) {
		return ps;
	}

	bzero(&pc, sizeof(struct pci_conf_io));
	pc.match_buf_len = sizeof(conf);
	pc.matches = conf;

	bzero(&patterns, sizeof(patterns));
	/*
	 * The pattern structure requires the unit to be split out from
	 * the driver name.  Walk backwards from the end of the name to
	 * find the start of the unit.
	 */
	if (name[0] == '\0') {
		close(fd);
		return ps;
	}
	cp = strchr(name, '\0');
	if (cp == NULL || cp == name) {
		close(fd);
		return ps;
	}
	cp--;
	while (cp != name && isdigit(cp[-1]))
		cp--;
	if (cp == name || !isdigit(*cp)) {
		close(fd);
		return ps;
	}
	if ((size_t)(cp - name) + 1 > sizeof(patterns[0].pd_name)) {
		close(fd);
		return ps;
	}
	memcpy(patterns[0].pd_name, name, cp - name);
	patterns[0].pd_unit = strtol(cp, &cp, 10);
	if (*cp != '\0') {
		close(fd);
		return ps;
	}
	patterns[0].flags = PCI_GETCONF_MATCH_NAME | PCI_GETCONF_MATCH_UNIT;
	pc.num_patterns = 1;
	pc.pat_buf_len = sizeof(patterns);
	pc.patterns = patterns;

	if (ioctl(fd, PCIOCGETCONF, &pc) == -1) {
		close(fd);
		return ps;
	}
	if (pc.status != PCI_GETCONF_LAST_DEVICE &&
	    pc.status != PCI_GETCONF_MORE_DEVS) {
		close(fd);
		return ps;
	}
	close(fd);
	if (pc.num_matches == 0) {
		return ps;
	}
	return (conf[0].pc_sel);
}

static struct pcisel
parsesel(const char *str)
{
	const char *ep;
	char *eppos;
	struct pcisel sel;
	unsigned long selarr[4];
	int i;

	struct pcisel ps;
	memset(&ps, 0, sizeof(struct pcisel));

	ep = strchr(str, '@');
	if (ep != NULL)
		ep++;
	else
		ep = str;

	if (strncmp(ep, "pci", 3) == 0) {
		ep += 3;
		i = 0;
		while (isdigit(*ep) && i < 4) {
			selarr[i++] = strtoul(ep, &eppos, 10);
			ep = eppos;
			if (*ep == ':')
				ep++;
		}
		if (i > 0 && *ep == '\0') {
			sel.pc_func = (i > 2) ? selarr[--i] : 0;
			sel.pc_dev = (i > 0) ? selarr[--i] : 0;
			sel.pc_bus = (i > 0) ? selarr[--i] : 0;
			sel.pc_domain = (i > 0) ? selarr[--i] : 0;
			return (sel);
		}
	} 
	return ps;
}

static int libsystem_os_pciconf(lua_State *L)
{
	lua_newtable(L);
	if (list_devs(L, NULL)) {
		lua_pop(L, 1);
		lua_pushnil(L);
	}
    return 1;
}

static const luaL_Reg system_os[] = {
    {"exec", libsystem_os_execute}, 
    {"execv", libsystem_os_execute_v}, 
    {"exec_nowait", libsystem_os_execute_nowait}, 
    {"execv_nowait", libsystem_os_execute_nowait_v}, 
    {"cmd", libsystem_os_cmd},
	{"fork", libsystem_os_run_func},
	{"kill", libsystem_os_kill},

    {"kldload", libsystem_os_kldload}, 
    {"kldunload", libsystem_os_kldunload}, 
    {"kldstat", libsystem_os_kldstat},

    {"kenv_get", libsystem_os_kenv_get},
    {"kenv_set", libsystem_os_kenv_set},
    {"kenv_unset", libsystem_os_kenv_unset},
	{"hostname", libsystem_os_hostname},

    {"mkdir", libsystem_os_mkdir},
	{"cp", libsystem_os_cp},
    {"ls", libsystem_os_ls},
    {"rm", libsystem_os_rm},
    {"pwd", libsystem_os_pwd},
	{"clear", libsystem_os_clear},

	{"mount", libsystem_os_mount},
	{"umount", libsystem_os_umount},
	{"diskinfo", libsystem_os_diskinfo},

	{"reboot", libsystem_os_reboot},
	{"shutdown", libsystem_os_shutdown},

	{"chown", libsystem_os_chown},
	{"chmod", libsystem_os_chmod},
	{"chroot", libsystem_os_chroot},
	{"ps", libsystem_os_ps},
	{"pciconf", libsystem_os_pciconf},
    {NULL, NULL}
};


#ifdef STATIC
LUAMOD_API int luaopen_libluasystem_os(lua_State *L)
#else
LUALIB_API int luaopen_libluasystem_os(lua_State *L)
#endif
{
    luaL_newlib(L, system_os);
    return 1;
}
